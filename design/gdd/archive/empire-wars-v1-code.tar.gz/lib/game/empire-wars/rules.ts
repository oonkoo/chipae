import { z } from "zod";
import {
  BOARD_TILE_COUNT,
  BOSSES,
  BROKEN,
  COMBAT,
  COSTS,
  DISTRICTS,
  EMPIRE_VALUE,
  EMPIRE_WARS_CONFIG,
  HEAT,
  KINGPIN,
  LAUNDER_RATES,
  LEVEL_DEFENCE,
  LEVEL_INCOME_MULT,
  LEVEL_VALUE_MULT,
  PROTECTION,
  RESPECT,
  TERRITORIES,
  TERRITORY_RING,
  TIER_CASH_RATE,
  TIER_DIRTY_RATE,
  UPGRADE_PRICE_MULT,
  type BossId,
  type DistrictId,
} from "@/lib/game/data/empire-wars";

// Pure rules for Empire Wars (design/gdd/empire-wars-core.md).
//
// SCHEMA GROWTH: every field added after a version ships carries a `.default()`.
// `GameSession.state` rows are written by whatever code was deployed at the
// time, so a required-but-new key makes every in-flight game unreadable the
// moment it ships — and an unreadable game used to wedge its lobby in IN_GAME
// forever. Defaults keep old saves loadable; `startGame` handles the rest.
// No DB, no I/O, no clock, no Math.random — every impurity arrives as an
// argument, which is what makes seeded replay and the Heat simulation possible
// (ADR-0005 Amendment 1).

// ─── State ───────────────────────────────────────────────────────────────────

export const PROPERTY_LEVELS = [1, 2, 3, 4, 5] as const;
export type PropertyLevel = (typeof PROPERTY_LEVELS)[number];

const territorySchema = z.object({
  /** Matches an id in TERRITORIES. */
  id: z.string(),
  /** LobbyMember id, or null while unowned. */
  ownerId: z.string().nullable(),
  level: z.union([
    z.literal(1),
    z.literal(2),
    z.literal(3),
    z.literal(4),
    z.literal(5),
  ]),
  /** Crew garrisoned here. Level 2 needs 1, Level 5 needs 2. */
  garrison: z.number().int().min(0),
  /** How many times this tile has been declined, driving the mark-down. */
  declines: z.number().int().min(0),
});
export type TerritoryState = z.infer<typeof territorySchema>;

const missionSchema = z.object({
  id: z.string(),
  /** Hidden from every other seat until completed. */
  completed: z.boolean(),
});

const playerSchema = z.object({
  /** LobbyMember id. */
  id: z.string(),
  boss: z.enum(BOSSES.map((b) => b.id) as [BossId, ...BossId[]]),
  cash: z.number().int(),
  dirty: z.number().int().min(0),
  respect: z.number().int().min(RESPECT.min).max(RESPECT.max),
  heat: z.number().int().min(HEAT.min).max(HEAT.max),
  /** Crew in hand — attacks, and defends you in a standoff. */
  poolCrew: z.number().int().min(0),
  /** Enforcers count double in combat and cannot be garrisoned. */
  enforcers: z.number().int().min(0),
  tile: z.number().int().min(0).max(BOARD_TILE_COUNT - 1),
  /** Turns left inside; 0 means free. */
  jailTurns: z.number().int().min(0),
  missions: z.array(missionSchema),
  /**
   * This player's own remaining mission deck.
   *
   * Per-player rather than shared: the GDD specifies **10** mission cards and
   * a hand of 3, but 6 seats need 18 to deal and more again to replace on
   * completion. A shared deck cannot serve a full table. Each seat therefore
   * draws from its own shuffled copy, so two players may hold the same
   * objective without knowing it — which is a feature at a table where
   * missions are secret.
   */
  missionDeck: z.array(z.string()).default([]),
  /** Capped so going broke can never become a strategy. */
  bailoutsTaken: z.number().int().min(0),
  /**
   * Running totals missions score against. Kept on state rather than derived
   * because none of them can be reconstructed from a board position — you
   * cannot look at a table and see how many fights someone has won.
   */
  fightsWon: z.number().int().min(0).default(0),
  turfWarsWon: z.number().int().min(0).default(0),
  launderedTotal: z.number().int().min(0).default(0),
  /** Set while this player is above the Most Wanted line. */
  mostWanted: z.boolean(),
  /** Quit the match — out of rotation, territories released. */
  eliminated: z.boolean().default(false),
});
export type EmpirePlayer = z.infer<typeof playerSchema>;

/** The only two pending decisions in v1, each with exactly one answerer. */
const pendingSchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("protection"),
    /** Who owes the answer. Always the active player for `protection`. */
    memberId: z.string(),
    territoryId: z.string(),
    fee: z.number().int().min(0),
    expiresAt: z.number().int(),
  }),
  z.object({
    kind: z.literal("truce"),
    memberId: z.string(),
    fromMemberId: z.string(),
    expiresAt: z.number().int(),
  }),
]);
export type PendingDecision = z.infer<typeof pendingSchema>;

const stateSchema = z.object({
  gameType: z.literal(EMPIRE_WARS_CONFIG.gameType),
  players: z.array(playerSchema), // seat order
  territories: z.array(territorySchema),
  currentIndex: z.number().int().min(0),
  round: z.number().int().min(1),
  turnCount: z.number().int().min(0),
  /**
   * Where the active seat is in its turn. Upkeep is not a phase — it runs
   * automatically when a turn opens.
   */
  phase: z.enum(["roll", "act", "build"]).default("roll"),
  /** The action die's face, held until the player uses or declines it. */
  dieFace: z
    .enum(["money-bag", "police", "gun", "car", "handshake", "question"])
    .nullable()
    .default(null),
  /** Consecutive doubles this turn — three sends you to jail. */
  doubles: z.number().int().min(0).default(0),
  /**
   * The last roll, kept so the board can show what actually happened.
   * `seq` increments every roll, which is what lets the client tell a fresh
   * roll from a re-render that happens to have the same numbers.
   */
  lastRoll: z
    .object({
      memberId: z.string(),
      d1: z.number().int().min(1).max(6),
      d2: z.number().int().min(1).max(6),
      from: z.number().int().min(0),
      to: z.number().int().min(0),
      seq: z.number().int().min(0),
    })
    .nullable()
    .default(null),
  /** Set once a turn's turf war has been declared; at most one per turn. */
  turfWarUsed: z.boolean().default(false),
  /**
   * Whether the tile the active seat landed on has been dealt with. Without
   * it, declining is repeatable — and a bot re-evaluating the same unowned
   * tile declines forever.
   */
  tileDone: z.boolean().default(false),
  /** Free attack owed to a player who just broke a truce. */
  freeAttackFor: z.string().nullable().default(null),
  /** The last few things that happened, for the board to narrate. */
  log: z.array(z.string()).default([]),
  /** Halts the whole table while set. At most one, ever. */
  pending: pendingSchema.nullable(),
  /** Unordered pairs of member ids, `a|b` with a < b. */
  truces: z.array(z.string()),
  /** Remaining event ids, drawn in order. */
  eventDeck: z.array(z.string()),
  winnerId: z.string().nullable(),
  /** Set when the winner took it by Kingpin rather than on points. */
  kingpin: z.boolean(),
  /**
   * Bumped on **every** applied move.
   *
   * Clients drive bots by watching for change, and a bot's turn is many moves
   * (roll, buy, upgrade, end). Without a value that moves every single time, a
   * watcher keyed on phase or round simply stops firing mid-turn and the table
   * hangs on "…is thinking".
   */
  version: z.number().int().min(0).default(0),
  /**
   * When the seat on the clock runs out of time, epoch ms.
   *
   * Serverless has no clock, so this is a deadline in state that clients call
   * in on — the same lazy pattern as pending decisions. It is what stops one
   * player who walked away from freezing the match for everyone else.
   */
  turnExpiresAt: z.number().int().nullable().default(null),
});
export type EmpireState = z.infer<typeof stateSchema>;

/** Validate state read back from GameSession.state; malformed fails closed. */
export function parseState(raw: unknown): EmpireState | null {
  const parsed = stateSchema.safeParse(raw);
  return parsed.success ? parsed.data : null;
}

export type EmpireTransition =
  | { ok: true; state: EmpireState }
  | { ok: false; error: string };

// ─── Board lookups ───────────────────────────────────────────────────────────

const BY_ID = new Map(TERRITORIES.map((t) => [t.id, t]));
const BY_TILE = new Map(TERRITORIES.map((t) => [t.tile, t]));

export function territoryDef(id: string) {
  const def = BY_ID.get(id);
  if (!def) throw new Error(`Unknown territory: ${id}`);
  return def;
}

export function territoryAtTile(tile: number) {
  return BY_TILE.get(tile) ?? null;
}

/**
 * The two neighbours of a territory, from the declared ring — never from tile
 * geometry, so the board can be laid out as a ring on desktop and as district
 * columns on a phone without the rules changing (GDD > Edge Cases > Adjacency).
 */
export function neighboursOf(id: string): [string, string] {
  const i = TERRITORY_RING.indexOf(id);
  if (i < 0) throw new Error(`Unknown territory: ${id}`);
  const n = TERRITORY_RING.length;
  return [TERRITORY_RING[(i - 1 + n) % n], TERRITORY_RING[(i + 1) % n]];
}

export function playerOf(state: EmpireState, memberId: string) {
  return state.players.find((p) => p.id === memberId) ?? null;
}

export function currentPlayer(state: EmpireState): EmpirePlayer {
  return state.players[state.currentIndex];
}

export function territoriesOf(state: EmpireState, memberId: string) {
  return state.territories.filter((t) => t.ownerId === memberId);
}

/** Districts where this player owns all three tiles. */
export function completedDistricts(
  state: EmpireState,
  memberId: string
): DistrictId[] {
  return DISTRICTS.filter((d) => {
    const inDistrict = TERRITORIES.filter((t) => t.district === d.id);
    return inDistrict.every(
      (t) =>
        state.territories.find((s) => s.id === t.id)?.ownerId === memberId
    );
  }).map((d) => d.id);
}

export function hasTruce(state: EmpireState, a: string, b: string): boolean {
  return state.truces.includes(trucePair(a, b));
}

export function trucePair(a: string, b: string): string {
  return [a, b].sort().join("|");
}

// ─── Formulas ────────────────────────────────────────────────────────────────
// `round()` is half-up throughout, i.e. Math.round — several published values
// land exactly on .5 and disagree under any other rule (GDD > Formulas).

/** Cash a tile pays per collection at its current level. */
export function cashIncome(territory: TerritoryState): number {
  const def = territoryDef(territory.id);
  return Math.round(
    def.price * TIER_CASH_RATE[def.tier] * LEVEL_INCOME_MULT[territory.level]
  );
}

/** The greedy option, or null on a small tile which never offers one. */
export function dirtyIncome(territory: TerritoryState): number | null {
  const def = territoryDef(territory.id);
  const rate = TIER_DIRTY_RATE[def.tier];
  if (rate === null) return null;
  return Math.round(def.price * rate * LEVEL_INCOME_MULT[territory.level]);
}

/** What a visitor owes. `ownsDistrict` applies the owner's district bonus. */
export function protectionFee(
  territory: TerritoryState,
  ownsDistrict: boolean
): number {
  const def = territoryDef(territory.id);
  const base =
    def.price *
    PROTECTION.rate *
    LEVEL_INCOME_MULT[territory.level] *
    PROTECTION.markup;
  return Math.round(base * (ownsDistrict ? PROTECTION.districtMult : 1));
}

/** Cash cost to reach a paid level. Levels 2 and 5 are reached by garrisoning. */
export function upgradeCost(territoryId: string, toLevel: 3 | 4 | 5): number {
  return Math.round(territoryDef(territoryId).price * UPGRADE_PRICE_MULT[toLevel]);
}

/** List price after cumulative declines, floored. */
export function currentPrice(territory: TerritoryState): number {
  const list = territoryDef(territory.id).price;
  const factor = Math.max(
    COSTS.declineFloor,
    1 - COSTS.declineMarkdown * territory.declines
  );
  return Math.round(list * factor);
}

/** Combat dice a defended tile fields: its garrison plus level defence. */
export function tileDefence(territory: TerritoryState): number {
  return territory.garrison + LEVEL_DEFENCE[territory.level];
}

/** Combat dice a player brings to an attack. Enforcers count double. */
export function attackStrength(player: EmpirePlayer): number {
  return player.poolCrew + player.enforcers * COMBAT.enforcerCrewValue;
}

/**
 * Empire Value. `crew` counts **pool crew only** — garrisoned crew are already
 * priced in through LEVEL_VALUE_MULT, since Levels 2 and 5 are reached by
 * garrisoning, and counting them twice inflates a Fortress-heavy empire.
 */
export function empireValue(state: EmpireState, memberId: string): number {
  const player = playerOf(state, memberId);
  if (!player) return 0;
  const property = territoriesOf(state, memberId).reduce(
    (sum, t) => sum + territoryDef(t.id).price * LEVEL_VALUE_MULT[t.level],
    0
  );
  return Math.round(
    player.cash +
      player.dirty * EMPIRE_VALUE.dirtyWeight +
      property +
      (player.poolCrew + player.enforcers) * EMPIRE_VALUE.crewWeight +
      player.respect * EMPIRE_VALUE.respectWeight
  );
}

/** Mean Empire Value across seats still in the match. */
export function meanEmpireValue(state: EmpireState): number {
  const active = state.players.filter((p) => !p.eliminated);
  if (active.length === 0) return 0;
  return (
    active.reduce((sum, p) => sum + empireValue(state, p.id), 0) / active.length
  );
}

/** Above 1.25× the table mean. The anti-runaway trigger. */
export function isMostWanted(state: EmpireState, memberId: string): boolean {
  const mean = meanEmpireValue(state);
  if (mean <= 0) return false;
  return empireValue(state, memberId) > HEAT.mostWantedMult * mean;
}

export type HeatBand = "clean" | "watched" | "raids" | "federal";

export function heatBand(heat: number): HeatBand {
  if (heat >= HEAT.federalAt) return "federal";
  if (heat >= HEAT.raidsAt) return "raids";
  if (heat >= HEAT.watchedAt) return "watched";
  return "clean";
}

export function clampHeat(heat: number): number {
  return Math.min(HEAT.max, Math.max(HEAT.min, heat));
}

export function clampRespect(respect: number): number {
  return Math.min(RESPECT.max, Math.max(RESPECT.min, respect));
}

/**
 * Net Heat change at a player's upkeep, before any die or action.
 *
 * The `mostWanted` suppression is the anti-runaway brake. Without it the
 * Most Wanted gain and the clean shed cancel exactly, the leader never leaves
 * the Clean band, and the raid-seizure clause never fires (GDD > Heat).
 */
export function upkeepHeatDelta(player: EmpirePlayer): number {
  if (player.dirty > 0) {
    return Math.floor(player.dirty / HEAT.dirtyStep);
  }
  const shedApplies = !player.mostWanted || HEAT.cleanShedAppliesToMostWanted;
  return shedApplies ? -HEAT.cleanUpkeepShed : 0;
}

/** Fraction returned when laundering, given where and who you are. */
export function launderRate(opts: {
  atSafehouse: boolean;
  ownsMoneyLaundry: boolean;
  isSmuggler: boolean;
  forced?: boolean;
}): number {
  if (opts.forced) return LAUNDER_RATES.forced;
  const base = opts.atSafehouse
    ? LAUNDER_RATES.safehouse
    : opts.ownsMoneyLaundry
      ? LAUNDER_RATES.moneyLaundryOwned
      : LAUNDER_RATES.elsewhere;
  return opts.isSmuggler ? base + LAUNDER_RATES.smugglerBonus : base;
}

export function isKingpin(state: EmpireState, memberId: string): boolean {
  const player = playerOf(state, memberId);
  if (!player || player.eliminated) return false;
  return (
    completedDistricts(state, memberId).length >= KINGPIN.districts &&
    player.respect >= KINGPIN.respect &&
    player.heat < KINGPIN.maxHeat
  );
}

// ─── Dice ────────────────────────────────────────────────────────────────────

export const ACTION_DIE_FACES = [
  "money-bag",
  "police",
  "gun",
  "car",
  "handshake",
  "question",
] as const;
export type ActionDieFace = (typeof ACTION_DIE_FACES)[number];

export function rollD6(random: () => number): number {
  return 1 + Math.floor(random() * 6);
}

export function rollActionDie(random: () => number): ActionDieFace {
  return ACTION_DIE_FACES[Math.floor(random() * ACTION_DIE_FACES.length)];
}

/**
 * One side of a fight: roll d6 equal to strength (minimum one), keep the best
 * two, sum. Fewer dice than `diceKept` simply keeps them all.
 */
export function rollCombat(strength: number, random: () => number): number {
  const count = Math.max(COMBAT.minDice, strength);
  const dice = Array.from({ length: count }, () => rollD6(random));
  dice.sort((a, b) => b - a);
  return dice.slice(0, COMBAT.diceKept).reduce((sum, d) => sum + d, 0);
}

/** Ties go to the defender, always. */
export function resolveCombat(
  attack: number,
  defence: number,
  random: () => number
): { attackerWins: boolean; attackRoll: number; defenceRoll: number } {
  const attackRoll = rollCombat(attack, random);
  const defenceRoll = rollCombat(defence, random);
  return {
    attackerWins: attackRoll > defenceRoll,
    attackRoll,
    defenceRoll,
  };
}

// ─── Setup ───────────────────────────────────────────────────────────────────

/** Fisher–Yates, immutably, with injected rng. */
export function shuffle<T>(items: T[], random: () => number): T[] {
  const out = [...items];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/**
 * Opening position. Bosses are dealt without replacement, missions dealt from
 * a shuffled deck, and every seat starts on The Docks with an identical purse.
 */
export function dealGame(
  memberIds: string[],
  random: () => number,
  opts: { missionIds: string[]; eventIds: string[] }
): EmpireState {
  const bosses = shuffle(
    BOSSES.map((b) => b.id),
    random
  );
  const eventDeck = shuffle(opts.eventIds, random);

  const players: EmpirePlayer[] = memberIds.map((id, i) => {
    // Each seat draws from its own shuffled copy — see missionDeck above.
    const own = shuffle(opts.missionIds, random);
    const hand = own.slice(0, EMPIRE_WARS_CONFIG.missionsInHand);
    return {
      id,
      boss: bosses[i % bosses.length],
      cash: EMPIRE_WARS_CONFIG.startingCash,
      dirty: EMPIRE_WARS_CONFIG.startingDirty,
      respect: EMPIRE_WARS_CONFIG.startingRespect,
      heat: EMPIRE_WARS_CONFIG.startingHeat,
      poolCrew: EMPIRE_WARS_CONFIG.startingCrew,
      enforcers: 0,
      tile: 0,
      jailTurns: 0,
      missions: hand.map((mid) => ({ id: mid, completed: false })),
      missionDeck: own.slice(EMPIRE_WARS_CONFIG.missionsInHand),
      bailoutsTaken: 0,
      fightsWon: 0,
      turfWarsWon: 0,
      launderedTotal: 0,
      mostWanted: false,
      eliminated: false,
    };
  });

  return {
    gameType: EMPIRE_WARS_CONFIG.gameType,
    players,
    territories: TERRITORIES.map((t) => ({
      id: t.id,
      ownerId: null,
      level: 1 as PropertyLevel,
      garrison: 0,
      declines: 0,
    })),
    currentIndex: Math.floor(random() * memberIds.length),
    round: 1,
    turnCount: 0,
    phase: "roll" as const,
    dieFace: null,
    doubles: 0,
    lastRoll: null,
    turfWarUsed: false,
    tileDone: false,
    freeAttackFor: null,
    log: [],
    pending: null,
    truces: [],
    eventDeck,
    winnerId: null,
    kingpin: false,
    version: 0,
    turnExpiresAt: null,
  };
}

// ─── Standings ───────────────────────────────────────────────────────────────

/** Finishing order: Empire Value desc, then territories, then Respect, then seat. */
export function standingsOrder(state: EmpireState): string[] {
  return [...state.players]
    .sort((a, b) => {
      if (a.eliminated !== b.eliminated) return a.eliminated ? 1 : -1;
      const evDiff = empireValue(state, b.id) - empireValue(state, a.id);
      if (evDiff !== 0) return evDiff;
      const tDiff =
        territoriesOf(state, b.id).length - territoriesOf(state, a.id).length;
      if (tDiff !== 0) return tDiff;
      const rDiff = b.respect - a.respect;
      if (rDiff !== 0) return rDiff;
      return state.players.indexOf(a) - state.players.indexOf(b);
    })
    .map((p) => p.id);
}

export { BROKEN, HEAT, EMPIRE_WARS_CONFIG };
