import { RESPECT } from "@/lib/game/data/empire-wars";
import {
  eventById,
  missionById,
  type MissionId,
} from "@/lib/game/data/empire-wars-content";
import {
  clampHeat,
  clampRespect,
  completedDistricts,
  playerOf,
  territoriesOf,
  territoryDef,
  type EmpirePlayer,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";

// Missions and events: the two content systems. Both are data-driven — adding
// a card touches `lib/game/data/empire-wars-content.ts` and never this file.

function clone(state: EmpireState): EmpireState {
  return structuredClone(state);
}

/**
 * Is this mission satisfied right now?
 *
 * Every predicate reads only from state, so a mission can complete on someone
 * else's turn (a rival's turf war can hand you your sixth territory) and it
 * will be noticed the next time completion is checked.
 */
function isComplete(
  state: EmpireState,
  player: EmpirePlayer,
  missionId: string
): boolean {
  const owned = territoriesOf(state, player.id);
  switch (missionId as MissionId) {
    case "control-a-district":
      return completedDistricts(state, player.id).length >= 1;
    case "five-grand":
      return player.cash >= 5000;
    case "three-wins":
      return player.fightsWon >= 3;
    case "respect-twenty":
      return player.respect >= 20;
    case "two-landmarks":
      return owned.filter((t) => territoryDef(t.id).tier === "landmark").length >= 2;
    case "take-by-force":
      return player.turfWarsWon >= 1;
    case "launder-three-grand":
      return player.launderedTotal >= 3000;
    case "clean-empire":
      return player.heat === 0 && owned.length >= 6;
    case "six-tiles":
      return owned.length >= 6;
    case "fortress":
      return owned.some((t) => t.level === 5);
    default:
      return false;
  }
}

export type MissionCompletion = { missionId: string; respect: number; cash: number };

/**
 * Check a seat's hand, pay out anything finished, and top the hand back up.
 *
 * A completed mission flips face-up (it stays in hand, marked) and a
 * replacement is drawn from that seat's own deck. When the deck runs dry the
 * hand simply shrinks — there is no reshuffle, because completed missions are
 * public and re-dealing one would be a visible repeat.
 */
export function settleMissions(
  state: EmpireState,
  memberId: string
): { state: EmpireState; completed: MissionCompletion[] } {
  const next = clone(state);
  const player = playerOf(next, memberId);
  if (!player) return { state: next, completed: [] };

  const completed: MissionCompletion[] = [];

  for (const held of player.missions) {
    if (held.completed) continue;
    if (!isComplete(next, player, held.id)) continue;

    const def = missionById(held.id);
    held.completed = true;
    const respect = def?.respect ?? 0;
    const cash = def?.cash ?? 0;
    player.respect = clampRespect(player.respect + respect);
    player.cash += cash;
    completed.push({ missionId: held.id, respect, cash });
  }

  // Top back up to a full hand from this seat's own deck.
  const live = player.missions.filter((m) => !m.completed).length;
  const wanted = 3 - live;
  for (let i = 0; i < wanted; i++) {
    const drawn = player.missionDeck.shift();
    if (!drawn) break;
    player.missions.push({ id: drawn, completed: false });
  }

  return { state: next, completed };
}

export type EventEffect = {
  id: string;
  text: string;
  cash: number;
  dirty: number;
  heat: number;
  respect: number;
};

/**
 * Apply a drawn event to the seat that drew it.
 *
 * Every event in v1 is **personal** — city-wide cards were cut in review,
 * because an event that touches other seats could open a second decision and
 * break ADR-0005's one-seat-on-the-clock model.
 */
export function applyEvent(
  state: EmpireState,
  memberId: string,
  eventId: string
): { state: EmpireState; effect: EventEffect | null } {
  const def = eventById(eventId);
  if (!def) return { state, effect: null };

  const next = clone(state);
  const player = playerOf(next, memberId);
  if (!player) return { state: next, effect: null };

  // Cash can go negative on paper; the debt path is the caller's business, so
  // a card never takes more than the player actually holds.
  player.cash = Math.max(0, player.cash + def.cash);
  player.dirty = Math.max(0, player.dirty + def.dirty);
  player.heat = clampHeat(player.heat + def.heat);
  player.respect = clampRespect(player.respect + def.respect);

  return {
    state: next,
    effect: {
      id: def.id,
      text: def.text,
      cash: def.cash,
      dirty: def.dirty,
      heat: def.heat,
      respect: def.respect,
    },
  };
}

export { RESPECT };
