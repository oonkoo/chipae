import { AGGRESSION, EMPIRE_WARS_CONFIG } from "@/lib/game/data/empire-wars";
import {
  attackStrength,
  clampHeat,
  clampRespect,
  hasTruce,
  neighboursOf,
  playerOf,
  resolveCombat,
  territoriesOf,
  tileDefence,
  type EmpirePlayer,
  type EmpireState,
  type EmpireTransition,
} from "@/lib/game/empire-wars/rules";
import { feeFor, payProtection, settleDebt } from "@/lib/game/empire-wars/economy";

// The three fights (GDD > Detailed Rules).
//
//   standoff  — refuse a protection fee. Money and Respect. Land never moves.
//   strike    — the Gun die. Crew against crew, anywhere on the board.
//   turf war  — declared in Build against an adjacent tile. Land moves.
//
// All three share one resolution: roll d6 equal to strength, keep the best
// two, ties to the defender. Only the stakes differ.

function clone(state: EmpireState): EmpireState {
  return structuredClone(state);
}

function bump(player: EmpirePlayer, respect: number, heat = 0) {
  player.respect = clampRespect(player.respect + respect);
  if (heat) player.heat = clampHeat(player.heat + heat);
}

export type FightOutcome = {
  attackerWins: boolean;
  attackRoll: number;
  defenceRoll: number;
  attackDice: number;
  defenceDice: number;
};

// ─── The standoff ────────────────────────────────────────────────────────────

export type StandoffResult = {
  state: EmpireState;
  outcome: FightOutcome;
  /** What the visitor ended up handing over. */
  paid: number;
  broken: boolean;
};

/**
 * Refuse a protection fee and fight for it.
 *
 * The visitor brings their pool crew; the owner brings **only that tile's
 * garrison plus its level defence** — their pool crew are elsewhere. Winning
 * cancels the fee and moves Respect; losing costs double and a crew.
 * Ownership never changes: that is what turf war is for.
 */
export function resolveStandoff(
  state: EmpireState,
  visitorId: string,
  territoryId: string,
  random: () => number
): StandoffResult {
  let next = clone(state);
  const territory = next.territories.find((t) => t.id === territoryId)!;
  const visitor = playerOf(next, visitorId)!;
  const owner = playerOf(next, territory.ownerId!)!;

  const attackDice = attackStrength(visitor);
  const defenceDice = tileDefence(territory);
  const roll = resolveCombat(attackDice, defenceDice, random);
  const outcome: FightOutcome = { ...roll, attackDice, defenceDice };

  // Violence is noticed whether or not it works.
  bump(visitor, 0, AGGRESSION.refuseHeat);

  if (outcome.attackerWins) {
    visitor.fightsWon += 1;
    bump(visitor, AGGRESSION.refuseWinnerRespect);
    bump(owner, AGGRESSION.refuseLoserOwnerRespect);
    return { state: next, outcome, paid: 0, broken: false };
  }

  // Lost: pay double, lose a crew.
  visitor.poolCrew = Math.max(0, visitor.poolCrew - 1);
  const fee = feeFor(next, territory) * 2;
  if (visitor.cash >= fee) {
    const paidResult = payProtection(next, visitorId, territoryId, 2);
    return {
      state: paidResult.state,
      outcome,
      paid: paidResult.paid,
      broken: false,
    };
  }

  const settled = settleDebt(next, visitorId, fee, territory.ownerId);
  next = settled.state;
  return { state: next, outcome, paid: fee, broken: settled.broken };
}

// ─── The strike ──────────────────────────────────────────────────────────────

/**
 * The Gun die's attack: crew against crew. It hits a *player*, not a tile, so
 * it ignores adjacency entirely — nowhere on the board is safe from it, which
 * is what keeps a garrison-heavy player honest. The defender gets no decision
 * and it never blocks the table.
 */
export function resolveStrike(
  state: EmpireState,
  attackerId: string,
  defenderId: string,
  random: () => number
): { state: EmpireState; outcome: FightOutcome } | { error: string } {
  if (attackerId === defenderId) return { error: "You can't strike yourself" };
  if (hasTruce(state, attackerId, defenderId)) {
    return { error: "You have a truce with them" };
  }
  const next = clone(state);
  const attacker = playerOf(next, attackerId);
  const defender = playerOf(next, defenderId);
  if (!attacker || !defender) return { error: "No such player" };
  if (defender.eliminated) return { error: "They're out of the game" };

  const attackDice = attackStrength(attacker);
  const defenceDice = attackStrength(defender);
  const roll = resolveCombat(attackDice, defenceDice, random);
  const outcome: FightOutcome = { ...roll, attackDice, defenceDice };

  bump(attacker, 0, AGGRESSION.strikeHeat);
  if (outcome.attackerWins) {
    defender.poolCrew = Math.max(0, defender.poolCrew - 1);
    attacker.fightsWon += 1;
    bump(attacker, AGGRESSION.strikeWinnerRespect);
  } else {
    attacker.poolCrew = Math.max(0, attacker.poolCrew - 1);
  }
  return { state: next, outcome };
}

/** Seats a strike may legally reach: within range, or holding a neighbour tile. */
export function strikeTargets(state: EmpireState, attackerId: string): string[] {
  const attacker = playerOf(state, attackerId);
  if (!attacker) return [];

  const mine = new Set(territoriesOf(state, attackerId).map((t) => t.id));
  const neighbourOwners = new Set<string>();
  for (const id of mine) {
    for (const n of neighboursOf(id)) {
      const owner = state.territories.find((t) => t.id === n)?.ownerId;
      if (owner && owner !== attackerId) neighbourOwners.add(owner);
    }
  }

  return state.players
    .filter((p) => {
      if (p.id === attackerId || p.eliminated) return false;
      if (hasTruce(state, attackerId, p.id)) return false;
      if (neighbourOwners.has(p.id)) return true;
      const gap = Math.abs(p.tile - attacker.tile);
      const ring = Math.min(gap, 32 - gap);
      return ring <= AGGRESSION.strikeRangeTiles;
    })
    .map((p) => p.id);
}

// ─── Turf war ────────────────────────────────────────────────────────────────

/** Tiles this player may declare a turf war on: owned by a rival, adjacent to one of theirs. */
export function turfWarTargets(state: EmpireState, attackerId: string): string[] {
  const mine = territoriesOf(state, attackerId).map((t) => t.id);
  const targets = new Set<string>();
  for (const id of mine) {
    for (const n of neighboursOf(id)) {
      const tile = state.territories.find((t) => t.id === n);
      if (!tile?.ownerId || tile.ownerId === attackerId) continue;
      if (hasTruce(state, attackerId, tile.ownerId)) continue;
      targets.add(n);
    }
  }
  return [...targets];
}

export type TurfWarResult = {
  state: EmpireState;
  outcome: FightOutcome;
  captured: boolean;
};

/**
 * Take a neighbouring tile by force. The winner gets it **at its current
 * level** with the garrison destroyed — so a Fortress taken is a Fortress
 * owned, minus its defenders. The attacker gains Heat either way: a turf war
 * is loud.
 */
export function resolveTurfWar(
  state: EmpireState,
  attackerId: string,
  territoryId: string,
  random: () => number
): TurfWarResult | { error: string } {
  if (!turfWarTargets(state, attackerId).includes(territoryId)) {
    return { error: "You can't reach that territory" };
  }
  const next = clone(state);
  const territory = next.territories.find((t) => t.id === territoryId)!;
  const attacker = playerOf(next, attackerId)!;
  const defender = playerOf(next, territory.ownerId!)!;

  const attackDice = attackStrength(attacker);
  const defenceDice = tileDefence(territory);
  const roll = resolveCombat(attackDice, defenceDice, random);
  const outcome: FightOutcome = { ...roll, attackDice, defenceDice };

  bump(attacker, 0, AGGRESSION.turfWarHeat);

  if (outcome.attackerWins) {
    territory.ownerId = attackerId;
    territory.garrison = 0;
    attacker.fightsWon += 1;
    attacker.turfWarsWon += 1;
    bump(attacker, AGGRESSION.turfWarWinnerRespect);
    bump(defender, AGGRESSION.turfWarLoserRespect);
    return { state: next, outcome, captured: true };
  }

  attacker.poolCrew = Math.max(0, attacker.poolCrew - 1);
  bump(attacker, AGGRESSION.turfWarLoserRespect);
  return { state: next, outcome, captured: false };
}

// ─── Truce ───────────────────────────────────────────────────────────────────

/** One truce per player, so an offer to someone already paired is refused. */
export function canOfferTruce(
  state: EmpireState,
  fromId: string,
  toId: string
): boolean {
  if (fromId === toId) return false;
  const busy = (id: string) =>
    state.truces.some((pair) => pair.split("|").includes(id));
  const target = playerOf(state, toId);
  return !!target && !target.eliminated && !busy(fromId) && !busy(toId);
}

export function acceptTruce(
  state: EmpireState,
  a: string,
  b: string
): EmpireTransition {
  if (!canOfferTruce(state, a, b)) {
    return { ok: false, error: "That truce isn't available" };
  }
  const next = clone(state);
  next.truces = [...next.truces, [a, b].sort().join("|")];
  return { ok: true, state: next };
}

/**
 * Break a truce during Build. Costs 3 Respect and grants exactly one free
 * attack, which the caller spends immediately — that is the whole betrayal
 * mechanic, with no negotiation UI and nothing that blocks on another human.
 */
export function breakTruce(
  state: EmpireState,
  breakerId: string,
  otherId: string
): EmpireTransition {
  if (!hasTruce(state, breakerId, otherId)) {
    return { ok: false, error: "You have no truce with them" };
  }
  const next = clone(state);
  next.truces = next.truces.filter(
    (pair) => pair !== [breakerId, otherId].sort().join("|")
  );
  const breaker = playerOf(next, breakerId)!;
  bump(breaker, -3);
  return { ok: true, state: next };
}

/** Every truce a player is in — used when they are broken or quit. */
export function clearTrucesFor(state: EmpireState, memberId: string): EmpireState {
  const next = clone(state);
  next.truces = next.truces.filter(
    (pair) => !pair.split("|").includes(memberId)
  );
  return next;
}

export { EMPIRE_WARS_CONFIG };
