import {
  BOARD_TILE_COUNT,
  BOSS_MODIFIERS,
  COSTS,
  DISTRICTS,
  HEAT,
  RESPECT,
  TERRITORIES,
  type DistrictId,
} from "@/lib/game/data/empire-wars";
import {
  cashIncome,
  clampHeat,
  clampRespect,
  completedDistricts,
  currentPrice,
  dirtyIncome,
  empireValue,
  heatBand,
  isMostWanted,
  launderRate,
  playerOf,
  protectionFee,
  rollD6,
  territoriesOf,
  territoryDef,
  upgradeCost,
  upkeepHeatDelta,
  type EmpirePlayer,
  type EmpireState,
  type EmpireTransition,
  type TerritoryState,
} from "@/lib/game/empire-wars/rules";

// The economic loop: movement, income, laundering, protection, upkeep Heat,
// raids and the Most Wanted sweep. Pure — RNG is always injected.
//
// This is the half of the game the anti-runaway brake lives in, and it is
// deliberately implemented and testable before combat, missions or UI exist
// (GDD > Heat; ADR-0005 Amendment 1).

function clone(state: EmpireState): EmpireState {
  return structuredClone(state);
}

// ─── Bonuses ─────────────────────────────────────────────────────────────────

type DistrictBonus = (typeof DISTRICTS)[number]["bonus"];

/** Does this player hold a full district granting `bonus`? */
export function hasDistrictBonus(
  state: EmpireState,
  memberId: string,
  bonus: DistrictBonus
): boolean {
  const owned = new Set<DistrictId>(completedDistricts(state, memberId));
  return DISTRICTS.some((d) => d.bonus === bonus && owned.has(d.id));
}

/**
 * Multiplier applied to the Dirty Money income option.
 *
 * Harbor's district power and the Drug Lord's passive are **additive** with
 * each other (+50% and +25% give ×1.75, not ×1.875). Multiplying them would
 * make one specific pairing sharply better than either alone, which is the
 * kind of hidden combo that quietly decides a match.
 */
export function dirtyIncomeMultiplier(
  state: EmpireState,
  player: EmpirePlayer
): number {
  let boost = 0;
  if (hasDistrictBonus(state, player.id, "dirty-income-boost")) {
    boost += BOSS_MODIFIERS.harborDirtyBoost;
  }
  if (player.boss === "drug-lord") boost += BOSS_MODIFIERS.drugLordDirtyBoost;
  return 1 + boost;
}

/** Crew price after the better of Old Town and Street Boss — they don't stack. */
export function crewCost(
  state: EmpireState,
  player: EmpirePlayer,
  currency: "cash" | "dirty"
): number {
  const base = currency === "cash" ? COSTS.crewCash : COSTS.crewDirty;
  const discount = Math.max(
    hasDistrictBonus(state, player.id, "crew-discount")
      ? BOSS_MODIFIERS.oldTownCrewDiscount
      : 0,
    player.boss === "street-boss" ? BOSS_MODIFIERS.streetBossCrewDiscount : 0
  );
  return Math.round(base * (1 - discount));
}

// ─── Movement ────────────────────────────────────────────────────────────────

/** Advance clockwise, reporting whether The Docks (tile 0) was passed or hit. */
export function advanceToken(
  from: number,
  steps: number
): { tile: number; passedDocks: boolean } {
  const tile = (from + steps) % BOARD_TILE_COUNT;
  // Wrapping past 31 → 0 is the only way to reach The Docks going clockwise.
  return { tile, passedDocks: from + steps >= BOARD_TILE_COUNT };
}

// ─── Income ──────────────────────────────────────────────────────────────────

/** Per-territory: true takes the Dirty option where one is offered. */
export type IncomeChoice = (territoryId: string) => boolean;

export type IncomeResult = {
  state: EmpireState;
  cash: number;
  dirty: number;
  respect: number;
};

/**
 * Collect a lap's income, plus the Docks stipend.
 *
 * Order matters and is fixed here: the Watched penalty applies to illegal
 * tiles *before* any Dirty multiplier, so a player cannot out-earn police
 * attention simply by owning The Harbor.
 */
export function collectIncome(
  state: EmpireState,
  memberId: string,
  takeDirty: IncomeChoice,
  opts: { stipend?: boolean } = {}
): IncomeResult {
  const next = clone(state);
  const player = playerOf(next, memberId);
  if (!player) return { state: next, cash: 0, dirty: 0, respect: 0 };

  const band = heatBand(player.heat);
  const watched = band !== "clean";
  const federal = band === "federal";
  const dirtyMult = dirtyIncomeMultiplier(next, player);

  // The stipend is the lap reward; territory income may arrive more often.
  let cash = opts.stipend === false ? 0 : COSTS.docksStipend;
  let dirty = 0;

  for (const territory of territoriesOf(next, memberId)) {
    const def = territoryDef(territory.id);
    const penalty =
      watched && def.tier === "illegal" ? 1 - HEAT.watchedIllegalPenalty : 1;

    const dirtyOffer = dirtyIncome(territory);
    // Federal blocks the Dirty option outright, everywhere.
    const wantsDirty = !federal && dirtyOffer !== null && takeDirty(territory.id);

    if (wantsDirty && dirtyOffer !== null) {
      dirty += Math.round(dirtyOffer * penalty * dirtyMult);
    } else {
      cash += Math.round(cashIncome(territory) * penalty);
    }
  }

  let respect = 0;
  if (hasDistrictBonus(next, memberId, "respect-per-collection")) {
    respect = 1;
  }

  player.cash += cash;
  player.dirty += dirty;
  player.respect = clampRespect(player.respect + respect);
  return { state: next, cash, dirty, respect };
}

// ─── Laundering ──────────────────────────────────────────────────────────────

/**
 * Convert Dirty Money to Cash at a loss. Nightclub's district power also
 * clears 1 Heat, wherever you do it.
 */
export function launder(
  state: EmpireState,
  memberId: string,
  opts: { amount: number; atSafehouse: boolean; forced?: boolean }
): { state: EmpireState; cash: number } {
  const next = clone(state);
  const player = playerOf(next, memberId);
  if (!player) return { state: next, cash: 0 };

  const amount = Math.min(Math.max(0, Math.floor(opts.amount)), player.dirty);
  if (amount === 0) return { state: next, cash: 0 };

  const rate = launderRate({
    atSafehouse: opts.atSafehouse,
    ownsMoneyLaundry:
      territoriesOf(next, memberId).some((t) => t.id === "money-laundry"),
    isSmuggler: player.boss === "smuggler",
    forced: opts.forced,
  });

  const cash = Math.round(amount * rate);
  player.dirty -= amount;
  player.cash += cash;
  player.launderedTotal += amount;

  if (!opts.forced && hasDistrictBonus(next, memberId, "launder-clears-heat")) {
    player.heat = clampHeat(player.heat - 1);
  }
  return { state: next, cash };
}

// ─── Buying and declining ────────────────────────────────────────────────────

/** Buy at the current (possibly marked-down) price, scoring any district it completes. */
export function buyTerritory(
  state: EmpireState,
  memberId: string,
  territoryId: string
): EmpireTransition {
  const next = clone(state);
  const player = playerOf(next, memberId);
  const territory = next.territories.find((t) => t.id === territoryId);
  if (!player || !territory) return { ok: false, error: "No such territory" };
  if (territory.ownerId) return { ok: false, error: "Someone already owns that" };

  const price = currentPrice(territory);
  if (player.cash < price) return { ok: false, error: "You can't afford it" };

  const before = completedDistricts(next, memberId);
  player.cash -= price;
  territory.ownerId = memberId;
  return { ok: true, state: awardDistrictRespect(next, memberId, before) };
}

/** Declining marks the tile down 10% of list, cumulatively, floored at 50%. */
export function declineTerritory(
  state: EmpireState,
  territoryId: string
): EmpireState {
  const next = clone(state);
  const territory = next.territories.find((t) => t.id === territoryId);
  if (!territory || territory.ownerId) return next;
  const maxDeclines = Math.ceil(
    (1 - COSTS.declineFloor) / COSTS.declineMarkdown
  );
  territory.declines = Math.min(maxDeclines, territory.declines + 1);
  return next;
}

/**
 * Pay Respect for districts completed since `previouslyOwned` was measured.
 *
 * Everyone earns for completing a district; the Godfather earns double. The
 * baseline is required rather than optional — without it there is no way to
 * tell a district completed *now* from one completed ten turns ago, and an
 * optional parameter here would silently pay nothing or pay repeatedly
 * depending on the call site.
 */
function awardDistrictRespect(
  state: EmpireState,
  memberId: string,
  previouslyOwned: DistrictId[]
): EmpireState {
  const player = playerOf(state, memberId);
  if (!player) return state;
  const before = new Set(previouslyOwned);
  const fresh = completedDistricts(state, memberId).filter(
    (d) => !before.has(d)
  );
  if (fresh.length === 0) return state;
  const perDistrict =
    player.boss === "godfather"
      ? RESPECT.godfatherPerDistrictCompleted
      : RESPECT.perDistrictCompleted;
  player.respect = clampRespect(player.respect + fresh.length * perDistrict);
  return state;
}

// ─── Building ────────────────────────────────────────────────────────────────

/** Recruit one crew into the pool, in Cash or the cheaper Dirty Money. */
export function recruitCrew(
  state: EmpireState,
  memberId: string,
  currency: "cash" | "dirty"
): EmpireTransition {
  const next = clone(state);
  const player = playerOf(next, memberId);
  if (!player) return { ok: false, error: "You're not in this game" };

  const cost = crewCost(next, player, currency);
  if (currency === "cash") {
    if (player.cash < cost) return { ok: false, error: "You can't afford crew" };
    player.cash -= cost;
  } else {
    if (player.dirty < cost) return { ok: false, error: "You can't afford crew" };
    player.dirty -= cost;
  }
  player.poolCrew += 1;
  return { ok: true, state: next };
}

/** The cash price of the next level, or null when it is reached by garrisoning. */
export function nextLevelCost(
  state: EmpireState,
  memberId: string,
  territory: TerritoryState
): number | null {
  const nextLevel = territory.level + 1;
  if (nextLevel !== 3 && nextLevel !== 4 && nextLevel !== 5) return null;
  const base = upgradeCost(territory.id, nextLevel);
  const discount = hasDistrictBonus(state, memberId, "upgrade-discount")
    ? BOSS_MODIFIERS.industrialUpgradeDiscount
    : 0;
  return Math.round(base * (1 - discount));
}

/**
 * Advance a territory one level. Levels 2 and 5 consume a pool crew as the
 * garrison; 3, 4 and 5 also cost cash (Level 4 accepts Dirty Money).
 */
export function upgradeTerritory(
  state: EmpireState,
  memberId: string,
  territoryId: string
): EmpireTransition {
  const next = clone(state);
  const player = playerOf(next, memberId);
  const territory = next.territories.find((t) => t.id === territoryId);
  if (!player || !territory) return { ok: false, error: "No such territory" };
  if (territory.ownerId !== memberId) return { ok: false, error: "Not yours" };
  if (territory.level >= 5) return { ok: false, error: "Already a Fortress" };

  const nextLevel = (territory.level + 1) as 2 | 3 | 4 | 5;
  const needsGarrison = nextLevel === 2 || nextLevel === 5;
  if (needsGarrison && player.poolCrew < 1) {
    return { ok: false, error: "You need a crew to garrison" };
  }

  const cost = nextLevelCost(next, memberId, territory);
  if (cost !== null && player.cash < cost) {
    return { ok: false, error: "You can't afford that upgrade" };
  }

  if (cost !== null) player.cash -= cost;
  if (needsGarrison) {
    player.poolCrew -= 1;
    territory.garrison += 1;
  }
  territory.level = nextLevel;
  return { ok: true, state: next };
}

// ─── Protection ──────────────────────────────────────────────────────────────

/** What a visitor owes on this tile right now. */
export function feeFor(state: EmpireState, territory: TerritoryState): number {
  if (!territory.ownerId) return 0;
  const def = territoryDef(territory.id);
  const ownsDistrict = completedDistricts(state, territory.ownerId).includes(
    def.district
  );
  return protectionFee(territory, ownsDistrict);
}

/**
 * Hand over a protection fee. Returns `shortfall` when the visitor cannot
 * cover it — the caller runs the broken-not-bankrupt path.
 */
export function payProtection(
  state: EmpireState,
  visitorId: string,
  territoryId: string,
  multiplier = 1
): { state: EmpireState; paid: number; shortfall: number } {
  const next = clone(state);
  const territory = next.territories.find((t) => t.id === territoryId);
  const visitor = playerOf(next, visitorId);
  if (!territory || !visitor || !territory.ownerId) {
    return { state: next, paid: 0, shortfall: 0 };
  }
  const owner = playerOf(next, territory.ownerId);
  if (!owner) return { state: next, paid: 0, shortfall: 0 };

  const fee = Math.round(feeFor(next, territory) * multiplier);
  const paid = Math.min(fee, visitor.cash);
  visitor.cash -= paid;
  owner.cash += paid;
  return { state: next, paid, shortfall: fee - paid };
}

// ─── Upkeep, raids and the Most Wanted sweep ─────────────────────────────────

export type UpkeepResult = {
  state: EmpireState;
  heatDelta: number;
  raided: boolean;
  /** Territory id taken by a raid, when there was no Dirty Money to seize. */
  seized: string | null;
  confiscated: number;
  jailed: boolean;
};

/**
 * Start-of-turn upkeep: Heat accrues or sheds, then a raid may fire.
 *
 * A raid takes **all Dirty Money**. If there is none it seizes the player's
 * **lowest-level** territory instead — the rule that makes Heat mean something
 * to a player who never touches Dirty Money. It takes the least valuable tile
 * on purpose, so it bleeds a sprawling empire rather than decapitating it.
 */
export function runUpkeep(
  state: EmpireState,
  memberId: string,
  random: () => number
): UpkeepResult {
  const next = clone(state);
  const player = playerOf(next, memberId);
  if (!player) {
    return {
      state: next,
      heatDelta: 0,
      raided: false,
      seized: null,
      confiscated: 0,
      jailed: false,
    };
  }

  // Financial District halves the Heat that held Dirty Money generates.
  let heatDelta = upkeepHeatDelta(player);
  if (heatDelta > 0 && hasDistrictBonus(next, memberId, "half-dirty-heat")) {
    heatDelta = Math.floor(heatDelta / 2);
  }
  player.heat = clampHeat(player.heat + heatDelta);

  const band = heatBand(player.heat);
  let raided = false;
  let seized: string | null = null;
  let confiscated = 0;
  let jailed = false;

  if (band === "raids" || band === "federal") {
    const threshold =
      band === "federal" ? HEAT.federalRaidRollAtLeast : HEAT.raidRollAtLeast;
    if (rollD6(random) >= threshold) {
      raided = true;
      if (player.dirty > 0) {
        confiscated = player.dirty;
        player.dirty = 0;
      } else {
        const target = lowestLevelTerritory(next, memberId);
        if (target) {
          seized = target.id;
          target.ownerId = null;
          target.level = 1;
          target.garrison = 0;
        }
      }
      if (band === "federal") {
        jailed = true;
        player.jailTurns = 3;
        player.tile = 8;
      }
    }
  }

  return { state: next, heatDelta, raided, seized, confiscated, jailed };
}

/** Lowest level, then cheapest, then id — deterministic for seeded replay. */
function lowestLevelTerritory(
  state: EmpireState,
  memberId: string
): TerritoryState | null {
  const owned = territoriesOf(state, memberId);
  if (owned.length === 0) return null;
  return [...owned].sort((a, b) => {
    if (a.level !== b.level) return a.level - b.level;
    const priceDiff = territoryDef(a.id).price - territoryDef(b.id).price;
    if (priceDiff !== 0) return priceDiff;
    return a.id.localeCompare(b.id);
  })[0];
}

/**
 * End-of-round sweep: flag everyone above 1.25× the table mean and charge them
 * Heat for it. The flag persists on state because next round's upkeep reads it
 * to decide whether the clean shed applies.
 */
export function sweepMostWanted(state: EmpireState): EmpireState {
  const next = clone(state);
  for (const player of next.players) {
    if (player.eliminated) {
      player.mostWanted = false;
      continue;
    }
    const wanted = isMostWanted(next, player.id);
    player.mostWanted = wanted;
    if (wanted) player.heat = clampHeat(player.heat + HEAT.mostWantedHeat);
  }
  return next;
}

// ─── Broken, not bankrupt ────────────────────────────────────────────────────

export type BrokenResult = {
  state: EmpireState;
  broken: boolean;
  surrendered: string | null;
};

/**
 * Settle a debt the player cannot cover in Cash.
 *
 * Dirty Money is force-laundered at the worst rate first — if that covers it,
 * the player is **not** broken and loses nothing else. Otherwise their highest
 * value territory goes to the creditor, they take a Respect hit and a capped
 * bailout, and play continues. There is no elimination.
 */
export function settleDebt(
  state: EmpireState,
  memberId: string,
  debt: number,
  creditorId: string | null
): BrokenResult {
  let next = clone(state);
  const player = playerOf(next, memberId);
  if (!player) return { state: next, broken: false, surrendered: null };

  let owed = debt - player.cash;
  if (owed <= 0) {
    player.cash -= debt;
    return { state: next, broken: false, surrendered: null };
  }

  if (player.dirty > 0) {
    next = launder(next, memberId, {
      amount: player.dirty,
      atSafehouse: false,
      forced: true,
    }).state;
    const after = playerOf(next, memberId)!;
    owed = debt - after.cash;
    if (owed <= 0) {
      after.cash -= debt;
      return { state: next, broken: false, surrendered: null };
    }
  }

  const broke = playerOf(next, memberId)!;
  broke.cash = 0;

  const best = [...territoriesOf(next, memberId)].sort(
    (a, b) => territoryDef(b.id).price - territoryDef(a.id).price
  )[0];
  let surrendered: string | null = null;
  if (best) {
    surrendered = best.id;
    best.ownerId = creditorId;
    best.garrison = 0;
    if (!creditorId) best.level = 1;
  }

  broke.respect = clampRespect(broke.respect - 3);
  if (broke.bailoutsTaken < 2) {
    broke.cash += 500;
    broke.bailoutsTaken += 1;
  }
  return { state: next, broken: true, surrendered };
}

/** Total Empire Value across active seats — used by the simulation harness. */
export function tableValues(state: EmpireState): Array<{ id: string; ev: number }> {
  return state.players
    .filter((p) => !p.eliminated)
    .map((p) => ({ id: p.id, ev: empireValue(state, p.id) }));
}

export { TERRITORIES };
