import type { GameModule, MoveContext, Standing } from "@/lib/game/module";
import { EMPIRE_WARS_CONFIG } from "@/lib/game/data/empire-wars";
import { MISSION_IDS, EVENT_IDS } from "@/lib/game/data/empire-wars-content";
import {
  currentPlayer,
  dealGame,
  empireValue,
  parseState,
  standingsOrder,
  territoriesOf,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";
import {
  applyMove,
  applyQuit,
  empireMoveSchema,
  turnHasExpired,
  type EmpireMove,
} from "@/lib/game/empire-wars/turn";
import { chooseBotMove } from "@/lib/game/empire-wars/bot";
import { viewFor, type EmpireView } from "@/lib/game/empire-wars/view";

// Empire Wars as a platform game module (ADR-0005). An adapter and nothing
// more — every rule lives in rules/economy/combat/turn, which stay free of
// platform concepts and are what the test suite exercises directly.

/** Money is formatted, not raw, so the platform never has to know the units. */
function money(value: number): string {
  return `$${value.toLocaleString("en-US")}`;
}

function standings(state: EmpireState): Standing[] {
  return standingsOrder(state).map((memberId) => {
    const player = state.players.find((p) => p.id === memberId)!;
    const won = state.winnerId === memberId;
    return {
      memberId,
      detail: player.eliminated
        ? "walked away"
        : won && state.kingpin
          ? "Kingpin"
          : `${money(empireValue(state, memberId))} empire`,
      eliminated: player.eliminated,
    };
  });
}

export const empireWarsModule: GameModule<EmpireState, EmpireView, EmpireMove> = {
  id: EMPIRE_WARS_CONFIG.gameType,
  moveSchema: empireMoveSchema,
  parseState,

  deal: (memberIds, ctx: MoveContext) =>
    dealGame(memberIds, ctx.random, {
      missionIds: [...MISSION_IDS],
      eventIds: [...EVENT_IDS],
    }),

  viewFor,

  apply: (state, memberId, move, ctx) => applyMove(state, memberId, move, ctx),

  quit: (state, memberId) => applyQuit(state, memberId),

  botMove: (state, memberId, ctx) => chooseBotMove(state, memberId, ctx),

  /**
   * Whoever owes the next action. While a decision is pending that is its
   * named answerer, not the seat whose turn it is — which is exactly what lets
   * the platform drive a bot through someone else's open choice.
   */
  currentMemberId: (state) => {
    if (state.winnerId) return null;
    if (state.pending) return state.pending.memberId;
    return currentPlayer(state)?.id ?? null;
  },

  winnerId: (state) => state.winnerId,

  standings,

  turnExpired: (state, now) => turnHasExpired(state, now),
};

export { territoriesOf };
