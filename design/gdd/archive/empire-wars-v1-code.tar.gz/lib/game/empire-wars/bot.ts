import { BOT, COSTS, HEAT, KINGPIN } from "@/lib/game/data/empire-wars";
import {
  attackStrength,
  completedDistricts,
  currentPlayer,
  currentPrice,
  empireValue,
  playerOf,
  territoriesOf,
  territoryAtTile,
  territoryDef,
  tileDefence,
  type EmpirePlayer,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";
import { nextLevelCost } from "@/lib/game/empire-wars/economy";
import { strikeTargets, turfWarTargets } from "@/lib/game/empire-wars/combat";
import type { EmpireMove, MoveCtx } from "@/lib/game/empire-wars/turn";

// Utility-heuristic bot. Every threshold lives in BOT (lib/game/data), so
// tuning never touches this file.
//
// The contract that matters: **a bot must be able to answer every pending
// decision**, or a table with an empty seat deadlocks. With auctions cut there
// are only two kinds, both single-answerer, which is what makes that tractable.

/** price × level multiplier, plus a bonus when buying would close a district. */
function assessedValue(state: EmpireState, memberId: string, territoryId: string) {
  const def = territoryDef(territoryId);
  const territory = state.territories.find((t) => t.id === territoryId)!;
  const base = def.price;
  const completes = wouldCompleteDistrict(state, memberId, territoryId);
  return base + (completes ? BOT.districtBonusWeight : 0) + territory.level * 50;
}

function wouldCompleteDistrict(
  state: EmpireState,
  memberId: string,
  territoryId: string
): boolean {
  const district = territoryDef(territoryId).district;
  const inDistrict = state.territories.filter(
    (t) => territoryDef(t.id).district === district
  );
  return inDistrict.every((t) => t.id === territoryId || t.ownerId === memberId);
}

/** A rival whose Empire Value exceeds the bot's by more than the margin. */
function strongerThan(
  state: EmpireState,
  memberId: string
): EmpirePlayer[] {
  const mine = empireValue(state, memberId);
  return state.players
    .filter((p) => p.id !== memberId && !p.eliminated)
    .filter((p) => empireValue(state, p.id) > mine * (1 + BOT.strongerMargin));
}

/**
 * The move this seat would make now, or null when there is nothing to do.
 *
 * Ordered by urgency: answer anything pending, get out of jail, take the tile
 * you are standing on, spend the action die, then build, then end the turn.
 */
export function chooseBotMove(
  state: EmpireState,
  memberId: string,
  ctx: MoveCtx
): EmpireMove | null {
  // The bot only *chooses*; every roll it triggers is made by the rules with
  // the server's rng, so it needs no randomness of its own. The parameter
  // stays to satisfy the GameModule contract.
  void ctx;
  if (state.winnerId) return null;
  const me = playerOf(state, memberId);
  if (!me || me.eliminated) return null;

  // ── Pending decisions come first, always ──────────────────────────────────
  const pending = state.pending;
  if (pending) {
    if (pending.memberId !== memberId) return null;

    if (pending.kind === "protection") {
      const territory = state.territories.find(
        (t) => t.id === pending.territoryId
      );
      if (!territory) return { kind: "payFee" };
      // Refuse only with a real crew advantage over that tile's defence.
      const advantage = attackStrength(me) - tileDefence(territory);
      return advantage >= BOT.fightMargin
        ? { kind: "refuseFee" }
        : { kind: "payFee" };
    }

    // Accept a truce from someone stronger; otherwise stay free to attack.
    const accept = strongerThan(state, memberId).some(
      (p) => p.id === pending.fromMemberId
    );
    return { kind: "answerTruce", accept };
  }

  if (currentPlayer(state).id !== memberId) return null;

  // ── Jail ──────────────────────────────────────────────────────────────────
  if (me.jailTurns > 0 && state.phase === "roll") {
    if (me.cash >= COSTS.bail * BOT.bailCashMultiple) return { kind: "bail" };
    return { kind: "roll" };
  }

  if (state.phase === "roll") return { kind: "roll" };

  // ── Standing on an unowned tile ───────────────────────────────────────────
  const here = state.tileDone ? null : territoryAtTile(me.tile);
  if (here) {
    const territory = state.territories.find((t) => t.id === here.id)!;
    if (!territory.ownerId) {
      const price = currentPrice(territory);
      const worth = assessedValue(state, memberId, here.id);
      const affordable = me.cash - price >= BOT.cashFloor;
      if (affordable && (wouldCompleteDistrict(state, memberId, here.id) || worth >= BOT.buyThreshold)) {
        return { kind: "buy" };
      }
      return { kind: "decline" };
    }
  }

  // ── The action die ────────────────────────────────────────────────────────
  if (state.phase === "act" && state.dieFace) {
    switch (state.dieFace) {
      case "gun": {
        const targets = strikeTargets(state, memberId);
        // Hit the strongest seat this bot actually beats on crew.
        const best = targets
          .map((id) => playerOf(state, id)!)
          .filter((p) => attackStrength(me) - attackStrength(p) >= BOT.fightMargin)
          .sort((a, b) => empireValue(state, b.id) - empireValue(state, a.id))[0];
        return best ? { kind: "strike", targetId: best.id } : { kind: "skipDie" };
      }
      case "handshake": {
        const target = strongerThan(state, memberId).sort(
          (a, b) => empireValue(state, b.id) - empireValue(state, a.id)
        )[0];
        return target
          ? { kind: "offerTruce", targetId: target.id }
          : { kind: "skipDie" };
      }
      case "car": {
        // Only worth it to reach a tile worth buying.
        for (let extra = 1; extra <= 3; extra++) {
          const def = territoryAtTile((me.tile + extra) % 32);
          if (!def) continue;
          const t = state.territories.find((x) => x.id === def.id)!;
          if (!t.ownerId && me.cash - currentPrice(t) >= BOT.cashFloor) {
            return { kind: "useCar", extra };
          }
        }
        return { kind: "skipDie" };
      }
      default:
        return { kind: "skipDie" };
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  if (state.phase === "build") {
    if (me.dirty > 0 && me.heat >= BOT.launderHeat) {
      return { kind: "launderMoney", amount: me.dirty };
    }

    if (me.heat >= BOT.bribeHeat && me.cash >= 600 + BOT.cashFloor) {
      const tile = territoryAtTile(me.tile);
      if (!tile && isCityHall(me.tile)) return { kind: "bribe", tier: 1 };
    }

    // Kingpin is close enough to buy the last Respect for.
    if (
      isCityHall(me.tile) &&
      completedDistricts(state, memberId).length >= KINGPIN.districts &&
      me.respect < KINGPIN.respect &&
      me.heat < KINGPIN.maxHeat &&
      me.cash >= COSTS.respectPrice * 3 + BOT.cashFloor
    ) {
      const need = Math.min(3, KINGPIN.respect - me.respect);
      return { kind: "buyRespect", points: need };
    }

    if (!state.turfWarUsed) {
      const target = turfWarTargets(state, memberId)
        .map((id) => ({
          id,
          tile: state.territories.find((t) => t.id === id)!,
        }))
        .filter(
          ({ id, tile }) =>
            attackStrength(me) - tileDefence(tile) >= BOT.fightMargin &&
            (wouldCompleteDistrict(state, memberId, id) ||
              territoryDef(id).tier === "landmark")
        )
        .sort(
          (a, b) => assessedValue(state, memberId, b.id) - assessedValue(state, memberId, a.id)
        )[0];
      if (target) return { kind: "turfWar", territoryId: target.id };
    }

    const upgrade = bestUpgrade(state, memberId);
    if (upgrade) return upgrade;

    if (me.poolCrew < BOT.poolCrewFloor && me.cash - COSTS.crewCash >= BOT.cashFloor) {
      return { kind: "recruit", currency: "cash" };
    }

    return { kind: "endTurn" };
  }

  return { kind: "endTurn" };
}

function isCityHall(tile: number): boolean {
  return tile === 20;
}

/** Cheapest next level first, garrisoning where that is what's missing. */
function bestUpgrade(state: EmpireState, memberId: string): EmpireMove | null {
  const me = playerOf(state, memberId)!;
  const candidates = territoriesOf(state, memberId)
    .filter((t) => t.level < 5)
    .map((t) => ({ t, cost: nextLevelCost(state, memberId, t) }))
    .sort((a, b) => (a.cost ?? 0) - (b.cost ?? 0));

  for (const { t, cost } of candidates) {
    const needsGarrison = t.level + 1 === 2 || t.level + 1 === 5;
    if (needsGarrison) {
      if (me.poolCrew < 1) continue;
      if (cost !== null && me.cash - cost < BOT.cashFloor) continue;
      return { kind: "upgrade", territoryId: t.id };
    }
    if (cost !== null && me.cash - cost >= BOT.cashFloor) {
      return { kind: "upgrade", territoryId: t.id };
    }
  }

  // Nothing affordable to upgrade — recruit toward the next garrison instead.
  const wantsGarrison = candidates.some(
    ({ t }) => t.level + 1 === 2 || t.level + 1 === 5
  );
  if (
    wantsGarrison &&
    me.poolCrew < 1 &&
    me.cash - COSTS.crewCash >= BOT.cashFloor
  ) {
    return { kind: "recruit", currency: "cash" };
  }
  return null;
}

export { HEAT };
