import { EMPIRE_WARS_CONFIG, HEAT } from "@/lib/game/data/empire-wars";
import {
  currentPrice,
  dealGame,
  empireValue,
  heatBand,
  playerOf,
  rollD6,
  territoriesOf,
  territoryAtTile,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";
import {
  advanceToken,
  buyTerritory,
  collectIncome,
  declineTerritory,
  feeFor,
  launder,
  nextLevelCost,
  payProtection,
  recruitCrew,
  runUpkeep,
  settleDebt,
  sweepMostWanted,
  upgradeTerritory,
} from "@/lib/game/empire-wars/economy";

/**
 * An **economic** simulation of a match, used to answer one question the
 * design cannot answer on paper: does the Heat brake actually hold a leader
 * down? (GDD > Heat; Open Questions.)
 *
 * It models movement, buying, protection payments, income with the cash/dirty
 * choice, laundering, upkeep Heat, raids with territory seizure, and the Most
 * Wanted sweep.
 *
 * It deliberately **omits** combat, missions, events, bribes, truces and turf
 * wars. Those move Heat and money too, so absolute numbers here are a floor,
 * not a forecast. What it is valid for is the *relative* question: whether the
 * richest seat accumulates Heat and gets bled, or sails through untouched.
 */

export type SimPolicy = {
  /** Take Dirty income while Heat is at or below this. */
  dirtyHeatCap: number;
  /** Launder everything at or above this Heat. */
  launderHeat: number;
  /** Never spend below this much cash. */
  cashFloor: number;
};

export const DEFAULT_POLICY: SimPolicy = {
  dirtyHeatCap: 3,
  launderHeat: 6,
  cashFloor: 400,
};

/** A policy that never touches Dirty Money — the case the brake must handle. */
export const CLEAN_POLICY: SimPolicy = {
  dirtyHeatCap: -1,
  launderHeat: 0,
  cashFloor: 400,
};

export type SimResult = {
  rounds: number;
  players: Array<{
    id: string;
    empireValue: number;
    heat: number;
    territories: number;
    cash: number;
    dirty: number;
    /** Rounds this seat spent flagged Most Wanted. */
    roundsMostWanted: number;
    /** Peak Heat reached at any point. */
    peakHeat: number;
    raids: number;
    seizures: number;
  }>;
  /** Seat ids ordered by final Empire Value, richest first. */
  ranking: string[];
};

const MISSIONS = Array.from({ length: 10 }, (_, i) => `m${i + 1}`);
const EVENTS = Array.from({ length: 8 }, (_, i) => `e${i + 1}`);

/**
 * Play a full match economically. `policies` may differ per seat, which is how
 * the "rich clean player" case is isolated.
 */
export function simulateMatch(opts: {
  seats: number;
  random: () => number;
  policies?: SimPolicy[];
  rounds?: number;
}): SimResult {
  const { random } = opts;
  const seatIds = Array.from({ length: opts.seats }, (_, i) => `seat-${i + 1}`);
  const rounds = opts.rounds ?? EMPIRE_WARS_CONFIG.roundLimit;
  const policyFor = (id: string) =>
    opts.policies?.[seatIds.indexOf(id)] ?? DEFAULT_POLICY;

  let state = dealGame(seatIds, random, {
    missionIds: MISSIONS,
    eventIds: EVENTS,
  });

  const stats = new Map(
    seatIds.map((id) => [
      id,
      { roundsMostWanted: 0, peakHeat: 0, raids: 0, seizures: 0 },
    ])
  );

  for (let round = 1; round <= rounds; round++) {
    for (const seatId of seatIds) {
      const before = playerOf(state, seatId);
      if (!before || before.eliminated) continue;

      // 1. Upkeep — Heat accrues or sheds, a raid may fire.
      const upkeep = runUpkeep(state, seatId, random);
      state = upkeep.state;
      const s = stats.get(seatId)!;
      if (upkeep.raided) s.raids++;
      if (upkeep.seized) s.seizures++;

      const player = playerOf(state, seatId)!;
      s.peakHeat = Math.max(s.peakHeat, player.heat);

      // Jail: serve the turn, no movement, no income.
      if (player.jailTurns > 0) {
        player.jailTurns -= 1;
        if (player.jailTurns === 0) player.heat = HEAT.jailRelease;
        continue;
      }

      // 2. Move.
      const steps = rollD6(random) + rollD6(random);
      const moved = advanceToken(player.tile, steps);
      player.tile = moved.tile;

      // 3. Collect income — every round, or only on a lap (see the knob).
      const collectNow =
        EMPIRE_WARS_CONFIG.incomeEveryRound || moved.passedDocks;
      if (collectNow) {
        const policy = policyFor(seatId);
        state = collectIncome(
          state,
          seatId,
          () => player.heat <= policy.dirtyHeatCap,
          { stipend: moved.passedDocks }
        ).state;
      }

      // 4. Resolve the tile.
      state = resolveTile(state, seatId, random);

      // 5. Launder if hot.
      const after = playerOf(state, seatId)!;
      const policy = policyFor(seatId);
      if (after.dirty > 0 && after.heat >= policy.launderHeat) {
        state = launder(state, seatId, {
          amount: after.dirty,
          atSafehouse: after.tile === 16,
        }).state;
      }

      // 6. Build — the primary engine of Empire Value growth, so a model that
      //    skipped it would badly understate both wealth and the spread the
      //    Most Wanted threshold is measured against.
      state = build(state, seatId, policy);
    }

    // End of round — flag and charge the leaders.
    state = sweepMostWanted(state);
    for (const seatId of seatIds) {
      const p = playerOf(state, seatId);
      if (!p) continue;
      const s = stats.get(seatId)!;
      if (p.mostWanted) s.roundsMostWanted++;
      s.peakHeat = Math.max(s.peakHeat, p.heat);
    }
    state = { ...state, round };
  }

  const players = seatIds.map((id) => {
    const p = playerOf(state, id)!;
    const s = stats.get(id)!;
    return {
      id,
      empireValue: empireValue(state, id),
      heat: p.heat,
      territories: territoriesOf(state, id).length,
      cash: p.cash,
      dirty: p.dirty,
      ...s,
    };
  });

  return {
    rounds,
    players,
    ranking: [...players]
      .sort((a, b) => b.empireValue - a.empireValue)
      .map((p) => p.id),
  };
}

/**
 * Spend surplus cash on the empire: garrison to Level 2, then pay for the
 * cheapest available upgrade, recruiting crew when a garrison is what's
 * missing. Greedy and simple — a real bot will do better, which makes these
 * numbers a floor.
 */
function build(
  state: EmpireState,
  seatId: string,
  policy: SimPolicy
): EmpireState {
  let next = state;
  // Bounded so a very rich seat cannot upgrade its whole empire in one turn.
  for (let step = 0; step < 3; step++) {
    const player = playerOf(next, seatId)!;
    const owned = territoriesOf(next, seatId).filter((t) => t.level < 5);
    if (owned.length === 0) break;

    // Cheapest next level first — best income per dollar early on.
    const candidates = owned
      .map((t) => ({ t, cost: nextLevelCost(next, seatId, t) }))
      .sort((a, b) => (a.cost ?? 0) - (b.cost ?? 0));

    let acted = false;
    for (const { t, cost } of candidates) {
      const needsGarrison = t.level + 1 === 2 || t.level + 1 === 5;
      if (needsGarrison && player.poolCrew < 1) {
        const crew = recruitCrew(next, seatId, "cash");
        if (!crew.ok) continue;
        const afterCrew = playerOf(crew.state, seatId)!;
        if (afterCrew.cash < policy.cashFloor) continue;
        next = crew.state;
      }
      const priceOk =
        cost === null || playerOf(next, seatId)!.cash - cost >= policy.cashFloor;
      if (!priceOk) continue;
      const up = upgradeTerritory(next, seatId, t.id);
      if (up.ok) {
        next = up.state;
        acted = true;
        break;
      }
    }
    if (!acted) break;
  }
  return next;
}

/** Buy if affordable above the cash floor; pay any protection owed. */
function resolveTile(
  state: EmpireState,
  seatId: string,
  random: () => number
): EmpireState {
  const player = playerOf(state, seatId)!;
  const def = territoryAtTile(player.tile);
  if (!def) return state;

  const territory = state.territories.find((t) => t.id === def.id)!;

  if (!territory.ownerId) {
    const price = currentPrice(territory);
    if (player.cash - price >= DEFAULT_POLICY.cashFloor) {
      const bought = buyTerritory(state, seatId, def.id);
      return bought.ok ? bought.state : state;
    }
    return declineTerritory(state, def.id);
  }

  if (territory.ownerId === seatId) return state;

  // Always pay — refusing is a combat decision, out of scope here.
  const fee = feeFor(state, territory);
  if (player.cash >= fee) {
    return payProtection(state, seatId, def.id).state;
  }
  // Can't cover it: the broken-not-bankrupt path settles the debt.
  const settled = settleDebt(state, seatId, fee, territory.ownerId);
  void random;
  return settled.state;
}

/** Summary of one seat's Heat exposure, for reporting. */
export function heatSummary(result: SimResult) {
  const leader = result.players.find((p) => p.id === result.ranking[0])!;
  return {
    leaderId: leader.id,
    leaderEv: leader.empireValue,
    leaderPeakHeat: leader.peakHeat,
    leaderRoundsMostWanted: leader.roundsMostWanted,
    leaderRaids: leader.raids,
    leaderSeizures: leader.seizures,
    leaderBand: heatBand(leader.peakHeat),
  };
}
