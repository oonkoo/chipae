import { DISTRICTS, EMPIRE_WARS_CONFIG, KINGPIN } from "@/lib/game/data/empire-wars";
import { missionById } from "@/lib/game/data/empire-wars-content";
import {
  attackStrength,
  cashIncome,
  completedDistricts,
  currentPlayer,
  currentPrice,
  empireValue,
  heatBand,
  isMostWanted,
  playerOf,
  standingsOrder,
  territoriesOf,
  territoryDef as territoryDefOf,
  tileDefence,
  type EmpireState,
  type HeatBand,
} from "@/lib/game/empire-wars/rules";
import { feeFor } from "@/lib/game/empire-wars/economy";
import { strikeTargets, turfWarTargets } from "@/lib/game/empire-wars/combat";

/**
 * What one seat is allowed to know (ADR-0005).
 *
 * The visibility model, from the GDD's Acceptance Criteria:
 *
 *   PUBLIC   ownership and levels, garrison sizes, pool crew counts, Respect,
 *            Heat (exact) and the Most Wanted badge, revealed missions
 *   PRIVATE  exact Cash, exact Dirty Money, missions still in hand
 *
 * Respect and Heat are public on purpose — they are reputation and notoriety,
 * and a hidden Heat track would make the Most Wanted drama invisible. Money is
 * private so the standoff stays a real read: you never quite know whether they
 * can afford to pay.
 */

export type PublicSeat = {
  memberId: string;
  respect: number;
  heat: number;
  heatBand: HeatBand;
  mostWanted: boolean;
  /** Combat dice they would bring to an attack. */
  crew: number;
  territories: number;
  districts: number;
  tile: number;
  inJail: boolean;
  eliminated: boolean;
  /** Missions they have completed, face-up. */
  completedMissions: string[];
};

export type TerritoryView = {
  id: string;
  name: string;
  district: string;
  tier: string;
  ownerId: string | null;
  level: number;
  garrison: number;
  /** Defence dice this tile fields right now. */
  defence: number;
  /** Price after any decline mark-down; null once owned. */
  price: number | null;
  /** What a visitor would owe; 0 when unowned. */
  fee: number;
  /** Cash this pays its owner each round — what a purchase is actually worth. */
  income: number;
  /** Human-readable district, so the UI never has to map ids to names. */
  districtName: string;
};

export type EmpireView = {
  round: number;
  roundLimit: number;
  phase: EmpireState["phase"];
  currentMemberId: string;
  dieFace: EmpireState["dieFace"];
  /** What the last roll was, so the board can show and animate it. */
  lastRoll: EmpireState["lastRoll"];
  /**
   * Bumped on every applied move. Clients that drive bots key their timers on
   * this — a bot's turn is several moves, and anything coarser (phase, round)
   * stops changing mid-turn and leaves the table hanging.
   */
  version: number;
  /** When the seat on the clock runs out of time, epoch ms. */
  turnExpiresAt: number | null;
  winnerId: string | null;
  kingpin: boolean;
  log: string[];

  territories: TerritoryView[];
  seats: PublicSeat[];
  truces: string[];

  /** The open decision, if any — including its deadline for the countdown. */
  pending: {
    kind: "protection" | "truce";
    memberId: string;
    expiresAt: number;
    fee?: number;
    territoryId?: string;
    fromMemberId?: string;
  } | null;

  /** Null when the viewer is a spectator rather than a seat. */
  you: {
    memberId: string;
    cash: number;
    dirty: number;
    /** Heat this seat will take at upkeep for the Dirty it is holding. */
    dirtyHeatPerRound: number;
    poolCrew: number;
    enforcers: number;
    boss: string;
    missions: Array<{ id: string; text: string; completed: boolean }>;
    empireValue: number;
    canBuyHere: { territoryId: string; price: number } | null;
    strikeTargets: string[];
    turfWarTargets: string[];
    kingpinProgress: { districts: number; respect: number; heat: number };
  } | null;
};

export function viewFor(
  state: EmpireState,
  memberId: string | null
): EmpireView {
  const seats: PublicSeat[] = state.players.map((p) => ({
    memberId: p.id,
    respect: p.respect,
    heat: p.heat,
    heatBand: heatBand(p.heat),
    mostWanted: p.mostWanted || isMostWanted(state, p.id),
    crew: attackStrength(p),
    territories: territoriesOf(state, p.id).length,
    districts: completedDistricts(state, p.id).length,
    tile: p.tile,
    inJail: p.jailTurns > 0,
    eliminated: p.eliminated,
    completedMissions: p.missions.filter((m) => m.completed).map((m) => m.id),
  }));

  const territories: TerritoryView[] = state.territories.map((t) => {
    const def = territoryDefOf(t.id);
    return {
      id: t.id,
      name: def.name,
      district: def.district,
      tier: def.tier,
      ownerId: t.ownerId,
      level: t.level,
      garrison: t.garrison,
      defence: tileDefence(t),
      price: t.ownerId ? null : currentPrice(t),
      fee: t.ownerId ? feeFor(state, t) : 0,
      income: cashIncome(t),
      districtName: DISTRICTS.find((d) => d.id === def.district)?.name ?? "",
    };
  });

  const me = memberId ? playerOf(state, memberId) : null;

  return {
    round: state.round,
    roundLimit: EMPIRE_WARS_CONFIG.roundLimit,
    phase: state.phase,
    currentMemberId: currentPlayer(state)?.id ?? "",
    dieFace: state.dieFace,
    lastRoll: state.lastRoll,
    version: state.version,
    turnExpiresAt: state.turnExpiresAt,
    winnerId: state.winnerId,
    kingpin: state.kingpin,
    log: state.log,
    territories,
    seats,
    truces: state.truces,
    pending: state.pending
      ? state.pending.kind === "protection"
        ? {
            kind: "protection",
            memberId: state.pending.memberId,
            expiresAt: state.pending.expiresAt,
            fee: state.pending.fee,
            territoryId: state.pending.territoryId,
          }
        : {
            kind: "truce",
            memberId: state.pending.memberId,
            expiresAt: state.pending.expiresAt,
            fromMemberId: state.pending.fromMemberId,
          }
      : null,
    you: me
      ? {
          memberId: me.id,
          cash: me.cash,
          dirty: me.dirty,
          dirtyHeatPerRound: Math.floor(me.dirty / 400),
          poolCrew: me.poolCrew,
          enforcers: me.enforcers,
          boss: me.boss,
          missions: me.missions.map((m) => ({
            id: m.id,
            text: missionById(m.id)?.text ?? m.id,
            completed: m.completed,
          })),
          empireValue: empireValue(state, me.id),
          canBuyHere: buyableAt(state, me.id),
          strikeTargets: strikeTargets(state, me.id),
          turfWarTargets: turfWarTargets(state, me.id),
          kingpinProgress: {
            districts: completedDistricts(state, me.id).length,
            respect: me.respect,
            heat: me.heat,
          },
        }
      : null,
  };
}

/**
 * The tile under this player, if they may still buy it.
 *
 * `tileDone` matters: buying and declining are both once-per-landing, so once
 * the tile is settled the offer has to disappear. Without that check the board
 * kept showing "…is for sale" after a pass — and the server rightly rejected
 * the click with "You've already settled this tile", which reads as a bug to
 * whoever pressed it.
 */
function buyableAt(state: EmpireState, memberId: string) {
  if (state.tileDone) return null;
  const player = playerOf(state, memberId);
  if (!player) return null;
  // Only the seat on the clock is standing on a tile it can act on.
  if (currentPlayer(state)?.id !== memberId) return null;
  const territory = state.territories.find(
    (t) => territoryDefOf(t.id).tile === player.tile && !t.ownerId
  );
  if (!territory) return null;
  return { territoryId: territory.id, price: currentPrice(territory) };
}

export { KINGPIN, standingsOrder };
