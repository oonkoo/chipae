import { z } from "zod";
import {
  BRIBE_TIERS,
  COSTS,
  EMPIRE_WARS_CONFIG,
  HEAT,
  JAIL,
  KINGPIN,
  RESPECT,
  SPECIAL_TILES,
  type SpecialTileKind,
} from "@/lib/game/data/empire-wars";
import {
  ACTION_DIE_FACES,
  clampHeat,
  clampRespect,
  currentPlayer,
  isKingpin,
  playerOf,
  rollActionDie,
  rollD6,
  standingsOrder,
  territoriesOf,
  territoryAtTile,
  territoryDef,
  type EmpireState,
  type EmpireTransition,
} from "@/lib/game/empire-wars/rules";
import {
  advanceToken,
  buyTerritory,
  collectIncome,
  declineTerritory,
  feeFor,
  hasDistrictBonus,
  launder,
  payProtection,
  recruitCrew,
  runUpkeep,
  settleDebt,
  sweepMostWanted,
  upgradeTerritory,
} from "@/lib/game/empire-wars/economy";
import { applyEvent, settleMissions } from "@/lib/game/empire-wars/progress";
import {
  acceptTruce,
  breakTruce,
  canOfferTruce,
  clearTrucesFor,
  resolveStandoff,
  resolveStrike,
  resolveTurfWar,
  strikeTargets,
} from "@/lib/game/empire-wars/combat";

// The turn engine: one move in, one state out. Every rule in the GDD's turn
// structure lives here, and nothing else in the game advances the clock.
//
// A turn runs roll → act → build → end. Upkeep is not a phase; it runs
// automatically when a turn opens. A pending decision freezes everything until
// it is answered or expires (GDD > Pending decisions).

const idSchema = z.string().min(1).max(64);

export const empireMoveSchema = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("roll") }),
  z.object({ kind: z.literal("buy") }),
  z.object({ kind: z.literal("decline") }),
  z.object({ kind: z.literal("payFee") }),
  z.object({ kind: z.literal("refuseFee") }),
  z.object({ kind: z.literal("useCar"), extra: z.number().int().min(1).max(3) }),
  z.object({ kind: z.literal("strike"), targetId: idSchema }),
  z.object({ kind: z.literal("offerTruce"), targetId: idSchema }),
  z.object({ kind: z.literal("answerTruce"), accept: z.boolean() }),
  z.object({ kind: z.literal("skipDie") }),
  z.object({ kind: z.literal("recruit"), currency: z.enum(["cash", "dirty"]) }),
  z.object({ kind: z.literal("upgrade"), territoryId: idSchema }),
  z.object({ kind: z.literal("turfWar"), territoryId: idSchema }),
  z.object({ kind: z.literal("breakTruce"), targetId: idSchema }),
  z.object({ kind: z.literal("launderMoney"), amount: z.number().int().min(1) }),
  z.object({ kind: z.literal("bribe"), tier: z.number().int().min(0).max(2) }),
  z.object({ kind: z.literal("buyRespect"), points: z.number().int().min(1).max(3) }),
  z.object({ kind: z.literal("bail") }),
  z.object({ kind: z.literal("endTurn") }),
  /** The lazy resolver any client may call once a decision's deadline passes. */
  z.object({ kind: z.literal("resolveExpired") }),
]);
export type EmpireMove = z.infer<typeof empireMoveSchema>;

export type MoveCtx = { random: () => number; now: number };

function clone(state: EmpireState): EmpireState {
  return structuredClone(state);
}

function say(state: EmpireState, line: string): EmpireState {
  // Keep the tail only — this rides in every state write.
  return { ...state, log: [...state.log, line].slice(-12) };
}

function specialAt(tile: number) {
  return SPECIAL_TILES.find((s) => s.tile === tile) ?? null;
}

const fail = (error: string): EmpireTransition => ({ ok: false, error });

// ─── Entry point ─────────────────────────────────────────────────────────────

/**
 * Apply one move for one seat.
 *
 * Turn and ownership are validated here, not by the caller. A pending decision
 * outranks everything: while one is live the only legal moves are its answer
 * and `resolveExpired`.
 */
export function applyMove(
  state: EmpireState,
  memberId: string,
  move: EmpireMove,
  ctx: MoveCtx
): EmpireTransition {
  const result = applyMoveInner(state, memberId, move, ctx);
  if (!result.ok) return result;
  return {
    ok: true,
    state: {
      ...result.state,
      // Every successful move moves this, so a client watching for change
      // never misses one — the whole reason a bot's multi-move turn used to
      // stall halfway through.
      version: (state.version ?? 0) + 1,
      // The seat on the clock just acted, so give them a fresh window.
      turnExpiresAt: result.state.winnerId
        ? null
        : ctx.now + EMPIRE_WARS_CONFIG.turnWindowMs,
    },
  };
}

function applyMoveInner(
  state: EmpireState,
  memberId: string,
  move: EmpireMove,
  ctx: MoveCtx
): EmpireTransition {
  if (state.winnerId) return fail("The game is over");

  if (state.pending) {
    if (move.kind === "resolveExpired") return resolveExpired(state, ctx);
    if (state.pending.memberId !== memberId) {
      return fail("Someone else owes an answer");
    }
    if (state.pending.kind === "protection") {
      if (move.kind === "payFee") return answerProtection(state, memberId, true, ctx);
      if (move.kind === "refuseFee") return answerProtection(state, memberId, false, ctx);
      return fail("Pay or refuse first");
    }
    if (move.kind === "answerTruce") {
      return answerTruce(state, memberId, move.accept);
    }
    return fail("Answer the offer first");
  }

  if (move.kind === "resolveExpired") return fail("Nothing is pending");

  const active = currentPlayer(state);
  if (active.id !== memberId) return fail("Not your turn");
  if (active.eliminated) return fail("You're out of the game");

  switch (move.kind) {
    case "roll":
      return doRoll(state, memberId, ctx);
    case "bail":
      return doBail(state, memberId, ctx);
    case "buy":
      return doBuy(state, memberId);
    case "decline":
      return doDecline(state, memberId);
    case "useCar":
      return doUseCar(state, memberId, move.extra, ctx);
    case "strike":
      return doStrike(state, memberId, move.targetId, ctx);
    case "offerTruce":
      return doOfferTruce(state, memberId, move.targetId, ctx);
    case "skipDie":
      return { ok: true, state: { ...state, dieFace: null, phase: "build" } };
    case "recruit":
      return inBuild(state, () => recruitCrew(state, memberId, move.currency));
    case "upgrade":
      return inBuild(state, () => upgradeTerritory(state, memberId, move.territoryId));
    case "turfWar":
      return doTurfWar(state, memberId, move.territoryId, ctx);
    case "breakTruce":
      return doBreakTruce(state, memberId, move.targetId);
    case "launderMoney":
      return doLaunder(state, memberId, move.amount);
    case "bribe":
      return doBribe(state, memberId, move.tier, ctx);
    case "buyRespect":
      return doBuyRespect(state, memberId, move.points);
    case "endTurn":
      return endTurn(state, ctx);
    default:
      return fail("That isn't a move you can make");
  }
}

function inBuild(state: EmpireState, run: () => EmpireTransition): EmpireTransition {
  if (state.phase !== "build") return fail("Not while you're mid-turn");
  return run();
}

// ─── Roll and move ───────────────────────────────────────────────────────────

function doRoll(
  state: EmpireState,
  memberId: string,
  ctx: MoveCtx
): EmpireTransition {
  if (state.phase !== "roll") return fail("You've already rolled");

  // Upkeep runs when the turn opens, not as a player action.
  const upkeep = runUpkeep(state, memberId, ctx.random);
  let next = upkeep.state;
  if (upkeep.raided) {
    next = say(
      next,
      upkeep.seized
        ? `Police seized ${territoryDef(upkeep.seized).name}`
        : `Police confiscated $${upkeep.confiscated}`
    );
  }
  if (upkeep.jailed) {
    return { ok: true, state: say({ ...next, phase: "build" }, "Federal raid — straight to County Jail") };
  }

  const player = playerOf(next, memberId)!;
  if (player.jailTurns > 0) {
    // Serving time: no roll, no move. Doubles is the bail attempt.
    const a = rollD6(ctx.random);
    const b = rollD6(ctx.random);
    player.jailTurns -= 1;
    if (a === b || player.jailTurns === 0) {
      player.jailTurns = 0;
      player.heat = HEAT.jailRelease;
      next = say(next, a === b ? "Rolled doubles — out of jail" : "Time served");
    } else {
      next = say(next, `Still inside — ${player.jailTurns} to go`);
    }
    return { ok: true, state: { ...next, phase: "build", dieFace: null } };
  }

  const a = rollD6(ctx.random);
  const b = rollD6(ctx.random);
  const isDoubles = a === b;
  const doubles = isDoubles ? state.doubles + 1 : 0;

  if (doubles >= JAIL.doublesToJail) {
    player.jailTurns = JAIL.maxTurns;
    player.tile = 8;
    return {
      ok: true,
      state: say(
        { ...next, doubles: 0, phase: "build", dieFace: null },
        "Three doubles — you got sloppy. County Jail."
      ),
    };
  }

  const face = rollActionDie(ctx.random);
  const from = player.tile;
  const moved = advanceToken(player.tile, a + b);
  player.tile = moved.tile;

  next = collectFor(next, memberId, moved.passedDocks);
  next = {
    ...next,
    doubles,
    dieFace: face,
    phase: "act",
    tileDone: false,
    lastRoll: {
      memberId,
      d1: a,
      d2: b,
      from,
      to: moved.tile,
      seq: (state.lastRoll?.seq ?? 0) + 1,
    },
  };
  next = applyAutomaticDie(next, memberId, face);

  return landOn(next, memberId, ctx);
}

/** Income arrives every round; the Docks stipend only on a lap. */
function collectFor(
  state: EmpireState,
  memberId: string,
  passedDocks: boolean
): EmpireState {
  if (!EMPIRE_WARS_CONFIG.incomeEveryRound && !passedDocks) return state;
  const player = playerOf(state, memberId)!;
  return collectIncome(
    state,
    memberId,
    () => player.heat <= 3,
    { stipend: passedDocks }
  ).state;
}

/** Money Bag, Police and Question apply themselves; the rest are offers. */
function applyAutomaticDie(
  state: EmpireState,
  memberId: string,
  face: (typeof ACTION_DIE_FACES)[number]
): EmpireState {
  const next = clone(state);
  const player = playerOf(next, memberId)!;
  switch (face) {
    case "money-bag":
      player.cash += COSTS.moneyBagWindfall;
      return say(
        { ...next, dieFace: null, phase: "build" },
        `Money Bag — $${COSTS.moneyBagWindfall}`
      );
    case "police":
      player.heat = clampHeat(player.heat + 1);
      return say(
        { ...next, dieFace: null, phase: "build" },
        "Police sniffing around — +1 Heat"
      );
    case "question":
      return drawEvent({ ...next, dieFace: null, phase: "build" }, memberId);
    default:
      return next;
  }
}

/** Draw the top event, apply it, and cycle the deck. */
function drawEvent(state: EmpireState, memberId: string): EmpireState {
  const [drawn, ...rest] = state.eventDeck;
  if (!drawn) return state;
  const cycled = { ...state, eventDeck: [...rest, drawn] };
  const { state: applied, effect } = applyEvent(cycled, memberId, drawn);
  return say(applied, effect ? effect.text : "Nothing doing");
}

// ─── Landing ─────────────────────────────────────────────────────────────────

function landOn(
  state: EmpireState,
  memberId: string,
  ctx: MoveCtx
): EmpireTransition {
  const player = playerOf(state, memberId)!;
  const def = territoryAtTile(player.tile);

  if (!def) {
    const special = specialAt(player.tile);
    const resolved = resolveSpecial(state, memberId, special?.kind);
    return { ok: true, state: { ...resolved, tileDone: true } };
  }

  const territory = state.territories.find((t) => t.id === def.id)!;
  if (territory.ownerId === memberId) {
    return { ok: true, state: { ...state, tileDone: true } };
  }
  if (!territory.ownerId) {
    // Unowned: the seat still owes a buy-or-decline.
    return { ok: true, state: { ...state, tileDone: false } };
  }

  // A truce means no fee is demanded at all.
  const pairs = state.truces;
  const pair = [memberId, territory.ownerId].sort().join("|");
  if (pairs.includes(pair)) {
    return {
      ok: true,
      state: say({ ...state, tileDone: true }, "Truce — no fee demanded"),
    };
  }

  const fee = feeFor(state, territory);
  if (fee === 0) return { ok: true, state: { ...state, tileDone: true } };

  return {
    ok: true,
    state: {
      ...state,
      tileDone: true,
      pending: {
        kind: "protection",
        memberId,
        territoryId: territory.id,
        fee,
        expiresAt: ctx.now + EMPIRE_WARS_CONFIG.decisionWindowMs,
      },
    },
  };
}

function resolveSpecial(
  state: EmpireState,
  memberId: string,
  kind: SpecialTileKind | undefined
): EmpireState {
  const next = clone(state);
  const player = playerOf(next, memberId)!;
  switch (kind) {
    case "safehouse":
      player.heat = clampHeat(player.heat - HEAT.safehouseShed);
      return say(next, "The Safehouse — 1 Heat cleared");
    case "checkpoint": {
      const band = player.heat;
      if (band >= HEAT.raidsAt) {
        const lost = player.dirty;
        player.dirty = 0;
        if (band >= HEAT.federalAt) {
          player.jailTurns = JAIL.maxTurns;
          player.tile = 8;
          return say(next, `Checkpoint — lost $${lost} and jailed`);
        }
        return say(next, `Checkpoint — lost $${lost}`);
      }
      if (band >= HEAT.watchedAt) {
        const lost = Math.floor(player.dirty / 2);
        player.dirty -= lost;
        return say(next, `Searched at the checkpoint — lost $${lost}`);
      }
      return say(next, "Waved through the checkpoint");
    }
    case "speakeasy":
      return drawEvent(next, memberId);
    default:
      return next;
  }
}

// ─── Pending decisions ───────────────────────────────────────────────────────

function answerProtection(
  state: EmpireState,
  memberId: string,
  pay: boolean,
  ctx: MoveCtx
): EmpireTransition {
  const pending = state.pending;
  if (!pending || pending.kind !== "protection") return fail("Nothing to answer");

  if (pay) {
    const player = playerOf(state, memberId)!;
    if (player.cash >= pending.fee) {
      const paid = payProtection(state, memberId, pending.territoryId);
      return {
        ok: true,
        state: say({ ...paid.state, pending: null }, `Paid $${paid.paid} protection`),
      };
    }
    const territory = state.territories.find((t) => t.id === pending.territoryId)!;
    const settled = settleDebt(state, memberId, pending.fee, territory.ownerId);
    return {
      ok: true,
      state: say({ ...settled.state, pending: null }, "Couldn't cover it — broke"),
    };
  }

  const fight = resolveStandoff(state, memberId, pending.territoryId, ctx.random);
  return {
    ok: true,
    state: say(
      { ...fight.state, pending: null },
      fight.outcome.attackerWins
        ? "Refused and won — paid nothing"
        : "Refused and lost — paid double"
    ),
  };
}

function answerTruce(
  state: EmpireState,
  memberId: string,
  accept: boolean
): EmpireTransition {
  const pending = state.pending;
  if (!pending || pending.kind !== "truce") return fail("Nothing to answer");
  if (!accept) {
    return { ok: true, state: say({ ...state, pending: null }, "Truce declined") };
  }
  const result = acceptTruce(state, pending.fromMemberId, memberId);
  if (!result.ok) {
    return { ok: true, state: say({ ...state, pending: null }, "Truce fell through") };
  }
  return { ok: true, state: say({ ...result.state, pending: null }, "Truce agreed") };
}

/**
 * Resolve an expired decision to its default.
 *
 * **Expiry is checked against the server's clock**, never the caller's. A
 * client's wall clock decides only *when to ask*; if it asks early this
 * returns an error and nothing happens (GDD > Pending decisions).
 */
export function resolveExpired(
  state: EmpireState,
  ctx: MoveCtx
): EmpireTransition {
  const pending = state.pending;
  if (!pending) return fail("Nothing is pending");
  if (ctx.now < pending.expiresAt) return fail("That decision is still live");

  if (pending.kind === "protection") {
    return answerProtection(state, pending.memberId, true, ctx);
  }
  return answerTruce(state, pending.memberId, false);
}

// ─── Action-die offers ───────────────────────────────────────────────────────

function doUseCar(
  state: EmpireState,
  memberId: string,
  extra: number,
  ctx: MoveCtx
): EmpireTransition {
  if (state.dieFace !== "car") return fail("You didn't roll the Car");
  const next = clone(state);
  const player = playerOf(next, memberId)!;
  const from = player.tile;
  const moved = advanceToken(player.tile, extra);
  player.tile = moved.tile;
  next.lastRoll = {
    memberId,
    d1: extra,
    d2: 0,
    from,
    to: moved.tile,
    seq: (next.lastRoll?.seq ?? 0) + 1,
  };
  const collected = collectFor(
    { ...next, dieFace: null, phase: "build" },
    memberId,
    moved.passedDocks
  );
  return landOn(collected, memberId, ctx);
}

function doStrike(
  state: EmpireState,
  memberId: string,
  targetId: string,
  ctx: MoveCtx
): EmpireTransition {
  const free = state.freeAttackFor === memberId;
  if (state.dieFace !== "gun" && !free) return fail("You didn't roll the Gun");
  if (!free && !strikeTargets(state, memberId).includes(targetId)) {
    return fail("They're out of reach");
  }
  const result = resolveStrike(state, memberId, targetId, ctx.random);
  if ("error" in result) return fail(result.error);
  return {
    ok: true,
    state: say(
      { ...result.state, dieFace: null, freeAttackFor: null, phase: "build" },
      result.outcome.attackerWins ? "Strike landed" : "Strike went badly"
    ),
  };
}

function doOfferTruce(
  state: EmpireState,
  memberId: string,
  targetId: string,
  ctx: MoveCtx
): EmpireTransition {
  if (state.dieFace !== "handshake") return fail("You didn't roll the Handshake");
  if (!canOfferTruce(state, memberId, targetId)) return fail("They can't take a truce");
  return {
    ok: true,
    state: {
      ...state,
      dieFace: null,
      phase: "build",
      pending: {
        kind: "truce",
        memberId: targetId,
        fromMemberId: memberId,
        expiresAt: ctx.now + EMPIRE_WARS_CONFIG.decisionWindowMs,
      },
    },
  };
}

// ─── Tile actions ────────────────────────────────────────────────────────────

function doBuy(state: EmpireState, memberId: string): EmpireTransition {
  const player = playerOf(state, memberId)!;
  const def = territoryAtTile(player.tile);
  if (!def) return fail("Nothing to buy here");
  if (state.tileDone) return fail("You've already settled this tile");
  const result = buyTerritory(state, memberId, def.id);
  if (!result.ok) return result;
  return {
    ok: true,
    state: say({ ...result.state, tileDone: true }, `Bought ${def.name}`),
  };
}

function doDecline(state: EmpireState, memberId: string): EmpireTransition {
  const player = playerOf(state, memberId)!;
  const def = territoryAtTile(player.tile);
  if (!def) return fail("Nothing to decline here");
  if (state.tileDone) return fail("You've already settled this tile");
  const territory = state.territories.find((t) => t.id === def.id)!;
  if (territory.ownerId) return fail("That's already owned");
  return {
    ok: true,
    state: say(
      { ...declineTerritory(state, def.id), tileDone: true },
      `Passed on ${def.name} — marked down`
    ),
  };
}

function doTurfWar(
  state: EmpireState,
  memberId: string,
  territoryId: string,
  ctx: MoveCtx
): EmpireTransition {
  if (state.phase !== "build") return fail("Turf wars are declared in Build");
  if (state.turfWarUsed) return fail("One turf war a turn");
  const result = resolveTurfWar(state, memberId, territoryId, ctx.random);
  if ("error" in result) return fail(result.error);
  return {
    ok: true,
    state: say(
      { ...result.state, turfWarUsed: true },
      result.captured ? `Took ${territoryDef(territoryId).name}` : "Turf war lost"
    ),
  };
}

function doBreakTruce(
  state: EmpireState,
  memberId: string,
  targetId: string
): EmpireTransition {
  if (state.phase !== "build") return fail("Not while you're mid-turn");
  const result = breakTruce(state, memberId, targetId);
  if (!result.ok) return result;
  return {
    ok: true,
    state: say(
      { ...result.state, freeAttackFor: memberId },
      "Truce broken — one free attack"
    ),
  };
}

function doLaunder(
  state: EmpireState,
  memberId: string,
  amount: number
): EmpireTransition {
  const player = playerOf(state, memberId)!;
  if (player.dirty <= 0) return fail("Nothing to launder");
  const special = specialAt(player.tile);
  const result = launder(state, memberId, {
    amount,
    atSafehouse: special?.kind === "safehouse",
  });
  return { ok: true, state: say(result.state, `Laundered — $${result.cash} clean`) };
}

function doBribe(
  state: EmpireState,
  memberId: string,
  tierIndex: number,
  ctx: MoveCtx
): EmpireTransition {
  const player = playerOf(state, memberId)!;
  if (specialAt(player.tile)?.kind !== "city-hall") return fail("Bribes happen at City Hall");
  const tier = BRIBE_TIERS[tierIndex];
  if (!tier) return fail("No such bribe");

  const discount = player.boss === "corrupt-politician" ? 0.5 : 0;
  const cost = Math.round(tier.cost * (1 - discount));
  if (player.cash < cost) return fail("You can't afford that bribe");

  const next = clone(state);
  const me = playerOf(next, memberId)!;
  me.cash -= cost;
  const roll = rollD6(ctx.random);
  if (roll >= tier.succeedsAtLeast) {
    me.heat = clampHeat(me.heat - HEAT.bribeSuccessShed);
    return { ok: true, state: say(next, "The bribe took — Heat down") };
  }
  me.heat = clampHeat(me.heat + HEAT.bribeFailHeat);
  return { ok: true, state: say(next, "Bribe refused — and now they're angry") };
}

function doBuyRespect(
  state: EmpireState,
  memberId: string,
  points: number
): EmpireTransition {
  const player = playerOf(state, memberId)!;
  if (specialAt(player.tile)?.kind !== "city-hall") return fail("That happens at City Hall");
  if (points > COSTS.respectMaxPerVisit) return fail("Three points a visit, no more");
  const cost = points * COSTS.respectPrice;
  if (player.cash < cost) return fail("You can't afford that");
  const next = clone(state);
  const me = playerOf(next, memberId)!;
  me.cash -= cost;
  me.respect = clampRespect(me.respect + points);
  return { ok: true, state: say(next, `Bought ${points} Respect`) };
}

function doBail(
  state: EmpireState,
  memberId: string,
  ctx: MoveCtx
): EmpireTransition {
  const player = playerOf(state, memberId)!;
  if (player.jailTurns <= 0) return fail("You're not in jail");
  if (player.cash < COSTS.bail) return fail("You can't make bail");
  void ctx;
  const next = clone(state);
  const me = playerOf(next, memberId)!;
  me.cash -= COSTS.bail;
  me.jailTurns = 0;
  me.heat = HEAT.jailRelease;
  return { ok: true, state: say(next, "Made bail") };
}

// ─── Ending a turn ───────────────────────────────────────────────────────────

/**
 * Close the turn: check for a Kingpin, hand the clock to the next live seat,
 * and run the end-of-round sweep when the rotation wraps.
 */
export function endTurn(state: EmpireState, ctx: MoveCtx): EmpireTransition {
  if (state.pending) return fail("Answer the open decision first");

  // Missions settle before the clock moves, so a mission completed by this
  // turn's last action still pays out this turn.
  const settled = settleMissions(state, currentPlayer(state).id);
  let next: EmpireState = {
    ...settled.state,
    dieFace: null,
    turfWarUsed: false,
    tileDone: false,
    freeAttackFor: null,
    turnCount: state.turnCount + 1,
  };
  for (const done of settled.completed) {
    next = say(next, `Mission complete: +${done.respect} Respect, $${done.cash}`);
  }

  const active = currentPlayer(next);
  if (isKingpin(next, active.id)) {
    return {
      ok: true,
      state: say(
        { ...next, winnerId: active.id, kingpin: true, phase: "roll" },
        "Kingpin — the city is theirs",
      ),
    };
  }

  // Doubles buy another turn, so the clock does not move.
  if (next.doubles > 0) {
    return { ok: true, state: { ...next, phase: "roll" } };
  }

  const live = next.players.filter((p) => !p.eliminated);
  if (live.length === 0) return { ok: true, state: { ...next, phase: "roll" } };

  let index = next.currentIndex;
  let wrapped = false;
  for (let i = 0; i < next.players.length; i++) {
    index = (index + 1) % next.players.length;
    if (index === 0) wrapped = true;
    if (!next.players[index].eliminated) break;
  }
  next = { ...next, currentIndex: index, phase: "roll" };

  if (wrapped) {
    next = sweepMostWanted(next);
    const round = next.round + 1;
    if (round > EMPIRE_WARS_CONFIG.roundLimit) {
      const winner = standingsOrder(next)[0] ?? null;
      return {
        ok: true,
        state: say({ ...next, round: next.round, winnerId: winner }, "Time's up"),
      };
    }
    next = { ...next, round };
  }

  void ctx;
  return { ok: true, state: next };
}

/**
 * Has the seat on the clock run out of time?
 *
 * Judged against the **server's** clock, never the caller's — a client with a
 * fast clock must not be able to play someone else's turn early.
 */
export function turnHasExpired(state: EmpireState, now: number): boolean {
  if (state.winnerId) return false;
  if (state.turnExpiresAt === null) return false;
  return now >= state.turnExpiresAt;
}

/** Quit: out of rotation, land released, truces dropped (ADR-0004). */
export function applyQuit(state: EmpireState, memberId: string): EmpireTransition {
  const player = playerOf(state, memberId);
  if (!player) return fail("You're not in this game");
  if (player.eliminated) return fail("You're already out");

  let next = clearTrucesFor(state, memberId);
  next = {
    ...next,
    players: next.players.map((p) =>
      p.id === memberId ? { ...p, eliminated: true, poolCrew: 0, enforcers: 0 } : p
    ),
    territories: next.territories.map((t) =>
      t.ownerId === memberId
        ? { ...t, ownerId: null, level: 1 as const, garrison: 0 }
        : t
    ),
    pending: next.pending?.memberId === memberId ? null : next.pending,
  };

  const live = next.players.filter((p) => !p.eliminated);
  if (live.length === 1) {
    return { ok: true, state: { ...next, winnerId: live[0].id } };
  }
  if (currentPlayer(next).id === memberId) {
    const advanced = endTurn(next, { random: Math.random, now: 0 });
    if (advanced.ok) next = advanced.state;
  }
  return { ok: true, state: say(next, "A boss walked away") };
}

export { KINGPIN, RESPECT, territoriesOf, hasDistrictBonus };
