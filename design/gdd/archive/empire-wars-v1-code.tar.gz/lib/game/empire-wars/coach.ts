import { COSTS, KINGPIN } from "@/lib/game/data/empire-wars";
import type { EmpireMove } from "@/lib/game/empire-wars/turn";
import type { EmpireView } from "@/lib/game/empire-wars/view";

// What to tell the player, right now.
//
// Empire Wars has 16 concepts and ~20 legal moves. Showing them all at once
// as equal buttons is how it ends up feeling like paperwork. This module picks
// **one obvious next action**, says what it will do in plain words, and pushes
// everything else down — so the game teaches itself while it is being played.
//
// Pure and view-driven, so it is unit-testable and can never disagree with
// what the board is actually allowed to do.

export type CoachAction = {
  move: EmpireMove;
  label: string;
  /** The consequence, in words. Shown under a primary, as a title elsewhere. */
  hint?: string;
  tone?: "go" | "danger" | "quiet";
};

export type Coach = {
  /** What is happening / what to do. One short sentence. */
  headline: string;
  /** Why it matters. Omitted when the headline says everything. */
  detail?: string;
  /** The obvious next move. Rendered big. */
  primary?: CoachAction;
  /** Other things worth doing now, best first. Rendered small. */
  secondary: CoachAction[];
  /** True while we're waiting on someone else — the rail goes quiet. */
  waiting?: boolean;
};

function money(n: number): string {
  return `$${n.toLocaleString("en-US")}`;
}

/** How many of a district the viewer owns, and how many are left. */
function districtProgress(view: EmpireView, districtName: string, youId: string) {
  const inDistrict = view.territories.filter(
    (t) => t.districtName === districtName
  );
  const mine = inDistrict.filter((t) => t.ownerId === youId).length;
  return { mine, total: inDistrict.length, left: inDistrict.length - mine };
}

/**
 * The guidance for this exact moment.
 *
 * Order matters: it walks the turn the way a person experiences it, so the
 * first branch that matches is the thing actually in front of them.
 */
export function coachFor(view: EmpireView, label: (id: string) => string): Coach {
  const you = view.you;

  if (view.winnerId) {
    const won = you && view.winnerId === you.memberId;
    return {
      headline: won ? "You run the city" : `${label(view.winnerId)} runs the city`,
      detail: view.kingpin
        ? "Kingpin — four districts, the respect, and a clean enough record."
        : "Biggest empire when the clock ran out.",
      secondary: [],
      waiting: true,
    };
  }

  if (!you) {
    return { headline: "Watching the table", secondary: [], waiting: true };
  }

  // A decision belonging to someone else freezes the whole table.
  if (view.pending && view.pending.memberId !== you.memberId) {
    return {
      headline: `Waiting on ${label(view.pending.memberId)}`,
      detail:
        view.pending.kind === "protection"
          ? "They're deciding whether to pay up or fight."
          : "They're deciding whether to shake on it.",
      secondary: [],
      waiting: true,
    };
  }

  // Their own decision is handled by the overlay, which takes over the screen.
  if (view.pending) {
    return { headline: "Your call", secondary: [] };
  }

  if (view.currentMemberId !== you.memberId) {
    return {
      headline: `${label(view.currentMemberId)} is playing`,
      detail: "Watch the board — you're next.",
      secondary: [],
      waiting: true,
    };
  }

  const seat = view.seats.find((s) => s.memberId === you.memberId);

  // ── Jail ──────────────────────────────────────────────────────────────────
  if (seat?.inJail) {
    const canBail = you.cash >= COSTS.bail;
    return {
      headline: "You're inside",
      detail: `Pay ${money(COSTS.bail)} to walk out now, or roll and sit it out. Either way you come out cooler — Heat drops to 2.`,
      primary: canBail
        ? { move: { kind: "bail" }, label: `Make bail — ${money(COSTS.bail)}`, tone: "go" }
        : { move: { kind: "roll" }, label: "Do your time", tone: "go" },
      secondary: canBail
        ? [{ move: { kind: "roll" }, label: "Do your time", tone: "quiet" }]
        : [],
    };
  }

  // ── Start of turn ─────────────────────────────────────────────────────────
  if (view.phase === "roll") {
    return {
      headline: "Your turn",
      detail: "Roll to move. Land on free ground and you can buy it.",
      primary: { move: { kind: "roll" }, label: "Roll the dice", tone: "go" },
      secondary: [],
    };
  }

  // ── Standing on something you could buy ───────────────────────────────────
  if (you.canBuyHere) {
    const tile = view.territories.find((t) => t.id === you.canBuyHere!.territoryId);
    const price = you.canBuyHere.price;
    const affordable = you.cash >= price;
    const progress = tile
      ? districtProgress(view, tile.districtName, you.memberId)
      : null;

    const detail = !tile
      ? undefined
      : affordable
        ? [
            `Pays you ${money(tile.income)} every round.`,
            progress && progress.left === 1
              ? `This is the last one — buy it and all of ${tile.districtName} is yours.`
              : progress && progress.mine > 0
                ? `${progress.left - 1} more after this and ${tile.districtName} is yours.`
                : null,
          ]
            .filter(Boolean)
            .join(" ")
        : `You're ${money(price - you.cash)} short. Passing knocks 10% off for whoever lands here next.`;

    return {
      headline: tile ? `${tile.name} is for sale` : "Up for sale",
      detail,
      primary: affordable
        ? { move: { kind: "buy" }, label: `Buy — ${money(price)}`, tone: "go" }
        : { move: { kind: "decline" }, label: "Pass", tone: "quiet" },
      secondary: affordable
        ? [
            {
              move: { kind: "decline" },
              label: "Pass",
              hint: "Knocks 10% off the price for whoever lands here next",
              tone: "quiet",
            },
          ]
        : [],
    };
  }

  // ── Holding an action die ─────────────────────────────────────────────────
  if (view.dieFace) {
    return dieCoach(view, you, label);
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  return buildCoach(view, you);
}

function dieCoach(
  view: EmpireView,
  you: NonNullable<EmpireView["you"]>,
  label: (id: string) => string
): Coach {
  const skip: CoachAction = {
    move: { kind: "skipDie" },
    label: "Skip it",
    tone: "quiet",
  };

  switch (view.dieFace) {
    case "gun": {
      if (you.strikeTargets.length === 0) {
        return {
          headline: "You drew the Gun",
          detail: "Nobody's in range. It keeps until next time.",
          primary: { ...skip, label: "Move on", tone: "go" },
          secondary: [],
        };
      }
      return {
        headline: "You drew the Gun",
        detail:
          "Hit a rival to take a crew off them. Costs you 1 Heat, win or lose — and you might lose a crew instead.",
        primary: {
          move: { kind: "strike", targetId: you.strikeTargets[0] },
          label: `Strike ${label(you.strikeTargets[0])}`,
          tone: "danger",
        },
        secondary: [
          ...you.strikeTargets.slice(1).map((id) => ({
            move: { kind: "strike" as const, targetId: id },
            label: `Strike ${label(id)}`,
            tone: "danger" as const,
          })),
          skip,
        ],
      };
    }

    case "handshake": {
      const others = view.seats.filter(
        (s) => s.memberId !== you.memberId && !s.eliminated
      );
      if (others.length === 0) {
        return {
          headline: "You drew the Handshake",
          detail: "Nobody left to deal with.",
          primary: { ...skip, label: "Move on", tone: "go" },
          secondary: [],
        };
      }
      return {
        headline: "You drew the Handshake",
        detail:
          "Offer a truce: neither of you pays the other, and neither can take the other's turf. You can break it later — for 3 Respect.",
        primary: {
          move: { kind: "offerTruce", targetId: others[0].memberId },
          label: `Offer ${label(others[0].memberId)} a truce`,
          tone: "go",
        },
        secondary: [
          ...others.slice(1).map((s) => ({
            move: { kind: "offerTruce" as const, targetId: s.memberId },
            label: `Offer ${label(s.memberId)} a truce`,
          })),
          skip,
        ],
      };
    }

    case "car":
      return {
        headline: "You drew the Car",
        detail: "Roll on up to three more tiles — handy if there's something worth buying just ahead.",
        primary: { move: { kind: "useCar", extra: 1 }, label: "Drive 1", tone: "go" },
        secondary: [
          { move: { kind: "useCar", extra: 2 }, label: "Drive 2" },
          { move: { kind: "useCar", extra: 3 }, label: "Drive 3" },
          { ...skip, label: "Stay put" },
        ],
      };

    default:
      return {
        headline: "Carry on",
        primary: { ...skip, label: "Continue", tone: "go" },
        secondary: [],
      };
  }
}

function buildCoach(
  view: EmpireView,
  you: NonNullable<EmpireView["you"]>
): Coach {
  const secondary: CoachAction[] = [];

  // Hot money first — it is the thing most likely to hurt them this round.
  if (you.dirty > 0) {
    secondary.push({
      move: { kind: "launderMoney", amount: you.dirty },
      label: `Launder ${money(you.dirty)}`,
      hint:
        you.dirtyHeatPerRound > 0
          ? `Stops it adding +${you.dirtyHeatPerRound} Heat every round. You lose a cut.`
          : "Turns it into clean cash. You lose a cut.",
      tone: you.dirtyHeatPerRound >= 2 ? "danger" : undefined,
    });
  }

  const upgradable = view.territories.filter(
    (t) => t.ownerId === you.memberId && t.level < 5
  );
  if (upgradable.length > 0) {
    const best = [...upgradable].sort((a, b) => b.income - a.income)[0];
    secondary.push({
      move: { kind: "upgrade", territoryId: best.id },
      label: `Upgrade ${best.name}`,
      hint: "Earns more, and harder for rivals to take",
    });
  }

  if (you.turfWarTargets.length > 0) {
    const target = view.territories.find((t) => t.id === you.turfWarTargets[0]);
    secondary.push({
      move: { kind: "turfWar", territoryId: you.turfWarTargets[0] },
      label: `Take ${target?.name ?? "their turf"}`,
      hint: "Win and it's yours. Costs 2 Heat either way",
      tone: "danger",
    });
  }

  secondary.push({
    move: { kind: "recruit", currency: "cash" },
    label: "Hire crew",
    hint: "Crew win fights and hold your corners",
  });

  const heat = you.kingpinProgress.heat;
  const detail =
    heat >= 6
      ? "The police are raiding at this Heat. Clear it or dump anything dirty."
      : you.dirty > 0
        ? "Dirty money earns more but the police notice it every round."
        : "Spend what you like, then end your turn.";

  return {
    headline: "Anything else before you're done?",
    detail,
    primary: { move: { kind: "endTurn" }, label: "End turn", tone: "go" },
    secondary,
  };
}

/** Plain-language meaning of a Heat band, for the track's caption. */
export function heatMeaning(heat: number): string {
  if (heat >= 9) return "Federal — raids most rounds, and no dirty income at all";
  if (heat >= 6) return "Raids — the police may take your dirty money, or a tile";
  if (heat >= 3) return "Watched — your illegal places earn 25% less";
  return "Clean — nobody's looking at you";
}

/** The whole game in four lines, for the first-run card. */
export const HOW_TO_PLAY = [
  {
    title: "Roll, move, buy",
    body: "Land on free ground and it's yours for the asking price. Each place pays you every round.",
  },
  {
    title: "Land on a rival and they want paying",
    body: "Hand it over, or refuse and fight them for it. Your crew against whatever is guarding the place.",
  },
  {
    title: "Dirty money earns more — and the police notice",
    body: "It pays better than cash, but every round you hold it your Heat climbs. At Heat 6 the raids start.",
  },
  {
    title: "Biggest empire wins",
    body: `After ${20} rounds, whoever's worth most takes the city. Or win outright: ${KINGPIN.districts} full districts, ${KINGPIN.respect} respect, and a cool head.`,
  },
] as const;
