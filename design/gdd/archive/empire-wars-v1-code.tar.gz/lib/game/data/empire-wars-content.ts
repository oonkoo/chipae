// Mission and event content for Empire Wars. Data only — the rules layer
// evaluates these, so adding a card never touches logic.

export type MissionId = (typeof MISSIONS)[number]["id"];

/**
 * The 10 secret missions. Each seat holds 3, drawn from its **own** shuffled
 * copy: 6 seats × 3 needs 18 cards, and a shared 10-card deck cannot serve a
 * full table. Two players may unknowingly chase the same objective, which is
 * fine — the whole point is that nobody can see them.
 */
export const MISSIONS = [
  {
    id: "control-a-district",
    text: "Own every tile in one district",
    respect: 4,
    cash: 400,
  },
  {
    id: "five-grand",
    text: "Hold $5,000 in Cash at once",
    respect: 3,
    cash: 300,
  },
  {
    id: "three-wins",
    text: "Win three fights",
    respect: 5,
    cash: 200,
  },
  {
    id: "respect-twenty",
    text: "Reach 20 Respect",
    respect: 3,
    cash: 500,
  },
  {
    id: "two-landmarks",
    text: "Own two landmarks",
    respect: 4,
    cash: 400,
  },
  {
    id: "take-by-force",
    text: "Take a territory by turf war",
    respect: 5,
    cash: 300,
  },
  {
    id: "launder-three-grand",
    text: "Launder $3,000 over the match",
    respect: 3,
    cash: 400,
  },
  {
    id: "clean-empire",
    text: "End a round at Heat 0 owning six or more tiles",
    respect: 5,
    cash: 300,
  },
  {
    id: "six-tiles",
    text: "Own six territories at once",
    respect: 3,
    cash: 350,
  },
  {
    id: "fortress",
    text: "Raise any territory to Level 5",
    respect: 4,
    cash: 350,
  },
] as const;

export const MISSION_IDS = MISSIONS.map((m) => m.id);

export function missionById(id: string) {
  return MISSIONS.find((m) => m.id === id) ?? null;
}

/**
 * Personal events, drawn on the Question die face and at The Speakeasy.
 *
 * **City-wide events were cut in the review revision.** Every card here hits
 * only the drawer, so an event can never open a decision for another seat —
 * which is what keeps ADR-0005's one-seat-on-the-clock model intact.
 */
export const EVENTS = [
  { id: "shipment-came-in", text: "A shipment came in", cash: 300, dirty: 0, heat: 0, respect: 0 },
  { id: "skim-the-take", text: "You skimmed the take", cash: 0, dirty: 400, heat: 0, respect: 0 },
  { id: "cop-on-payroll", text: "A cop owes you a favour", cash: 0, dirty: 0, heat: -2, respect: 0 },
  { id: "made-your-name", text: "Word gets around", cash: 0, dirty: 0, heat: 0, respect: 2 },
  { id: "informant-talked", text: "An informant talked", cash: 0, dirty: 0, heat: 2, respect: 0 },
  { id: "shakedown", text: "You got shaken down", cash: -250, dirty: 0, heat: 0, respect: 0 },
  { id: "lost-face", text: "You lost face on the street", cash: 0, dirty: 0, heat: 0, respect: -2 },
  { id: "quiet-week", text: "A quiet week", cash: 150, dirty: 0, heat: -1, respect: 0 },
] as const;

export const EVENT_IDS = EVENTS.map((e) => e.id);

export function eventById(id: string) {
  return EVENTS.find((e) => e.id === id) ?? null;
}
