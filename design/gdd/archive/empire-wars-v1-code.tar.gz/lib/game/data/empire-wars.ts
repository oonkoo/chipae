// Tuning knobs for Empire Wars (design/gdd/empire-wars-core.md, ADR-0005).
// Gameplay values live here, never inline in logic code.
//
// Every number below is transcribed from the GDD's Formulas and Tuning Knobs
// sections. If a value here and the GDD ever disagree, the GDD is wrong until
// someone fixes one of them — the acceptance criteria check this file against
// the published tables.

// ─── Match shape ─────────────────────────────────────────────────────────────

export const EMPIRE_WARS_CONFIG = {
  gameType: "empire-wars",
  minPlayers: 2,
  maxPlayers: 6,
  roundLimit: 20,

  startingCash: 1500,
  startingDirty: 0,
  startingRespect: 3,
  startingHeat: 0,
  startingCrew: 2,
  missionsInHand: 3,

  /** Pending-decision window, and the jitter clients add before resolving. */
  decisionWindowMs: 20_000,
  decisionJitterMaxMs: 2_000,

  /**
   * How long a human seat has to act before the table plays on without them.
   *
   * CPU seats ignore this entirely — they act on `botDelayMsMin/Max`. This is
   * only the backstop for a person who walked away, so nobody else's match is
   * held hostage.
   */
  turnWindowMs: 30_000,

  /**
   * Territory income every round, rather than only on a Docks lap.
   *
   * ⚠️ MEASURED, NOT ASSUMED. With income on laps (~4.3 per match) every
   * upgrade in the game needs 5.4–27.8 laps to repay its cost, so the entire
   * 5-level property system is strictly dominated by never upgrading. Per
   * round gives 20 collections instead of 4.3 and brings payback inside the
   * match. The Docks stipend stays lap-based — that's the "passing GO" beat.
   *
   * Set false to reproduce the published lap-only economy in simulation.
   */
  incomeEveryRound: true,

  /** Client-side bot pacing, matching Nuno's casual feel. */
  botDelayMsMin: 1_000,
  botDelayMsMax: 3_000,
} as const;

// ─── The board ───────────────────────────────────────────────────────────────

export type TerritoryTier = "small" | "illegal" | "landmark";
export type DistrictId =
  | "old-town"
  | "little-havana"
  | "harbor"
  | "industrial"
  | "downtown"
  | "nightclub"
  | "casino-strip"
  | "financial";

/**
 * District powers, unlocked by owning all three tiles and lost the moment one
 * goes. `bonus` is the discriminator the rules switch on.
 */
export const DISTRICTS: Array<{
  id: DistrictId;
  name: string;
  bonus:
    | "crew-discount"
    | "respect-per-collection"
    | "dirty-income-boost"
    | "upgrade-discount"
    | "protection-boost"
    | "launder-clears-heat"
    | "doubles-jackpot"
    | "half-dirty-heat";
}> = [
  { id: "old-town", name: "Old Town", bonus: "crew-discount" },
  { id: "little-havana", name: "Little Havana", bonus: "respect-per-collection" },
  { id: "harbor", name: "The Harbor", bonus: "dirty-income-boost" },
  { id: "industrial", name: "Industrial", bonus: "upgrade-discount" },
  { id: "downtown", name: "Downtown", bonus: "protection-boost" },
  { id: "nightclub", name: "Nightclub District", bonus: "launder-clears-heat" },
  { id: "casino-strip", name: "Casino Strip", bonus: "doubles-jackpot" },
  { id: "financial", name: "Financial District", bonus: "half-dirty-heat" },
];

/** The 24 territories, in board order. `tile` is the index on the 32-tile ring. */
export const TERRITORIES: Array<{
  id: string;
  name: string;
  district: DistrictId;
  tier: TerritoryTier;
  price: number;
  tile: number;
}> = [
  { id: "pawn-shop", name: "Pawn Shop", district: "old-town", tier: "small", price: 120, tile: 1 },
  { id: "barber-shop", name: "Barber Shop", district: "old-town", tier: "small", price: 140, tile: 2 },
  { id: "tattoo-parlour", name: "Tattoo Parlour", district: "old-town", tier: "small", price: 160, tile: 3 },

  { id: "cigar-lounge", name: "Cigar Lounge", district: "little-havana", tier: "small", price: 160, tile: 5 },
  { id: "car-wash", name: "Car Wash", district: "little-havana", tier: "small", price: 180, tile: 6 },
  { id: "liquor-store", name: "Liquor Store", district: "little-havana", tier: "illegal", price: 300, tile: 7 },

  { id: "fish-market", name: "Fish Market", district: "harbor", tier: "small", price: 200, tile: 9 },
  { id: "boat-yard", name: "Boat Yard", district: "harbor", tier: "illegal", price: 330, tile: 10 },
  { id: "shipping-port", name: "Shipping Port", district: "harbor", tier: "landmark", price: 600, tile: 11 },

  { id: "garage", name: "Garage", district: "industrial", tier: "small", price: 240, tile: 13 },
  { id: "factory", name: "Factory", district: "industrial", tier: "small", price: 260, tile: 14 },
  { id: "chop-shop", name: "Chop Shop", district: "industrial", tier: "illegal", price: 420, tile: 15 },

  { id: "coffee-house", name: "Coffee House", district: "downtown", tier: "small", price: 280, tile: 17 },
  { id: "drug-lab", name: "Drug Lab", district: "downtown", tier: "illegal", price: 450, tile: 18 },
  { id: "money-laundry", name: "Money Laundry", district: "downtown", tier: "illegal", price: 480, tile: 19 },

  { id: "jazz-cellar", name: "Jazz Cellar", district: "nightclub", tier: "small", price: 320, tile: 21 },
  { id: "gin-joint", name: "Gin Joint", district: "nightclub", tier: "illegal", price: 510, tile: 22 },
  { id: "onyx-room", name: "The Onyx Room", district: "nightclub", tier: "landmark", price: 850, tile: 23 },

  { id: "poker-room", name: "Poker Room", district: "casino-strip", tier: "illegal", price: 560, tile: 25 },
  { id: "racetrack", name: "Racetrack", district: "casino-strip", tier: "illegal", price: 580, tile: 26 },
  { id: "golden-chip", name: "The Golden Chip", district: "casino-strip", tier: "landmark", price: 950, tile: 27 },

  { id: "accounting-office", name: "Accounting Office", district: "financial", tier: "small", price: 400, tile: 29 },
  { id: "bail-bonds", name: "Bail Bonds", district: "financial", tier: "small", price: 420, tile: 30 },
  { id: "first-city-bank", name: "First City Bank", district: "financial", tier: "landmark", price: 1100, tile: 31 },
];

export type SpecialTileKind =
  | "docks"
  | "jail"
  | "safehouse"
  | "airport"
  | "checkpoint"
  | "speakeasy"
  | "city-hall";

export const SPECIAL_TILES: Array<{ tile: number; kind: SpecialTileKind; name: string }> = [
  { tile: 0, kind: "docks", name: "The Docks" },
  { tile: 4, kind: "checkpoint", name: "Police Checkpoint" },
  { tile: 8, kind: "jail", name: "County Jail" },
  { tile: 12, kind: "speakeasy", name: "The Speakeasy" },
  { tile: 16, kind: "safehouse", name: "The Safehouse" },
  { tile: 20, kind: "city-hall", name: "City Hall" },
  { tile: 24, kind: "airport", name: "The Airport" },
  { tile: 28, kind: "checkpoint", name: "Police Checkpoint" },
];

export const BOARD_TILE_COUNT = 32;

/**
 * Turf-war adjacency: a **declared ring of territory ids**, deliberately not
 * derived from tile geometry (GDD > Edge Cases > Adjacency). The rules own
 * this; the board merely visualises it. Desktop draws a ring, mobile draws
 * eight district columns, and adjacency is identical on both.
 *
 * Each territory has exactly two neighbours and the ring closes, so First City
 * Bank neighbours Pawn Shop across The Docks.
 */
export const TERRITORY_RING: string[] = TERRITORIES.map((t) => t.id);

// ─── Income and value ────────────────────────────────────────────────────────

/** Fraction of price paid as Cash per collection. */
export const TIER_CASH_RATE: Record<TerritoryTier, number> = {
  small: 0.15,
  illegal: 0.15,
  landmark: 0.16,
};

/** The greedy option. Small tiles never offer it. */
export const TIER_DIRTY_RATE: Record<TerritoryTier, number | null> = {
  small: null,
  illegal: 0.25,
  landmark: 0.28,
};

/** Indexed by level 1–5 (index 0 unused). */
export const LEVEL_INCOME_MULT = [0, 1.0, 1.5, 2.2, 3.2, 4.5] as const;
export const LEVEL_VALUE_MULT = [0, 1.0, 1.3, 1.8, 2.4, 3.2] as const;

/**
 * Defence **dice** added by level, cumulative (L2 +1, L4 +1, L5 +2).
 * A Fortress therefore fields 2 garrisoned crew + 4 = 6 dice minimum.
 *
 * KNOWN OPEN ITEM: the GDD deliberately did not retune this in the review
 * revision, so the Heat fix could be measured on its own. Revisit only after
 * the Monte-Carlo win-rate table and the Heat simulation are both in.
 */
export const LEVEL_DEFENCE = [0, 0, 1, 1, 2, 4] as const;

/** Level 2 and 5 are reached by garrisoning, not paying. */
export const UPGRADE_PRICE_MULT: Record<3 | 4 | 5, number> = {
  3: 0.6,
  4: 0.9,
  5: 1.3,
};

export const COSTS = {
  crewCash: 250,
  crewDirty: 200,
  inmateCrew: 125,
  enforcerCash: 400,
  enforcerRespect: 2,
  docksStipend: 200,
  airportFee: 150,
  bail: 200,
  respectPrice: 150,
  respectMaxPerVisit: 3,
  moneyBagWindfall: 150,
  jackpotCasinoStrip: 200,
  jackpotCasinoKing: 100,
  /** Each decline knocks 10% off list, cumulative, floored at 50%. */
  declineMarkdown: 0.1,
  declineFloor: 0.5,
} as const;

export const PROTECTION = {
  rate: 0.15,
  markup: 1.2,
  districtMult: 1.5,
} as const;

// ─── Combat ──────────────────────────────────────────────────────────────────

export const COMBAT = {
  /** Roll d6 equal to strength, keep the best this many. */
  diceKept: 2,
  minDice: 1,
  /** Ties go to the defender. Not a knob — flipping it is a design change. */
  tiesToDefender: true,
  enforcerCrewValue: 2,
} as const;

export const AGGRESSION = {
  strikeHeat: 1,
  strikeWinnerRespect: 1,
  turfWarHeat: 2,
  turfWarWinnerRespect: 2,
  turfWarLoserRespect: -1,
  refuseHeat: 1,
  refuseWinnerRespect: 1,
  refuseLoserOwnerRespect: -1,
  /** How far a strike reaches from the attacker's token. */
  strikeRangeTiles: 6,
} as const;

// ─── Heat ────────────────────────────────────────────────────────────────────

export const HEAT = {
  min: 0,
  max: 10,

  /** +1 Heat per this much Dirty Money held at upkeep (floored). */
  dirtyStep: 400,

  /** Band floors: < watched = Clean. */
  watchedAt: 3,
  raidsAt: 6,
  federalAt: 9,

  /** Illegal tiles pay this much less while Watched or worse. */
  watchedIllegalPenalty: 0.25,

  /** Upkeep raid fires when a d6 rolls at least this. */
  raidRollAtLeast: 5,
  federalRaidRollAtLeast: 3,

  /** Empire Value above this multiple of the table mean is Most Wanted. */
  mostWantedMult: 1.25,
  mostWantedHeat: 1,

  /** Shed for holding zero Dirty Money at upkeep. */
  cleanUpkeepShed: 1,

  /**
   * ⚠️ THE DECISION THAT MAKES OR BREAKS THE ANTI-RUNAWAY BRAKE.
   *
   * `false` — the clean-upkeep shed is suppressed while you are Most Wanted.
   * A clean leader then nets +1 Heat/round, reaches Raids around round 6 and
   * Federal around round 9, and the territory-seizure clause actually fires.
   *
   * `true` — the published GDD behaviour, where Most Wanted (+1) and the clean
   * shed (−1) cancel exactly. A clean leader nets ~+0.17/round from the Police
   * die alone, tops out near Heat 3 over a full match, and is **never raided** —
   * so seizure, which the GDD calls load-bearing, never executes.
   *
   * Defaulted to `false` pending sign-off; flip and re-run the Heat simulation
   * to reproduce the broken case.
   */
  cleanShedAppliesToMostWanted: false,

  /** Heat on release from jail. The only hard reset in the game. */
  jailRelease: 2,
  safehouseShed: 1,
  bribeSuccessShed: 3,
  bribeFailHeat: 2,
} as const;

export const LAUNDER_RATES = {
  safehouse: 0.8,
  moneyLaundryOwned: 0.75,
  elsewhere: 0.6,
  /** Forced conversion when settling a debt you cannot cover. */
  forced: 0.5,
  /** The Smuggler adds this to whichever rate applies. */
  smugglerBonus: 0.1,
} as const;

/** Pay a tier, roll d6, succeed on `succeedsAtLeast`. Every tier clears p>0.4. */
export const BRIBE_TIERS = [
  { cost: 300, succeedsAtLeast: 4 },
  { cost: 600, succeedsAtLeast: 3 },
  { cost: 1000, succeedsAtLeast: 2 },
] as const;

export const JAIL = {
  maxTurns: 3,
  inmateCrewPerTurn: 1,
  doublesToJail: 3,
} as const;

// ─── Scoring and victory ─────────────────────────────────────────────────────

export const EMPIRE_VALUE = {
  /** Dirty Money is halved — it isn't really yours until it's clean. */
  dirtyWeight: 0.5,
  /** Pool crew only. Garrisoned crew are already priced in via LEVEL_VALUE_MULT. */
  crewWeight: 150,
  respectWeight: 100,
} as const;

export const RESPECT = {
  min: 0,
  max: 40,
  /** Everyone gets this for completing a district; the Godfather gets double. */
  perDistrictCompleted: 1,
  godfatherPerDistrictCompleted: 2,
} as const;

export const KINGPIN = {
  districts: 4,
  respect: 30,
  /** Heat must be strictly below this. */
  maxHeat: 6,
} as const;

export const BROKEN = {
  bailout: 500,
  respectPenalty: 3,
  /** Capped so going broke can never become a strategy. */
  maxBailoutsPerMatch: 2,
} as const;

// ─── Bosses ──────────────────────────────────────────────────────────────────

export type BossId =
  | "godfather"
  | "drug-lord"
  | "casino-king"
  | "smuggler"
  | "corrupt-politician"
  | "street-boss";

/** Passives only in v1 — all six actives were cut (GDD > The six bosses). */
export const BOSSES: Array<{ id: BossId; name: string; passive: string }> = [
  { id: "godfather", name: "The Godfather", passive: "Completing a district pays +2 Respect" },
  { id: "drug-lord", name: "The Drug Lord", passive: "Dirty Money income pays +25%" },
  { id: "casino-king", name: "The Casino King", passive: "Doubles pay a $100 jackpot" },
  { id: "smuggler", name: "The Smuggler", passive: "Laundering returns 10 points more" },
  { id: "corrupt-politician", name: "The Corrupt Politician", passive: "Bribes cost 50% less" },
  { id: "street-boss", name: "The Street Boss", passive: "Crew cost −25%" },
];

export const BOSS_MODIFIERS = {
  drugLordDirtyBoost: 0.25,
  smugglerLaunderBonus: 0.1,
  corruptPoliticianBribeDiscount: 0.5,
  streetBossCrewDiscount: 0.25,
  /** Does not stack with Street Boss — take the better of the two. */
  oldTownCrewDiscount: 0.25,
  harborDirtyBoost: 0.5,
  industrialUpgradeDiscount: 0.5,
  downtownProtectionBoost: 0.5,
} as const;

// ─── Bot ─────────────────────────────────────────────────────────────────────

/**
 * Weights behind the heuristic table in the GDD. The full utility model belongs
 * in `design/gdd/empire-wars-bot.md` before the bot is scoped — these are the
 * v1 contract values, not a finished tuning pass.
 */
export const BOT = {
  /** Minimum assessed value before buying a tile that doesn't complete a district. */
  buyThreshold: 300,
  /** Never spend below this much cash. */
  cashFloor: 400,
  /** Crew advantage needed before refusing to pay, striking, or declaring war. */
  fightMargin: 1,
  /** Heat at or above which it dumps Dirty Money. */
  launderHeat: 6,
  /** Heat above which it stops taking Dirty income. */
  dirtyHeatCap: 3,
  /** Heat at or above which it will bribe. */
  bribeHeat: 7,
  /** Another player is "stronger" when their EV exceeds the bot's by this. */
  strongerMargin: 0.15,
  /** Added to assessed value when a purchase completes a district. */
  districtBonusWeight: 500,
  /** Keep at least this many crew in the pool before garrisoning. */
  poolCrewFloor: 2,
  /** Respect needed before buying an enforcer. */
  enforcerMinRespect: 10,
  /** Pay bail when cash is at least this multiple of the bail cost. */
  bailCashMultiple: 3,
} as const;
