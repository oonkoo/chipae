"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { pieceForSeat } from "./icons";

// The pieces on the board, and how they walk it.
//
// A piece animates by *stepping* — one tile at a time, with a small hop — so
// movement reads as walking the block rather than teleporting. The server has
// already decided the destination; this only shows the journey.

export const STEP_MS = 120;

function prefersReducedMotion(): boolean {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

export type PieceSeat = {
  memberId: string;
  seat: number;
  tile: number;
  color: string;
  label: string;
  eliminated: boolean;
  inJail: boolean;
};

/**
 * Where every piece should be drawn right now.
 *
 * Returns the *animated* tile per member, which lags the server's tile while a
 * walk is in progress. Everything else on the board reads from the server
 * directly; only the piece's position is interpolated.
 */
export function useWalkingPieces(
  seats: PieceSeat[],
  lastRoll: { memberId: string; from: number; to: number; seq: number } | null,
  boardSize: number
): Record<string, number> {
  /**
   * Only the walking piece is ever overridden, and only from a timer. Every
   * other piece is *derived* from the server position below, so there is no
   * copy of the board's truth to fall out of sync — and no effect that writes
   * state just to mirror props.
   */
  const [walk, setWalk] = useState<{ memberId: string; tile: number } | null>(
    null
  );
  const lastSeq = useRef<number | null>(null);
  const timers = useRef<Array<ReturnType<typeof setTimeout>>>([]);

  useEffect(() => {
    if (!lastRoll) return;
    if (lastSeq.current === lastRoll.seq) return;

    // The first roll we observe may have happened before we were watching —
    // joining a game in progress shouldn't replay someone else's move.
    const isFirst = lastSeq.current === null;
    lastSeq.current = lastRoll.seq;
    if (isFirst || prefersReducedMotion()) return;

    const steps: number[] = [];
    let cursor = lastRoll.from;
    // Bounded: corrupt from/to must not spin forever.
    for (let i = 0; i < boardSize && cursor !== lastRoll.to; i++) {
      cursor = (cursor + 1) % boardSize;
      steps.push(cursor);
    }
    if (steps.length === 0) return;

    timers.current.forEach(clearTimeout);
    timers.current = [
      // Snap back to the origin, then walk. Deferred by a tick so the state
      // write happens from a timer rather than from the effect body.
      setTimeout(
        () => setWalk({ memberId: lastRoll.memberId, tile: lastRoll.from }),
        0
      ),
      ...steps.map((tile, i) =>
        setTimeout(
          () => setWalk({ memberId: lastRoll.memberId, tile }),
          // The dice land first; the piece leaves once they settle.
          260 + i * STEP_MS
        )
      ),
      // Hand control back to the server position at the end of the walk.
      setTimeout(() => setWalk(null), 260 + steps.length * STEP_MS + 40),
    ];

    return () => {
      timers.current.forEach(clearTimeout);
      timers.current = [];
    };
  }, [lastRoll, boardSize]);

  const positions: Record<string, number> = {};
  for (const seat of seats) {
    positions[seat.memberId] =
      walk && walk.memberId === seat.memberId ? walk.tile : seat.tile;
  }
  return positions;
}

/** One piece, sitting on a tile. */
export function GamePiece({
  seat,
  isYou,
  moving,
  className,
}: {
  seat: PieceSeat;
  isYou: boolean;
  moving: boolean;
  className?: string;
}) {
  const { Piece, name } = pieceForSeat(seat.seat);
  return (
    <span
      className={cn(
        "flex items-center justify-center rounded-full border shadow-md transition-transform",
        seat.eliminated && "opacity-35 grayscale",
        moving && "motion-safe:[animation:ew-hop_var(--ew-step)_ease-in-out]",
        isYou && "ring-1 ring-[var(--ew-gold)]",
        className
      )}
      style={
        {
          background: `color-mix(in srgb, ${seat.color} 88%, black)`,
          borderColor: "rgba(0,0,0,.55)",
          color: "var(--ew-ink)",
          "--ew-step": `${STEP_MS}ms`,
        } as React.CSSProperties
      }
      title={`${seat.label} — ${name}${seat.inJail ? " (inside)" : ""}`}
    >
      <Piece className="size-[62%]" />
    </span>
  );
}
