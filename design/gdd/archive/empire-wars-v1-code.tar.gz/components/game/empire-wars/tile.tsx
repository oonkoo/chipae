import Image from "next/image";
import { cn } from "@/lib/utils";
import type { TerritoryView } from "@/lib/game/empire-wars/view";
import { GamePiece, type PieceSeat } from "./pieces";

// One board tile, drawn in DOM/CSS like Nuno's cards — no canvas.
//
// Colour comes from the game's own `--ew-*` tokens, never app theme tokens: a
// board looks the same in any theme. Owner colour is the one exception, and it
// uses the *platform* seat tokens so a player is the same colour here as in
// the lobby (design/art-direction.md).

const DISTRICT_ORDER = [
  "old-town",
  "little-havana",
  "harbor",
  "industrial",
  "downtown",
  "nightclub",
  "casino-strip",
  "financial",
] as const;

export function districtVar(district: string): string {
  const index = DISTRICT_ORDER.indexOf(district as (typeof DISTRICT_ORDER)[number]);
  return `var(--ew-district-${index < 0 ? 1 : index + 1})`;
}

/**
 * Per-tile artwork. Files are dropped at `public/games/empire-wars/tiles/<id>.svg`
 * and appear automatically — see `design/empire-wars-art-manifest.md`.
 *
 * `hasArt` is a manifest, not a filesystem check: a component cannot stat a
 * file, and a missing `<Image>` src logs a 404 on every render. Flip an entry
 * to true when its art lands.
 */
export const TILE_ART: Record<string, boolean> = {};

export function tileArtSrc(id: string): string | null {
  return TILE_ART[id] ? `/games/empire-wars/tiles/${id}.svg` : null;
}

/** Level as pips — legible at 40px where a number would not be. */
function LevelPips({ level }: { level: number }) {
  if (level <= 1) return null;
  return (
    <span className="flex gap-[1px]" aria-label={`Level ${level}`}>
      {Array.from({ length: level - 1 }, (_, i) => (
        <span
          key={i}
          className="block size-[3px] rounded-full"
          style={{ background: "var(--ew-gold)" }}
        />
      ))}
    </span>
  );
}

/** Pieces standing on a tile, stacked tight so four still fit. */
function PieceStack({
  seats,
  youId,
  movingId,
  compact,
}: {
  seats: PieceSeat[];
  youId: string | null;
  movingId: string | null;
  compact?: boolean;
}) {
  if (seats.length === 0) return null;
  return (
    <span
      className={cn(
        "pointer-events-none absolute flex -space-x-1",
        compact ? "top-1 right-1" : "-top-1 -right-1"
      )}
    >
      {seats.map((seat) => (
        <GamePiece
          key={seat.memberId}
          seat={seat}
          isYou={seat.memberId === youId}
          moving={seat.memberId === movingId}
          className={compact ? "size-5" : "size-[18px]"}
        />
      ))}
    </span>
  );
}

export function TerritoryTile({
  territory,
  seatColor,
  youAreHere,
  seats,
  youId,
  movingId,
  onSelect,
  selected,
  compact = false,
}: {
  territory: TerritoryView;
  /** chart-N var for the owner, or null when unowned. */
  seatColor: string | null;
  youAreHere: boolean;
  /** Pieces standing on this tile. */
  seats: PieceSeat[];
  youId: string | null;
  movingId: string | null;
  onSelect?: () => void;
  selected?: boolean;
  compact?: boolean;
}) {
  const owned = !!territory.ownerId;
  const art = tileArtSrc(territory.id);
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-label={`${territory.name}${owned ? ", owned" : `, $${territory.price}`}`}
      className={cn(
        "relative flex flex-col overflow-hidden rounded-[3px] border text-left transition-shadow",
        compact ? "min-h-14 p-1" : "h-full w-full p-[3px]",
        selected && "ring-2 ring-[var(--ew-gold)]",
        youAreHere && "shadow-[0_0_0_2px_var(--ew-gold)]"
      )}
      style={{
        background: owned
          ? `color-mix(in srgb, ${seatColor} 22%, var(--ew-ink))`
          : "color-mix(in srgb, var(--ew-paper) 8%, var(--ew-ink))",
        borderColor: owned
          ? `color-mix(in srgb, ${seatColor} 55%, transparent)`
          : "color-mix(in srgb, var(--ew-paper) 16%, transparent)",
      }}
    >
      {/* District band — the property strip. */}
      <span
        aria-hidden
        className="mb-[2px] block h-[4px] w-full shrink-0 rounded-[1px]"
        style={{ background: districtVar(territory.district) }}
      />

      {art && (
        <Image
          src={art}
          alt=""
          width={64}
          height={64}
          className="pointer-events-none absolute inset-0 m-auto w-[58%] opacity-25"
        />
      )}

      <span
        className={cn(
          "relative block leading-[1.05] font-medium text-[var(--ew-paper)]",
          compact ? "text-[10px]" : "text-[7px] sm:text-[8px]"
        )}
      >
        {territory.name}
      </span>

      <span className="relative mt-auto flex items-center justify-between gap-1">
        <span
          className={cn(
            "font-mono tabular-nums text-[var(--ew-gold)]",
            compact ? "text-[10px]" : "text-[7px]"
          )}
        >
          {owned ? `$${territory.fee}` : `$${territory.price}`}
        </span>
        <LevelPips level={territory.level} />
      </span>

      <PieceStack
        seats={seats}
        youId={youId}
        movingId={movingId}
        compact={compact}
      />
    </button>
  );
}

export function SpecialTile({
  id,
  name,
  seats,
  youId,
  movingId,
  youAreHere,
  compact = false,
}: {
  id: string;
  name: string;
  seats: PieceSeat[];
  youId: string | null;
  movingId: string | null;
  youAreHere: boolean;
  compact?: boolean;
}) {
  const art = tileArtSrc(id);
  return (
    <div
      className={cn(
        "relative flex flex-col items-center justify-center rounded-[3px] border text-center",
        compact ? "min-h-14 p-1" : "h-full w-full p-1",
        youAreHere && "shadow-[0_0_0_2px_var(--ew-gold)]"
      )}
      style={{
        background: "color-mix(in srgb, var(--ew-neon) 12%, var(--ew-ink))",
        borderColor: "color-mix(in srgb, var(--ew-gold) 35%, transparent)",
      }}
    >
      {art && (
        <Image
          src={art}
          alt=""
          width={64}
          height={64}
          className="pointer-events-none absolute inset-0 m-auto w-[52%] opacity-30"
        />
      )}
      <span
        className={cn(
          "relative font-heading leading-tight text-[var(--ew-gold)]",
          compact ? "text-[11px]" : "text-[7px] sm:text-[9px]"
        )}
      >
        {name}
      </span>
      <PieceStack
        seats={seats}
        youId={youId}
        movingId={movingId}
        compact={compact}
      />
    </div>
  );
}
