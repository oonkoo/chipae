"use client";

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { RiVipCrownFill } from "@remixicon/react";
import { advanceBot, submitMove } from "@/lib/actions/games";
import {
  EMPIRE_WARS_CONFIG,
  KINGPIN,
  SPECIAL_TILES,
  TERRITORIES,
} from "@/lib/game/data/empire-wars";
import type { EmpireView } from "@/lib/game/empire-wars/view";
import type { EmpireMove } from "@/lib/game/empire-wars/turn";
import type { BoardMember } from "@/components/game/types";
import { cn } from "@/lib/utils";
import { SpecialTile, TerritoryTile, districtVar } from "./tile";
import { DecisionOverlay } from "./decision-overlay";
import { DiceTray } from "./dice";
import { useWalkingPieces, type PieceSeat } from "./pieces";
import { CURRENCY_ICON, pieceForSeat } from "./icons";
import { EmpireRail } from "./rail";
import { coachFor } from "@/lib/game/empire-wars/coach";

// The Empire Wars table. Presentation only — every rule lives in
// lib/game/empire-wars/ and the server decides every move.
//
// Two layouts, one rule set: a 32-tile ring on desktop, eight district columns
// on a phone. Adjacency is a declared list in the rules, not board geometry,
// which is exactly what makes that possible (GDD > Edge Cases > Adjacency).

const RING = 32;

/** Tile index → cell in a 9×9 grid, walking clockwise from bottom-right. */
function ringCell(tile: number): { row: number; col: number } {
  if (tile <= 8) return { row: 9, col: 9 - tile };
  if (tile <= 16) return { row: 17 - tile, col: 1 };
  if (tile <= 24) return { row: 1, col: tile - 15 };
  return { row: tile - 23, col: 9 };
}

function specialAt(tile: number) {
  return SPECIAL_TILES.find((s) => s.tile === tile) ?? null;
}
function territoryAt(tile: number) {
  return TERRITORIES.find((t) => t.tile === tile) ?? null;
}

export function EmpireWarsBoard({
  lobbyId,
  view,
  members,
  hostId,
}: {
  lobbyId: string;
  view: EmpireView;
  members: BoardMember[];
  hostId: string;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const botTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const resolverTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const turnTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const byId = new Map(members.map((m) => [m.id, m]));
  const you = view.you;
  const yourTurn = view.currentMemberId === you?.memberId;

  const label = useCallback(
    (memberId: string) => {
      const member = byId.get(memberId);
      if (!member) return "A departed boss";
      return member.isBot
        ? (member.botName ?? "CPU")
        : member.displayName || `@${member.username}`;
    },
    // byId is derived from props and stable enough for a label lookup.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [members]
  );

  const seatColor = useCallback(
    (memberId: string | null) => {
      if (!memberId) return null;
      const seat = byId.get(memberId)?.seat ?? 1;
      return `var(--chart-${seat})`;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [members]
  );

  /**
   * Run a server action. No `router.refresh()` — the action revalidates the
   * game route itself, so its response already carries the new render.
   * Refreshing as well doubles the queries for every move.
   */
  function run(action: () => Promise<{ ok: boolean }>) {
    setError(null);
    startTransition(async () => {
      const result = (await action()) as
        | { ok: true }
        | { ok: false; error: string };
      if (!result.ok) setError(result.error);
    });
  }

  const move = useCallback(
    (next: EmpireMove) => run(() => submitMove(lobbyId, next)),
    // run is stable for our purposes; lobbyId is the only real dependency.
     
    [lobbyId]
  );

  // ── Bot driver ────────────────────────────────────────────────────────────
  // Whoever is watching asks the server to play one move for a CPU after a
  // casual pause. The lobby lock plus the whose-turn check make duplicate
  // calls harmless, so racing clients are fine.
  //
  // **Keyed on `view.version`, which moves on every single applied move.** A
  // CPU turn is several moves — roll, buy, upgrade, end — and an effect keyed
  // on anything coarser (phase, round) simply stops re-firing partway through,
  // leaving the table stuck on "…is thinking".
  const onClock = view.pending?.memberId ?? view.currentMemberId;
  const onClockIsBot = (() => {
    const member = byId.get(onClock);
    return !member || member.isBot;
  })();

  useEffect(() => {
    if (!onClockIsBot || view.winnerId) return;
    const delay =
      EMPIRE_WARS_CONFIG.botDelayMsMin +
      Math.random() *
        (EMPIRE_WARS_CONFIG.botDelayMsMax - EMPIRE_WARS_CONFIG.botDelayMsMin);
    botTimer.current = setTimeout(() => {
      void advanceBot(lobbyId);
    }, delay);
    return () => {
      if (botTimer.current) clearTimeout(botTimer.current);
    };
  }, [onClockIsBot, onClock, view.version, view.winnerId, lobbyId, router]);

  // ── Turn clock ────────────────────────────────────────────────────────────
  // A human who walked away must not freeze everyone else's match. Once their
  // window passes, any client may ask the server to play a move for them; the
  // server re-checks the deadline against its own clock and refuses if early.
  // CPU seats never reach here — the driver above already has them covered.
  useEffect(() => {
    if (onClockIsBot || view.winnerId || view.turnExpiresAt === null) return;
    const wait =
      Math.max(0, view.turnExpiresAt - Date.now()) +
      Math.random() * EMPIRE_WARS_CONFIG.decisionJitterMaxMs;
    turnTimer.current = setTimeout(() => {
      void advanceBot(lobbyId);
    }, wait);
    return () => {
      if (turnTimer.current) clearTimeout(turnTimer.current);
    };
  }, [onClockIsBot, view.turnExpiresAt, view.version, view.winnerId, lobbyId, router]);

  // ── Lazy decision resolver ────────────────────────────────────────────────
  // Serverless has no clock, so a deadline only fires because a client calls
  // in. Every connected client computes the *same* absolute deadline, so the
  // call is jittered — otherwise six browsers hit one advisory lock at once.
  // The server re-checks expiry against its own clock and rejects early calls.
  useEffect(() => {
    const deadline = view.pending?.expiresAt;
    if (!deadline || view.winnerId) return;
    const wait =
      Math.max(0, deadline - Date.now()) +
      Math.random() * EMPIRE_WARS_CONFIG.decisionJitterMaxMs;
    resolverTimer.current = setTimeout(() => {
      void submitMove(lobbyId, { kind: "resolveExpired" });
    }, wait);
    return () => {
      if (resolverTimer.current) clearTimeout(resolverTimer.current);
    };
  }, [view.pending?.expiresAt, view.winnerId, lobbyId, router]);

  // ── Pieces ────────────────────────────────────────────────────────────────
  // Everything else reads the server's position directly; only the piece lags,
  // walking tile by tile while the rest of the board is already up to date.
  const pieceSeats: PieceSeat[] = view.seats.map((s) => ({
    memberId: s.memberId,
    seat: byId.get(s.memberId)?.seat ?? 1,
    tile: s.tile,
    color: seatColor(s.memberId) ?? "var(--chart-1)",
    label: label(s.memberId),
    eliminated: s.eliminated,
    inJail: s.inJail,
  }));
  const walked = useWalkingPieces(pieceSeats, view.lastRoll, RING);
  const movingId = view.lastRoll?.memberId ?? null;

  const seatsOn = (tile: number) =>
    pieceSeats.filter(
      (s) => !s.eliminated && (walked[s.memberId] ?? s.tile) === tile
    );

  const cells = Array.from({ length: RING }, (_, tile) => {
    const { row, col } = ringCell(tile);
    const special = specialAt(tile);
    const def = territoryAt(tile);
    const here = you ? (walked[you.memberId] ?? -1) === tile : false;

    return (
      <div key={tile} style={{ gridRow: row, gridColumn: col }}>
        {special ? (
          <SpecialTile
            id={special.kind}
            name={special.name}
            seats={seatsOn(tile)}
            youId={you?.memberId ?? null}
            movingId={movingId}
            youAreHere={here}
          />
        ) : def ? (
          <TerritoryTile
            territory={view.territories.find((t) => t.id === def.id)!}
            seatColor={seatColor(
              view.territories.find((t) => t.id === def.id)!.ownerId
            )}
            youAreHere={here}
            seats={seatsOn(tile)}
            youId={you?.memberId ?? null}
            movingId={movingId}
            selected={selected === def.id}
            onSelect={() => setSelected(selected === def.id ? null : def.id)}
          />
        ) : null}
      </div>
    );
  });

  const canAct = yourTurn && !pending && !view.winnerId && !view.pending;

  const selectedTile = selected
    ? view.territories.find((t) => t.id === selected)
    : null;

  // One sentence and one obvious button, derived from the same view the board
  // renders — so the guidance can never suggest an illegal move.
  const coach = coachFor(view, label);

  return (
    // Everything lives on the felt: rivals along the top, the city in the
    // middle, your own rail along the bottom. Nothing about the game sits
    // outside the table.
    <div
      className="relative flex min-w-0 flex-col gap-3 overflow-hidden rounded-3xl border border-white/10 p-2 sm:p-3"
        style={{
          background:
            "radial-gradient(100% 80% at 50% 45%, var(--ew-felt-center) 0%, var(--ew-felt-edge) 100%)",
        }}
    >
      {/* ── Rivals, along the top edge ──────────────────────────────────── */}
      <div className="flex flex-wrap justify-center gap-1.5">
        {view.seats
          .filter((s) => s.memberId !== you?.memberId)
          .map((seat) => {
            const member = byId.get(seat.memberId);
            const { Piece } = pieceForSeat(member?.seat ?? 1);
            const onTheClock = view.currentMemberId === seat.memberId;
            return (
              <div
                key={seat.memberId}
                className={cn(
                  "flex min-w-0 items-center gap-1.5 rounded-full border px-2 py-1 backdrop-blur-sm transition-colors",
                  onTheClock
                    ? "border-[var(--ew-gold)] bg-[color-mix(in_srgb,var(--ew-gold)_18%,transparent)]"
                    : "border-white/10 bg-black/30",
                  seat.eliminated && "opacity-40"
                )}
              >
                <span
                  className="flex size-6 shrink-0 items-center justify-center rounded-full border border-black/50"
                  style={{
                    background: `color-mix(in srgb, ${seatColor(seat.memberId)} 88%, black)`,
                    color: "var(--ew-ink)",
                  }}
                >
                  <Piece className="size-[62%]" />
                </span>
                <span className="flex flex-col leading-tight">
                  <span className="flex items-center gap-1 text-[11px] font-medium text-foreground">
                    {member?.userId === hostId && (
                      <RiVipCrownFill className="size-3 text-primary" />
                    )}
                    <span className="max-w-20 truncate">{label(seat.memberId)}</span>
                    {seat.mostWanted && (
                      <span
                        className="rounded-full px-1 font-heading text-[8px] text-black"
                        style={{ background: "var(--ew-heat-federal)" }}
                        title="Their empire is the biggest — the police have noticed"
                      >
                        WANTED
                      </span>
                    )}
                    {seat.inJail && (
                      <span className="text-[9px] text-muted-foreground">inside</span>
                    )}
                  </span>
                  <span className="flex items-center gap-1.5 font-mono text-[9px] text-muted-foreground">
                    <IconStat icon="empire" value={seat.territories} title="territories" />
                    <IconStat icon="crew" value={seat.crew} title="crew" />
                    <IconStat icon="respect" value={seat.respect} title="respect" />
                    <IconStat
                      icon="heat"
                      value={seat.heat}
                      title="heat"
                      tone="var(--ew-heat-raid)"
                    />
                  </span>
                </span>
              </div>
            );
          })}
      </div>

      {/* Desktop: the ring. Capped so the whole city stays on screen with
            the rail — an uncapped square grid in a wide column is taller than
            the viewport. */}
        <div
          className="mx-auto hidden aspect-square w-full max-w-[min(100%,38rem)] grid-cols-9 grid-rows-9 gap-[2px] md:grid"
          aria-label="The city"
        >
          {cells}
          {/* The middle of the table. */}
          <div
            className="flex flex-col items-center justify-center gap-2 p-4 text-center"
            style={{ gridRow: "2 / 9", gridColumn: "2 / 9" }}
          >
            <p className="font-heading text-2xl text-[var(--ew-gold)]">
              Round {view.round}
              <span className="text-base text-muted-foreground">
                /{view.roundLimit}
              </span>
            </p>
            <p className="text-sm text-foreground">
              {view.winnerId
                ? `${label(view.winnerId)} runs the city`
                : yourTurn
                  ? "Your move"
                  : `${label(view.currentMemberId)} is thinking…`}
            </p>

            {/* The dice land in the middle of the table, where everyone can
                see them. The result is already decided server-side — the
                tumble is theatre over a known outcome. */}
            <DiceTray roll={view.lastRoll} face={view.dieFace} />
            {you && (
              <p className="font-mono text-[11px] text-muted-foreground">
                Kingpin {you.kingpinProgress.districts}/{KINGPIN.districts} districts ·{" "}
                {you.kingpinProgress.respect}/{KINGPIN.respect} Respect ·{" "}
                Heat {you.kingpinProgress.heat}
                {you.kingpinProgress.heat < KINGPIN.maxHeat ? " ✓" : " ✗"}
              </p>
            )}
            {view.log.length > 0 && (
              <p className="mt-1 max-w-56 text-[11px] leading-snug text-muted-foreground">
                {view.log[view.log.length - 1]}
              </p>
            )}
          </div>
        </div>

        {/* Mobile: eight district columns. Same rules, different picture. */}
        <div className="flex flex-col gap-2 md:hidden">
          <p className="text-center font-heading text-lg text-[var(--ew-gold)]">
            Round {view.round}/{view.roundLimit}
          </p>
          <div className="grid grid-cols-2 gap-2">
            {[
              "old-town",
              "little-havana",
              "harbor",
              "industrial",
              "downtown",
              "nightclub",
              "casino-strip",
              "financial",
            ].map((district) => (
              <div key={district} className="flex flex-col gap-1">
                <span
                  className="h-[3px] w-full rounded-full"
                  style={{ background: districtVar(district) }}
                />
                {view.territories
                  .filter((t) => t.district === district)
                  .map((t) => (
                    <TerritoryTile
                      key={t.id}
                      compact
                      territory={t}
                      seatColor={seatColor(t.ownerId)}
                      youAreHere={false}
                      seats={seatsOn(
                        TERRITORIES.find((d) => d.id === t.id)!.tile
                      )}
                      youId={you?.memberId ?? null}
                      movingId={movingId}
                      selected={selected === t.id}
                      onSelect={() =>
                        setSelected(selected === t.id ? null : t.id)
                      }
                    />
                  ))}
              </div>
            ))}
          </div>
        </div>

        {view.pending && (
          <DecisionOverlay
            view={view}
            youId={you?.memberId ?? null}
            windowMs={EMPIRE_WARS_CONFIG.decisionWindowMs}
            pending={view.pending}
            onPay={() => move({ kind: "payFee" })}
            onRefuse={() => move({ kind: "refuseFee" })}
            onAnswerTruce={(accept) => move({ kind: "answerTruce", accept })}
            labelFor={label}
          />
        )}

      {/* ── Your rail, along the bottom edge ────────────────────────────── */}
      <EmpireRail
        view={view}
        coach={coach}
        onMove={move}
        disabled={!canAct}
        error={error}
      />

      {/* What you last tapped on the board — a plain reading of the tile. */}
      {selectedTile && (
        <p className="px-1 text-[11px] text-muted-foreground">
          <span className="text-foreground">{selectedTile.name}</span> ·{" "}
          {selectedTile.districtName} ·{" "}
          {selectedTile.ownerId
            ? selectedTile.ownerId === you?.memberId
              ? `yours, level ${selectedTile.level} · earns $${selectedTile.income} a round · visitors pay $${selectedTile.fee}`
              : `${label(selectedTile.ownerId)}'s · land here and you owe $${selectedTile.fee} · ${selectedTile.defence} guarding it`
            : `free · $${selectedTile.price} to buy · would earn you $${selectedTile.income} a round`}
        </p>
      )}

    </div>
  );
}

/** A rival's number, led by its icon — no room for words in the strip. */
function IconStat({
  icon,
  value,
  title,
  tone,
}: {
  icon: keyof typeof CURRENCY_ICON;
  value: number;
  title: string;
  tone?: string;
}) {
  const Icon = CURRENCY_ICON[icon];
  return (
    <span className="flex items-center gap-0.5" title={title}>
      <Icon className="size-2.5" style={tone ? { color: tone } : undefined} />
      {value}
    </span>
  );
}

