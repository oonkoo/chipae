import {
  RiBankFill,
  RiCarFill,
  RiCoinsFill,
  RiCrosshair2Fill,
  RiFireFill,
  RiHandCoinFill,
  RiMedalFill,
  RiMoneyDollarCircleFill,
  RiPoliceBadgeFill,
  RiQuestionFill,
  RiShakeHandsFill,
  RiTeamFill,
  type RemixiconComponentType,
} from "@remixicon/react";

// The game's iconography.
//
// Currency icons come from Remix Icon (the repo's library — not lucide).
// Player pieces are hand-drawn inline SVG rather than icon-font glyphs: they
// are the one place the game needs *objects* rather than symbols, and they
// must read as a silhouette at 16px on a crowded tile.

export const CURRENCY_ICON: Record<string, RemixiconComponentType> = {
  cash: RiMoneyDollarCircleFill,
  dirty: RiHandCoinFill,
  respect: RiMedalFill,
  crew: RiTeamFill,
  empire: RiBankFill,
  heat: RiFireFill,
};

// ─── Player pieces ───────────────────────────────────────────────────────────
// Prohibition-era objects, in the spirit of Monopoly's boot and thimble: a
// fedora, a roadster, a tommy gun, a tumbler, a cigar, a pocket watch. One per
// seat, assigned by seat order so a player's piece matches their seat colour.

type PieceProps = { className?: string; title?: string };

function Piece({
  children,
  className,
  title,
}: PieceProps & { children: React.ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      role={title ? "img" : "presentation"}
      aria-label={title}
      aria-hidden={title ? undefined : true}
    >
      {children}
    </svg>
  );
}

/** Seat 1 — the boss's hat. */
export function FedoraPiece(props: PieceProps) {
  return (
    <Piece {...props}>
      <path d="M12 3c-2.6 0-4.4 1.9-4.4 4.6v4.1c-2.8.5-4.6 1.5-4.6 2.8C3 16.4 7 18 12 18s9-1.6 9-3.5c0-1.3-1.8-2.3-4.6-2.8V7.6C16.4 4.9 14.6 3 12 3z" />
      <path
        d="M7.6 10.4h8.8"
        stroke="rgba(0,0,0,.45)"
        strokeWidth="2.2"
        fill="none"
      />
    </Piece>
  );
}

/** Seat 2 — the getaway roadster. */
export function RoadsterPiece(props: PieceProps) {
  return (
    <Piece {...props}>
      <path d="M3.2 15.4l1.4-3.6c.3-.8 1-1.3 1.9-1.3h1.9l1.5-1.6c.4-.4.9-.6 1.4-.6h3.3c.6 0 1.1.2 1.5.7l1.3 1.5h1.1c.9 0 1.6.5 1.9 1.3l1.4 3.6v1.7h-2.2a2.3 2.3 0 0 1-4.5 0H9.9a2.3 2.3 0 0 1-4.5 0H3.2v-1.7z" />
      <circle cx="7.6" cy="17.1" r="1.6" />
      <circle cx="16.4" cy="17.1" r="1.6" />
    </Piece>
  );
}

/** Seat 3 — the chicago typewriter. */
export function TommyGunPiece(props: PieceProps) {
  return (
    <Piece {...props}>
      <path d="M2.5 8.6h13.1v2.1h2.6V8.6H21v3.5h-2.8v2.1h-2.3l-1.2 4.2h-2.2l1.2-4.2H9.4v4.2H7.3v-4.2H5.6l-3.1 2V8.6z" />
      <circle cx="10.6" cy="14.6" r="3.1" />
      <circle
        cx="10.6"
        cy="14.6"
        r="1.2"
        fill="rgba(0,0,0,.4)"
      />
    </Piece>
  );
}

/** Seat 4 — a glass of the good stuff. */
export function TumblerPiece(props: PieceProps) {
  return (
    <Piece {...props}>
      <path d="M5.6 4h12.8l-1.5 15.2c-.1.9-.8 1.6-1.7 1.6H8.8c-.9 0-1.6-.7-1.7-1.6L5.6 4z" />
      <path
        d="M6.6 11.6h10.8"
        stroke="rgba(0,0,0,.4)"
        strokeWidth="2"
        fill="none"
      />
    </Piece>
  );
}

/** Seat 5 — the cigar, still lit. */
export function CigarPiece(props: PieceProps) {
  return (
    <Piece {...props}>
      <path d="M3.6 18.9l11.6-8.4 2.6 3.6-11.6 8.4c-.6.4-1.4.3-1.9-.3l-1-1.4c-.4-.6-.3-1.4.3-1.9z" />
      <path d="M16.2 9.4l2.7-2c.6-.4 1.4-.3 1.9.3l1 1.4c.4.6.3 1.4-.3 1.9l-2.7 2-2.6-3.6z" />
      <path
        d="M12.4 6.6c1.4-1 .6-2.4 1.9-3.4"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        fill="none"
        opacity=".55"
      />
    </Piece>
  );
}

/** Seat 6 — the pocket watch, because timing is everything. */
export function PocketWatchPiece(props: PieceProps) {
  return (
    <Piece {...props}>
      <path d="M10.6 1.8h2.8c.5 0 .9.4.9.9v1.6h-4.6V2.7c0-.5.4-.9.9-.9z" />
      <circle cx="12" cy="13.4" r="8.2" />
      <circle cx="12" cy="13.4" r="6" fill="rgba(0,0,0,.35)" />
      <path
        d="M12 9.4v4h2.8"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        fill="none"
      />
    </Piece>
  );
}

export const PLAYER_PIECES = [
  { id: "fedora", name: "The Fedora", Piece: FedoraPiece },
  { id: "roadster", name: "The Roadster", Piece: RoadsterPiece },
  { id: "tommy-gun", name: "The Typewriter", Piece: TommyGunPiece },
  { id: "tumbler", name: "The Tumbler", Piece: TumblerPiece },
  { id: "cigar", name: "The Cigar", Piece: CigarPiece },
  { id: "pocket-watch", name: "The Pocket Watch", Piece: PocketWatchPiece },
] as const;

/** A seat's piece. Seats are 1-based; anything out of range wraps. */
export function pieceForSeat(seat: number) {
  return PLAYER_PIECES[(Math.max(1, seat) - 1) % PLAYER_PIECES.length];
}

// ─── The action die ──────────────────────────────────────────────────────────

/** Pip layout for a d6 face, on a 3×3 grid. */
const PIPS: Record<number, Array<[number, number]>> = {
  1: [[1, 1]],
  2: [
    [0, 0],
    [2, 2],
  ],
  3: [
    [0, 0],
    [1, 1],
    [2, 2],
  ],
  4: [
    [0, 0],
    [2, 0],
    [0, 2],
    [2, 2],
  ],
  5: [
    [0, 0],
    [2, 0],
    [1, 1],
    [0, 2],
    [2, 2],
  ],
  6: [
    [0, 0],
    [2, 0],
    [0, 1],
    [2, 1],
    [0, 2],
    [2, 2],
  ],
};

export function DieFace({
  value,
  className,
  style,
}: {
  value: number;
  className?: string;
  style?: React.CSSProperties;
}) {
  const pips = PIPS[Math.min(6, Math.max(1, value))] ?? PIPS[1];
  return (
    <svg
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label={`${value}`}
      role="img"
    >
      <rect
        x="1.5"
        y="1.5"
        width="21"
        height="21"
        rx="5"
        fill="var(--ew-paper)"
        stroke="var(--ew-gold-edge)"
        strokeWidth="1"
      />
      {pips.map(([col, row], i) => (
        <circle
          key={i}
          cx={6.5 + col * 5.5}
          cy={6.5 + row * 5.5}
          r="2.1"
          fill="var(--ew-ink)"
        />
      ))}
    </svg>
  );
}

/**
 * The action die's six faces. Icons rather than emoji: emoji render
 * differently on every platform and read as templated, which is exactly the
 * look design/art-direction.md rules out.
 */
export const ACTION_FACE_ICON: Record<string, RemixiconComponentType> = {
  "money-bag": RiCoinsFill,
  police: RiPoliceBadgeFill,
  gun: RiCrosshair2Fill,
  car: RiCarFill,
  handshake: RiShakeHandsFill,
  question: RiQuestionFill,
};

export const ACTION_FACE_LABEL: Record<string, string> = {
  "money-bag": "Money Bag",
  police: "Police",
  gun: "Gun",
  car: "Car",
  handshake: "Handshake",
  question: "Question",
};
