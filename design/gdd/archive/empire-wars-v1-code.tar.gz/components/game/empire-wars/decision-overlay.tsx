"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { EmpireView } from "@/lib/game/empire-wars/view";

// The standoff and the truce offer.
//
// Two rules from the GDD drive this component:
//
//  1. **Every timer derives from `expiresAt`, recomputed at mount.** The
//     overlay is remounted routinely by navigation and Fast Refresh, and a
//     client-started duration would restart the countdown each time.
//  2. **The default is stated out loud.** A decision that times out must never
//     feel stolen, so the button that will fire on its own says so.

/**
 * Time left on a decision, recomputed from the absolute deadline so a remount
 * (navigation, Fast Refresh) can never restart it.
 *
 * Null until the first tick: the server cannot know the client's clock, and
 * seeding from `Date.now()` during render would make the two disagree and
 * blow up hydration.
 */
function useCountdown(expiresAt: number): number | null {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 200);
    return () => clearInterval(timer);
  }, [expiresAt]);
  return now === null ? null : Math.max(0, expiresAt - now);
}

function CountdownRing({
  remaining,
  total,
}: {
  remaining: number | null;
  total: number;
}) {
  // Before the first tick, show a full ring rather than a wrong number.
  const fraction =
    remaining === null || total <= 0
      ? 1
      : Math.max(0, Math.min(1, remaining / total));
  const seconds =
    remaining === null ? Math.ceil(total / 1000) : Math.ceil(remaining / 1000);
  return (
    <span
      className="relative flex size-11 shrink-0 items-center justify-center rounded-full"
      style={{
        background: `conic-gradient(var(--ew-gold) ${fraction * 360}deg, color-mix(in srgb, var(--ew-paper) 12%, transparent) 0deg)`,
      }}
    >
      <span className="flex size-9 items-center justify-center rounded-full bg-card font-mono text-xs tabular-nums text-foreground">
        {seconds}
      </span>
    </span>
  );
}

export function DecisionOverlay({
  view,
  youId,
  windowMs,
  pending,
  onPay,
  onRefuse,
  onAnswerTruce,
  labelFor,
}: {
  view: EmpireView;
  youId: string | null;
  windowMs: number;
  pending: NonNullable<EmpireView["pending"]>;
  onPay: () => void;
  onRefuse: () => void;
  onAnswerTruce: (accept: boolean) => void;
  labelFor: (memberId: string) => string;
}) {
  const remaining = useCountdown(pending.expiresAt);
  const total = windowMs;
  const yours = youId !== null && pending.memberId === youId;

  const territory = pending.territoryId
    ? view.territories.find((t) => t.id === pending.territoryId)
    : undefined;
  const you = view.you;

  return (
    <div
      className="absolute inset-0 z-40 flex items-center justify-center rounded-3xl bg-black/70 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={pending.kind === "protection" ? "Protection demanded" : "Truce offered"}
    >
      <div
        className="w-full max-w-sm rounded-2xl border p-4 shadow-2xl"
        style={{
          background: "var(--ew-ink)",
          borderColor: "color-mix(in srgb, var(--ew-gold) 40%, transparent)",
        }}
      >
        {!yours ? (
          <div className="flex items-center gap-3">
            <CountdownRing remaining={remaining} total={windowMs} />
            <p className="text-sm text-foreground">
              Waiting on{" "}
              <span className="font-medium">{labelFor(pending.memberId)}</span>…
            </p>
          </div>
        ) : pending.kind === "protection" ? (
          <>
            <div className="flex items-start gap-3">
              <CountdownRing remaining={remaining} total={windowMs} />
              <div className="min-w-0">
                <p className="font-heading text-lg text-[var(--ew-gold)]">
                  {territory?.name ?? "Their turf"}
                </p>
                <p className="text-sm text-foreground">
                  {labelFor(territory?.ownerId ?? "")} wants{" "}
                  <span className="font-mono">${pending.fee?.toLocaleString("en-US")}</span>.
                </p>
              </div>
            </div>

            {/* The read: your crew against what's defending that corner. */}
            <div className="mt-3 flex items-center justify-center gap-4 rounded-xl bg-white/5 px-3 py-2 text-center">
              <span className="flex flex-col">
                <span className="font-mono text-lg text-foreground">
                  {you?.poolCrew ?? 0}
                  {you && you.enforcers > 0 ? `+${you.enforcers * 2}` : ""}
                </span>
                <span className="text-[10px] text-muted-foreground">your crew</span>
              </span>
              <span className="text-xs text-muted-foreground">vs</span>
              <span className="flex flex-col">
                <span className="font-mono text-lg text-foreground">
                  {territory?.defence ?? 0}
                </span>
                <span className="text-[10px] text-muted-foreground">defending</span>
              </span>
            </div>

            <div className="mt-3 flex gap-2">
              <Button className="flex-1" onClick={onPay}>
                Pay ${pending.fee?.toLocaleString("en-US")}
              </Button>
              <Button variant="destructive" className="flex-1" onClick={onRefuse}>
                Refuse
              </Button>
            </div>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              Lose the fight and you pay double, and a crew. No answer pays the fee.
            </p>
          </>
        ) : (
          <>
            <div className="flex items-start gap-3">
              <CountdownRing remaining={remaining} total={windowMs} />
              <div>
                <p className="font-heading text-lg text-[var(--ew-gold)]">
                  A hand across the table
                </p>
                <p className="text-sm text-foreground">
                  {labelFor(pending.fromMemberId ?? "")} offers a truce.
                </p>
              </div>
            </div>
            <div className="mt-3 flex gap-2">
              <Button className="flex-1" onClick={() => onAnswerTruce(true)}>
                Shake on it
              </Button>
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => onAnswerTruce(false)}
              >
                Walk away
              </Button>
            </div>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              Neither of you pays the other, and neither can take the other&apos;s turf.
              No answer walks away.
            </p>
          </>
        )}

        {/* Announced, not merely drawn — the countdown has to reach a screen reader. */}
        <span aria-live="polite" className="sr-only">
          {remaining === null
            ? Math.ceil(total / 1000)
            : Math.ceil(remaining / 1000)}{" "}
          seconds left to answer
        </span>
      </div>
    </div>
  );
}

export { cn };
