"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { ACTION_FACE_ICON, ACTION_FACE_LABEL, DieFace } from "./icons";

// The dice, thrown into the middle of the table.
//
// The roll is already decided by the server before this ever renders — the
// tumble is pure theatre over a known result, which is the only honest way to
// animate a server-authoritative game. Nothing here can change what was rolled.

export const TUMBLE_MS = 620;

function prefersReducedMotion(): boolean {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

export function DiceTray({
  roll,
  face,
  className,
}: {
  /** `seq` changing is what triggers a fresh throw. */
  roll: { d1: number; d2: number; seq: number } | null;
  face: string | null;
  className?: string;
}) {
  const [tumbling, setTumbling] = useState(false);
  const lastSeq = useRef<number | null>(null);

  useEffect(() => {
    if (!roll) return;
    if (lastSeq.current === roll.seq) return;
    // First render of an in-progress game shouldn't replay an old roll.
    const isFirst = lastSeq.current === null;
    lastSeq.current = roll.seq;
    if (isFirst || prefersReducedMotion()) return;

    setTumbling(true);
    const timer = setTimeout(() => setTumbling(false), TUMBLE_MS);
    return () => clearTimeout(timer);
  }, [roll]);

  if (!roll) return null;

  const FaceIcon = face ? ACTION_FACE_ICON[face] : null;
  // The Car's second hop reuses lastRoll with d2 = 0 — one die, not two.
  const isSingle = roll.d2 === 0;

  return (
    <div
      className={cn("flex items-center gap-1.5", className)}
      aria-live="polite"
      aria-label={
        isSingle
          ? `Moved ${roll.d1}`
          : `Rolled ${roll.d1} and ${roll.d2}${face ? `, ${ACTION_FACE_LABEL[face]}` : ""}`
      }
    >
      <Die value={roll.d1} tumbling={tumbling} delay={0} />
      {!isSingle && <Die value={roll.d2} tumbling={tumbling} delay={70} />}

      {FaceIcon && (
        <span
          className={cn(
            "ml-1 flex size-9 items-center justify-center rounded-lg border",
            tumbling && "motion-safe:[animation:ew-tumble_var(--ew-tumble)_ease-out]"
          )}
          style={
            {
              background: "color-mix(in srgb, var(--ew-neon) 22%, var(--ew-ink))",
              borderColor: "color-mix(in srgb, var(--ew-gold) 45%, transparent)",
              color: "var(--ew-gold)",
              "--ew-tumble": `${TUMBLE_MS}ms`,
              animationDelay: "140ms",
            } as React.CSSProperties
          }
          title={face ? ACTION_FACE_LABEL[face] : undefined}
        >
          <FaceIcon className="size-5" />
        </span>
      )}
    </div>
  );
}

function Die({
  value,
  tumbling,
  delay,
}: {
  value: number;
  tumbling: boolean;
  delay: number;
}) {
  return (
    <DieFace
      value={value}
      className={cn(
        "size-9 drop-shadow-md",
        tumbling
          ? "motion-safe:[animation:ew-tumble_var(--ew-tumble)_ease-out]"
          : "motion-safe:[animation:ew-settle_180ms_ease-out]"
      )}
      // Two dice thrown together shouldn't tumble in lockstep.
      style={
        {
          "--ew-tumble": `${TUMBLE_MS}ms`,
          animationDelay: `${delay}ms`,
        } as React.CSSProperties
      }
    />
  );
}
