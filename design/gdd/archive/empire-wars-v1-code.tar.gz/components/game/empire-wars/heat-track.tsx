import { cn } from "@/lib/utils";

// The Heat track. Always visible, always exact.
//
// This is not decoration: if a player cannot watch their Heat climb, the
// anti-runaway mechanic is invisible and every raid reads as the game picking
// on them (GDD > UI Requirements).

const BANDS = [
  { from: 0, to: 2, label: "Clean", token: "var(--ew-heat-clean)" },
  { from: 3, to: 5, label: "Watched", token: "var(--ew-heat-watched)" },
  { from: 6, to: 8, label: "Raids", token: "var(--ew-heat-raid)" },
  { from: 9, to: 10, label: "Federal", token: "var(--ew-heat-federal)" },
];

export function bandFor(heat: number) {
  return BANDS.find((b) => heat >= b.from && heat <= b.to) ?? BANDS[0];
}

export function HeatTrack({
  heat,
  mostWanted,
  compact = false,
}: {
  heat: number;
  mostWanted: boolean;
  compact?: boolean;
}) {
  const band = bandFor(heat);
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-[10px] tracking-wide text-muted-foreground uppercase">
          Heat
        </span>
        <span className="flex items-center gap-1.5">
          {mostWanted && (
            <span
              className="rounded-full px-1.5 py-px font-heading text-[9px] text-black"
              style={{ background: "var(--ew-heat-federal)" }}
              title="Your empire is the biggest — the police have noticed"
            >
              MOST WANTED
            </span>
          )}
          <span
            className="font-mono text-[11px] tabular-nums"
            style={{ color: band.token }}
          >
            {heat}/10 · {band.label}
          </span>
        </span>
      </div>

      <div
        className={cn("flex gap-[2px]", compact ? "h-1.5" : "h-2")}
        role="meter"
        aria-valuemin={0}
        aria-valuemax={10}
        aria-valuenow={heat}
        aria-label={`Heat ${heat} of 10, ${band.label}`}
      >
        {Array.from({ length: 10 }, (_, i) => {
          const step = i + 1;
          const lit = step <= heat;
          const stepBand = bandFor(step);
          return (
            <span
              key={step}
              className="flex-1 rounded-[1px] transition-colors"
              style={{
                background: lit
                  ? stepBand.token
                  : "color-mix(in srgb, var(--ew-paper) 12%, transparent)",
              }}
            />
          );
        })}
      </div>
    </div>
  );
}

/** The Dirty Money figure, always shown with the Heat it is costing. */
export function DirtyMoney({
  amount,
  heatPerRound,
}: {
  amount: number;
  heatPerRound: number;
}) {
  return (
    <span className="flex items-baseline gap-1.5">
      <span className="font-mono text-sm tabular-nums text-foreground">
        ${amount.toLocaleString("en-US")}
      </span>
      {heatPerRound > 0 && (
        <span
          className="font-mono text-[10px]"
          style={{ color: "var(--ew-heat-raid)" }}
          title="Heat this will add at your next upkeep"
        >
          +{heatPerRound} Heat/round
        </span>
      )}
    </span>
  );
}
