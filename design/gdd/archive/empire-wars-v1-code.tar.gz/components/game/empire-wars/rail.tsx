"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import { RiCloseLine, RiQuestionLine } from "@remixicon/react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { HOW_TO_PLAY, heatMeaning, type Coach } from "@/lib/game/empire-wars/coach";
import type { EmpireMove } from "@/lib/game/empire-wars/turn";
import type { EmpireView } from "@/lib/game/empire-wars/view";
import { CURRENCY_ICON } from "./icons";
import { HeatTrack } from "./heat-track";

// Your side of the table: what you have, what it means, and the one thing to
// do next.
//
// The rule this component exists to enforce: **one primary action, ever**.
// Everything else is small, and anything that doesn't apply right now isn't
// rendered at all. A first-timer should be able to play a whole turn by
// reading one sentence and pressing one button.

const SEEN_KEY = "chipae:empire-wars:how-to-play-seen";

export function EmpireRail({
  view,
  coach,
  onMove,
  disabled,
  error,
}: {
  view: EmpireView;
  coach: Coach;
  onMove: (move: EmpireMove) => void;
  disabled: boolean;
  error: string | null;
}) {
  const you = view.you;
  /**
   * Open the primer the first time someone plays, then never again.
   *
   * `useSyncExternalStore` rather than a `useState` initialiser or an effect:
   * the server cannot read localStorage, so it must render "already seen" and
   * let the client correct it. Doing that in a state initialiser produces a
   * hydration mismatch; doing it in an effect trips the setState-in-effect
   * rule. This is the API built for exactly this split.
   */
  const seenPrimer = useSyncExternalStore(
    () => () => {},
    () => {
      try {
        return !!window.localStorage.getItem(SEEN_KEY);
      } catch {
        // Private mode or blocked storage — don't nag.
        return true;
      }
    },
    () => true
  );
  /** null = follow the first-run default; true/false = the player chose. */
  const [manual, setManual] = useState<boolean | null>(null);
  const showHelp = manual ?? !seenPrimer;

  function dismissHelp() {
    setManual(false);
    try {
      window.localStorage.setItem(SEEN_KEY, "1");
    } catch {
      // Nothing to do — it will simply open again next time.
    }
  }

  if (!you) return null;
  const seat = view.seats.find((s) => s.memberId === you.memberId);

  return (
    <div className="flex flex-col gap-2.5 rounded-2xl border border-white/10 bg-black/40 p-3 backdrop-blur-sm">
      {/* ── What you're worth ─────────────────────────────────────────────── */}
      <div className="flex flex-wrap items-end gap-x-4 gap-y-2">
        <Stat icon="cash" label="Cash" value={money(you.cash)} note="buys turf" />
        <Stat
          icon="dirty"
          label="Dirty"
          value={money(you.dirty)}
          note={
            you.dirtyHeatPerRound > 0
              ? `+${you.dirtyHeatPerRound} Heat each round`
              : "earns more, draws police"
          }
          alarm={you.dirtyHeatPerRound > 0}
        />
        <Stat
          icon="respect"
          label="Respect"
          value={String(you.kingpinProgress.respect)}
          note="counts at the end"
        />
        <Stat
          icon="crew"
          label="Crew"
          value={String(you.poolCrew + you.enforcers * 2)}
          note="wins fights"
        />
        <Stat
          icon="empire"
          label="Empire"
          value={money(you.empireValue)}
          note="what wins the game"
        />

        <div className="ml-auto min-w-44 flex-1">
          <HeatTrack
            heat={you.kingpinProgress.heat}
            mostWanted={seat?.mostWanted ?? false}
            compact
          />
          <p className="mt-0.5 text-[10px] leading-tight text-muted-foreground">
            {heatMeaning(you.kingpinProgress.heat)}
          </p>
        </div>
      </div>

      {/* ── What to do now ────────────────────────────────────────────────── */}
      <div
        className={cn(
          "flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl px-3 py-2.5",
          coach.waiting ? "bg-white/5" : "bg-[var(--ew-gold)]/10"
        )}
      >
        <div className="min-w-48 flex-1">
          <p
            className={cn(
              "font-heading text-base leading-tight",
              coach.waiting ? "text-muted-foreground" : "text-[var(--ew-gold)]"
            )}
          >
            {coach.headline}
          </p>
          {coach.detail && (
            <p className="mt-0.5 text-xs leading-snug text-foreground/80">
              {coach.detail}
            </p>
          )}
        </div>

        {coach.primary && (
          <span className="flex items-center gap-2">
            {!coach.waiting && <TurnClock expiresAt={view.turnExpiresAt} />}
            <Button
              variant={coach.primary.tone === "danger" ? "destructive" : "game"}
              size="lg"
              disabled={disabled}
              onClick={() => onMove(coach.primary!.move)}
            >
              {coach.primary.label}
            </Button>
          </span>
        )}
      </div>

      {/* ── Everything else, quietly ──────────────────────────────────────── */}
      {coach.secondary.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          {coach.secondary.map((action, i) => (
            <Button
              key={i}
              variant={action.tone === "danger" ? "outline" : "secondary"}
              size="sm"
              disabled={disabled}
              title={action.hint}
              onClick={() => onMove(action.move)}
              className={cn(
                action.tone === "danger" &&
                  "border-destructive/50 text-destructive"
              )}
            >
              {action.label}
            </Button>
          ))}
        </div>
      )}

      {/* ── Your missions, and the way in to the rules ────────────────────── */}
      <div className="flex flex-wrap items-center gap-1.5">
        {you.missions.map((mission) => (
          <span
            key={mission.id}
            className={cn(
              "rounded-lg border px-2 py-1 text-[11px]",
              mission.completed
                ? "border-success/40 bg-success/10 text-muted-foreground line-through"
                : "border-border bg-background/40 text-foreground"
            )}
            title="Only you can see this. Finish it for Respect and cash."
          >
            {mission.text}
          </span>
        ))}
        <button
          type="button"
          onClick={() => setManual(true)}
          className="ml-auto flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
        >
          <RiQuestionLine className="size-3.5" />
          How to play
        </button>
      </div>

      {error && <p className="text-xs text-destructive">{error}</p>}

      {showHelp && <HowToPlay onClose={dismissHelp} />}
    </div>
  );
}

function money(n: number): string {
  return `$${n.toLocaleString("en-US")}`;
}

/**
 * How long you have before the table plays on without you.
 *
 * Only shown in the last ten seconds — a clock ticking through every turn
 * makes a casual game feel like an exam. Recomputed from the absolute
 * deadline, so remounting (navigation, Fast Refresh) can't restart it.
 */
function TurnClock({ expiresAt }: { expiresAt: number | null }) {
  /**
   * Starts null — deliberately.
   *
   * The server has no idea what time it is on the player's machine, so seeding
   * this from `Date.now()` during render makes the server write one number and
   * the client write another: a hydration mismatch. Rendering nothing until
   * the first tick costs half a second on a clock that only appears in the
   * final ten seconds anyway.
   */
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    if (expiresAt === null) return;
    const timer = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(timer);
  }, [expiresAt]);

  if (expiresAt === null || now === null) return null;
  const remaining = Math.max(0, expiresAt - now);
  if (remaining > 10_000) return null;
  const seconds = Math.ceil(remaining / 1000);
  return (
    <span
      className="font-mono text-xs tabular-nums"
      style={{ color: "var(--ew-heat-raid)" }}
      title="Take too long and the table plays on without you"
      aria-live="polite"
    >
      {seconds}s
    </span>
  );
}

/** A number, its name, and what it is actually for. */
function Stat({
  icon,
  label,
  value,
  note,
  alarm,
}: {
  icon: keyof typeof CURRENCY_ICON;
  label: string;
  value: string;
  note: string;
  alarm?: boolean;
}) {
  const Icon = CURRENCY_ICON[icon];
  return (
    <span className="flex flex-col gap-0.5">
      <span className="flex items-center gap-1 text-[10px] tracking-wide text-muted-foreground uppercase">
        <Icon className="size-3" />
        {label}
      </span>
      <span className="font-mono text-sm tabular-nums text-foreground">{value}</span>
      <span
        className={cn(
          "text-[9px] leading-none",
          alarm ? "text-[var(--ew-heat-raid)]" : "text-muted-foreground/70"
        )}
      >
        {note}
      </span>
    </span>
  );
}

/** The whole game in four lines. Opens itself once, then stays out of the way. */
function HowToPlay({ onClose }: { onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center rounded-3xl bg-black/80 p-4 backdrop-blur-sm">
      <div
        className="w-full max-w-md rounded-2xl border p-5 shadow-2xl"
        style={{
          background: "var(--ew-ink)",
          borderColor: "color-mix(in srgb, var(--ew-gold) 40%, transparent)",
        }}
      >
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="font-heading text-xl text-[var(--ew-gold)]">
            Running the city
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:text-foreground"
          >
            <RiCloseLine className="size-5" />
          </button>
        </div>

        <ol className="flex flex-col gap-3">
          {HOW_TO_PLAY.map((step, i) => (
            <li key={step.title} className="flex gap-3">
              <span
                className="flex size-6 shrink-0 items-center justify-center rounded-full font-mono text-xs"
                style={{
                  background: "color-mix(in srgb, var(--ew-gold) 22%, transparent)",
                  color: "var(--ew-gold)",
                }}
              >
                {i + 1}
              </span>
              <span className="flex flex-col">
                <span className="text-sm font-medium text-foreground">
                  {step.title}
                </span>
                <span className="text-xs leading-snug text-muted-foreground">
                  {step.body}
                </span>
              </span>
            </li>
          ))}
        </ol>

        <p className="mt-4 text-center text-[11px] text-muted-foreground">
          The game tells you what to do each turn — just follow the gold line.
        </p>

        <Button variant="game" className="mt-3 w-full" onClick={onClose}>
          Deal me in
        </Button>
      </div>
    </div>
  );
}
