import { describe, expect, it } from "vitest";
import { AGGRESSION } from "@/lib/game/data/empire-wars";
import {
  acceptTruce,
  breakTruce,
  canOfferTruce,
  clearTrucesFor,
  resolveStandoff,
  resolveStrike,
  resolveTurfWar,
  strikeTargets,
  turfWarTargets,
} from "@/lib/game/empire-wars/combat";
import {
  dealGame,
  hasTruce,
  playerOf,
  rollCombat,
  territoriesOf,
  tileDefence,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";

function seeded(seed: number): () => number {
  let value = seed;
  return () => {
    value = (value * 1664525 + 1013904223) % 4294967296;
    return value / 4294967296;
  };
}

/**
 * Always rolls 6s. Note this is only an "attacker wins" oracle when the
 * defender rolls fewer than two dice — with two or more, both sides cap at 12
 * and the tie goes to the defender. Use `favouring` when the defender is real.
 */
const ALWAYS_HIGH = () => 0.999;
/** Always rolls 1s. With ties going to the defender, the attacker always loses. */
const ALWAYS_LOW = () => 0;

/**
 * Scripted rng: the first `attackDice` draws roll 6s, everything after rolls
 * 1s. Since resolveCombat rolls the attacker first, this guarantees the
 * attacker wins regardless of how many dice the defender fields.
 */
function favouring(attackDice: number): () => number {
  let draw = 0;
  return () => (draw++ < Math.max(1, attackDice) ? 0.999 : 0);
}

const MISSIONS = Array.from({ length: 10 }, (_, i) => `m${i + 1}`);
const EVENTS = Array.from({ length: 8 }, (_, i) => `e${i + 1}`);

function fresh(seats: string[], seed = 1): EmpireState {
  return dealGame(seats, seeded(seed), { missionIds: MISSIONS, eventIds: EVENTS });
}

function give(
  state: EmpireState,
  id: string,
  over: Partial<EmpireState["players"][number]>
): EmpireState {
  return {
    ...state,
    players: state.players.map((p) => (p.id === id ? { ...p, ...over } : p)),
  };
}

function own(
  state: EmpireState,
  id: string,
  ids: string[],
  over: Partial<EmpireState["territories"][number]> = {}
): EmpireState {
  return {
    ...state,
    territories: state.territories.map((t) =>
      ids.includes(t.id) ? { ...t, ownerId: id, ...over } : t
    ),
  };
}

describe("combat resolution", () => {
  it("gives ties to the defender", () => {
    // Identical strength and an rng that always yields the same face.
    let state = fresh(["a", "b"]);
    state = own(state, "b", ["drug-lab"], { garrison: 2, level: 1 });
    state = give(state, "a", { poolCrew: 2, enforcers: 0, cash: 5000 });
    const result = resolveStandoff(state, "a", "drug-lab", ALWAYS_HIGH);
    expect(result.outcome.attackRoll).toBe(result.outcome.defenceRoll);
    expect(result.outcome.attackerWins).toBe(false);
  });

  it("counts enforcers as two crew", () => {
    let state = fresh(["a", "b"]);
    state = give(state, "a", { poolCrew: 1, enforcers: 2 });
    state = own(state, "b", ["drug-lab"]);
    const result = resolveStandoff(state, "a", "drug-lab", seeded(2));
    expect(result.outcome.attackDice).toBe(5);
  });

  it("rolls a defended tile's garrison plus its level bonus", () => {
    let state = fresh(["a", "b"]);
    // A Fortress: 2 garrisoned crew + 4 cumulative level defence.
    state = own(state, "b", ["drug-lab"], { garrison: 2, level: 5 });
    const territory = state.territories.find((t) => t.id === "drug-lab")!;
    expect(tileDefence(territory)).toBe(6);
  });

  it("never rolls fewer than one die", () => {
    const rng = seeded(3);
    for (let i = 0; i < 20; i++) {
      expect(rollCombat(0, rng)).toBeGreaterThanOrEqual(1);
    }
  });
});

describe("the standoff", () => {
  it("cancels the fee and swings Respect when the visitor wins", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "b", ["drug-lab"], { garrison: 0, level: 1 });
    state = give(state, "a", { poolCrew: 6, cash: 5000, respect: 5 });
    state = give(state, "b", { respect: 5 });
    const result = resolveStandoff(state, "a", "drug-lab", ALWAYS_HIGH);
    expect(result.outcome.attackerWins).toBe(true);
    expect(result.paid).toBe(0);
    expect(playerOf(result.state, "a")!.cash).toBe(5000);
    expect(playerOf(result.state, "a")!.respect).toBe(6);
    expect(playerOf(result.state, "b")!.respect).toBe(4);
  });

  it("charges double and takes a crew when the visitor loses", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "b", ["drug-lab"], { garrison: 3, level: 1 });
    state = give(state, "a", { poolCrew: 2, cash: 5000 });
    const result = resolveStandoff(state, "a", "drug-lab", ALWAYS_LOW);
    expect(result.outcome.attackerWins).toBe(false);
    expect(playerOf(result.state, "a")!.poolCrew).toBe(1);
    // Drug Lab L1 fee is 22 × ... doubled; the owner receives exactly what was paid.
    expect(result.paid).toBeGreaterThan(0);
    expect(playerOf(result.state, "b")!.cash).toBeGreaterThan(1500);
  });

  it("never transfers the territory, win or lose", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "b", ["drug-lab"]);
    state = give(state, "a", { poolCrew: 8, cash: 5000 });
    const won = resolveStandoff(state, "a", "drug-lab", favouring(8));
    expect(
      won.state.territories.find((t) => t.id === "drug-lab")!.ownerId
    ).toBe("b");
    const lost = resolveStandoff(state, "a", "drug-lab", ALWAYS_LOW);
    expect(
      lost.state.territories.find((t) => t.id === "drug-lab")!.ownerId
    ).toBe("b");
  });

  it("adds Heat to the refuser whether they win or lose", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "b", ["drug-lab"]);
    state = give(state, "a", { poolCrew: 6, cash: 5000, heat: 0 });
    expect(
      playerOf(resolveStandoff(state, "a", "drug-lab", ALWAYS_HIGH).state, "a")!.heat
    ).toBe(AGGRESSION.refuseHeat);
    expect(
      playerOf(resolveStandoff(state, "a", "drug-lab", ALWAYS_LOW).state, "a")!.heat
    ).toBe(AGGRESSION.refuseHeat);
  });

  it("runs the broken path when the doubled fee can't be covered", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "b", ["first-city-bank"], { garrison: 4, level: 5 });
    state = own(state, "a", ["pawn-shop"]);
    state = give(state, "a", { poolCrew: 1, cash: 0, dirty: 0 });
    const result = resolveStandoff(state, "a", "first-city-bank", ALWAYS_LOW);
    expect(result.broken).toBe(true);
    // Their only tile went to the creditor, and they are still playing.
    expect(territoriesOf(result.state, "a")).toHaveLength(0);
    expect(playerOf(result.state, "a")!.eliminated).toBe(false);
  });
});

describe("the strike", () => {
  it("takes a crew from the loser and never moves land", () => {
    let state = fresh(["a", "b"]);
    state = give(state, "a", { poolCrew: 6, respect: 5 });
    state = give(state, "b", { poolCrew: 1 });
    state = own(state, "b", ["drug-lab"]);
    const result = resolveStrike(state, "a", "b", ALWAYS_HIGH);
    expect("error" in result).toBe(false);
    if ("error" in result) return;
    expect(playerOf(result.state, "b")!.poolCrew).toBe(0);
    expect(playerOf(result.state, "a")!.respect).toBe(6);
    expect(
      result.state.territories.find((t) => t.id === "drug-lab")!.ownerId
    ).toBe("b");
  });

  it("costs the attacker a crew when it fails", () => {
    let state = fresh(["a", "b"]);
    state = give(state, "a", { poolCrew: 2 });
    state = give(state, "b", { poolCrew: 5 });
    const result = resolveStrike(state, "a", "b", ALWAYS_LOW);
    if ("error" in result) throw new Error(result.error);
    expect(playerOf(result.state, "a")!.poolCrew).toBe(1);
  });

  it("refuses a truce partner", () => {
    let state = fresh(["a", "b"]);
    const truce = acceptTruce(state, "a", "b");
    if (!truce.ok) throw new Error(truce.error);
    state = truce.state;
    expect("error" in resolveStrike(state, "a", "b", ALWAYS_HIGH)).toBe(true);
  });

  it("reaches players within range regardless of adjacency", () => {
    let state = fresh(["a", "b", "c"]);
    state = give(state, "a", { tile: 1 });
    state = give(state, "b", { tile: 5 }); // 4 tiles away — in range
    state = give(state, "c", { tile: 20 }); // far side — out of range
    const targets = strikeTargets(state, "a");
    expect(targets).toContain("b");
    expect(targets).not.toContain("c");
  });

  it("reaches a distant player who owns a neighbouring tile", () => {
    let state = fresh(["a", "c"]);
    state = give(state, "a", { tile: 1 });
    state = give(state, "c", { tile: 20 });
    state = own(state, "a", ["pawn-shop"]);
    state = own(state, "c", ["barber-shop"]); // neighbour on the ring
    expect(strikeTargets(state, "a")).toContain("c");
  });
});

describe("turf war", () => {
  it("only targets rival tiles adjacent to one you own", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "a", ["pawn-shop"]);
    state = own(state, "b", ["barber-shop", "drug-lab"]);
    const targets = turfWarTargets(state, "a");
    expect(targets).toContain("barber-shop");
    expect(targets).not.toContain("drug-lab");
  });

  it("captures at the current level and destroys the garrison", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "a", ["pawn-shop"]);
    state = own(state, "b", ["barber-shop"], { level: 4, garrison: 1 });
    state = give(state, "a", { poolCrew: 8 });
    const result = resolveTurfWar(state, "a", "barber-shop", favouring(8));
    if ("error" in result) throw new Error(result.error);
    expect(result.captured).toBe(true);
    const taken = result.state.territories.find((t) => t.id === "barber-shop")!;
    expect(taken.ownerId).toBe("a");
    expect(taken.level).toBe(4);
    expect(taken.garrison).toBe(0);
  });

  it("adds Heat to the attacker whether they win or lose", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "a", ["pawn-shop"]);
    state = own(state, "b", ["barber-shop"]);
    state = give(state, "a", { poolCrew: 8, heat: 0 });
    const won = resolveTurfWar(state, "a", "barber-shop", favouring(8));
    const lost = resolveTurfWar(state, "a", "barber-shop", ALWAYS_LOW);
    if ("error" in won || "error" in lost) throw new Error("unreachable");
    expect(playerOf(won.state, "a")!.heat).toBe(AGGRESSION.turfWarHeat);
    expect(playerOf(lost.state, "a")!.heat).toBe(AGGRESSION.turfWarHeat);
  });

  it("refuses a target protected by a truce", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "a", ["pawn-shop"]);
    state = own(state, "b", ["barber-shop"]);
    const truce = acceptTruce(state, "a", "b");
    if (!truce.ok) throw new Error(truce.error);
    expect(turfWarTargets(truce.state, "a")).not.toContain("barber-shop");
    expect(
      "error" in resolveTurfWar(truce.state, "a", "barber-shop", favouring(8))
    ).toBe(true);
  });
});

describe("truce and betrayal", () => {
  it("allows one truce per player", () => {
    let state = fresh(["a", "b", "c"]);
    const first = acceptTruce(state, "a", "b");
    if (!first.ok) throw new Error(first.error);
    state = first.state;
    expect(hasTruce(state, "a", "b")).toBe(true);
    expect(canOfferTruce(state, "a", "c")).toBe(false);
    expect(acceptTruce(state, "a", "c").ok).toBe(false);
  });

  it("costs the breaker 3 Respect", () => {
    let state = fresh(["a", "b"]);
    state = give(state, "a", { respect: 10 });
    const truce = acceptTruce(state, "a", "b");
    if (!truce.ok) throw new Error(truce.error);
    const broken = breakTruce(truce.state, "a", "b");
    if (!broken.ok) throw new Error(broken.error);
    expect(playerOf(broken.state, "a")!.respect).toBe(7);
    expect(hasTruce(broken.state, "a", "b")).toBe(false);
  });

  it("frees both players to pair again after a break", () => {
    const state = fresh(["a", "b", "c"]);
    const truce = acceptTruce(state, "a", "b");
    if (!truce.ok) throw new Error(truce.error);
    const broken = breakTruce(truce.state, "a", "b");
    if (!broken.ok) throw new Error(broken.error);
    expect(canOfferTruce(broken.state, "a", "c")).toBe(true);
  });

  it("clears every truce a departing player was in", () => {
    const state = fresh(["a", "b"]);
    const truce = acceptTruce(state, "a", "b");
    if (!truce.ok) throw new Error(truce.error);
    expect(clearTrucesFor(truce.state, "a").truces).toEqual([]);
  });
});

/**
 * The published table is exact (full enumeration, not sampling), so these
 * assertions are tight. If combat resolution changes, they fail immediately.
 */
describe("win rates match the published table", () => {
  function winRate(attack: number, defence: number, trials = 60_000): number {
    const rng = seeded(9876);
    let wins = 0;
    for (let i = 0; i < trials; i++) {
      if (rollCombat(attack, rng) > rollCombat(defence, rng)) wins++;
    }
    return (100 * wins) / trials;
  }

  const cases: Array<[number, number, number]> = [
    [2, 2, 44.4],
    [3, 3, 43.7],
    [4, 4, 42.5],
    [5, 5, 41.0],
    [3, 2, 61.9],
    [4, 2, 72.4],
    // The Fortress column — 2 garrison + 4 level defence.
    [4, 6, 26.6],
    [6, 6, 39.4],
    [8, 6, 48.6],
  ];

  for (const [attack, defence, expected] of cases) {
    it(`${attack} attack vs ${defence} defence wins about ${expected}%`, () => {
      expect(winRate(attack, defence)).toBeCloseTo(expected, -0.5);
    });
  }

  it("shows diminishing returns — 6 crew is not twice 3", () => {
    expect(winRate(6, 4) - winRate(3, 4)).toBeLessThan(30);
  });
});
