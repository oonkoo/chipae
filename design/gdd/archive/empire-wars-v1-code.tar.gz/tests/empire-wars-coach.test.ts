import { describe, expect, it } from "vitest";
import { MISSION_IDS, EVENT_IDS } from "@/lib/game/data/empire-wars-content";
import { coachFor, heatMeaning } from "@/lib/game/empire-wars/coach";
import { applyMove, type MoveCtx } from "@/lib/game/empire-wars/turn";
import { viewFor } from "@/lib/game/empire-wars/view";
import {
  currentPlayer,
  dealGame,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";

// The guidance layer. Two things matter and both are tested here:
//
//  1. It never suggests a move the rules would reject — a coach that lies is
//     worse than no coach.
//  2. It always offers a way forward, so a first-timer is never stuck looking
//     at a board with nothing to press.

function seeded(seed: number): () => number {
  let value = seed;
  return () => {
    value = (value * 1664525 + 1013904223) % 4294967296;
    return value / 4294967296;
  };
}

const NOW = 1_760_000_000_000;
const ctx = (seed = 1): MoveCtx => ({ random: seeded(seed), now: NOW });
const label = (id: string) => (id === "a" ? "You" : "Croupier");

function fresh(seats: string[], seed = 1): EmpireState {
  return dealGame(seats, seeded(seed), {
    missionIds: [...MISSION_IDS],
    eventIds: [...EVENT_IDS],
  });
}

describe("the coach always offers a legal way forward", () => {
  it("suggests a move the rules accept, at every step of a whole turn", () => {
    for (let seed = 1; seed <= 40; seed++) {
      let state = fresh(["a", "b"], seed);
      const me = currentPlayer(state).id;

      // Walk a turn purely by following the coach's primary action.
      for (let step = 0; step < 12; step++) {
        const view = viewFor(state, me);
        const coach = coachFor(view, label);

        // Somebody else's turn or decision — nothing to press, correctly.
        if (coach.waiting || !coach.primary) break;

        const result = applyMove(state, me, coach.primary.move, ctx(seed));
        expect(
          result.ok,
          `seed ${seed} step ${step}: "${coach.headline}" → ${JSON.stringify(
            coach.primary.move
          )} rejected: ${result.ok ? "" : result.error}`
        ).toBe(true);
        if (!result.ok) break;
        state = result.state;

        if (state.pending || currentPlayer(state).id !== me) break;
      }
    }
  });

  it("offers only legal secondary actions too", () => {
    for (let seed = 1; seed <= 25; seed++) {
      const state = fresh(["a", "b"], seed);
      const me = currentPlayer(state).id;
      const rolled = applyMove(state, me, { kind: "roll" }, ctx(seed));
      if (!rolled.ok || rolled.state.pending) continue;

      const coach = coachFor(viewFor(rolled.state, me), label);
      for (const action of coach.secondary) {
        const result = applyMove(rolled.state, me, action.move, ctx(seed));
        // "Can't afford it" is a legitimate refusal; a *malformed* move is not.
        if (!result.ok) {
          expect(result.error).not.toMatch(/not your turn|isn't a move/i);
        }
      }
    }
  });

  it("gives the player something to press whenever it is their turn", () => {
    for (let seed = 1; seed <= 40; seed++) {
      const state = fresh(["a", "b"], seed);
      const me = currentPlayer(state).id;
      const rolled = applyMove(state, me, { kind: "roll" }, ctx(seed));
      if (!rolled.ok) continue;
      if (rolled.state.pending) continue;

      const coach = coachFor(viewFor(rolled.state, me), label);
      expect(coach.primary, `seed ${seed}: "${coach.headline}"`).toBeDefined();
    }
  });
});

describe("the coach explains, not just instructs", () => {
  it("opens a turn by telling you to roll", () => {
    const state = fresh(["a", "b"], 3);
    const me = currentPlayer(state).id;
    const coach = coachFor(viewFor(state, me), label);
    expect(coach.primary?.move).toEqual({ kind: "roll" });
    expect(coach.detail).toBeTruthy();
  });

  it("says what a territory earns before you buy it", () => {
    // Walk until the active seat is standing on something buyable.
    for (let seed = 1; seed <= 40; seed++) {
      const state = fresh(["a", "b"], seed);
      const me = currentPlayer(state).id;
      const rolled = applyMove(state, me, { kind: "roll" }, ctx(seed));
      if (!rolled.ok) continue;
      const view = viewFor(rolled.state, me);
      if (!view.you?.canBuyHere) continue;

      const coach = coachFor(view, label);
      expect(coach.headline).toMatch(/for sale/i);
      // Either the income it pays, or how far off affording it you are.
      expect(coach.detail).toMatch(/every round|short/i);
      return;
    }
    throw new Error("no seed produced a buyable tile");
  });

  it("goes quiet while another seat is playing", () => {
    const state = fresh(["a", "b"], 5);
    const other = state.players.find((p) => p.id !== currentPlayer(state).id)!;
    const coach = coachFor(viewFor(state, other.id), label);
    expect(coach.waiting).toBe(true);
    expect(coach.primary).toBeUndefined();
  });

  it("warns about dirty money in plain words once it is costing Heat", () => {
    const base = fresh(["a", "b"], 7);
    const me = currentPlayer(base).id;
    const state: EmpireState = {
      ...base,
      phase: "build",
      players: base.players.map((p) =>
        p.id === me ? { ...p, dirty: 1200 } : p
      ),
    };
    const coach = coachFor(viewFor(state, me), label);
    const launder = coach.secondary.find((a) => a.move.kind === "launderMoney");
    expect(launder).toBeDefined();
    expect(launder?.hint).toMatch(/Heat/i);
  });
});

describe("heat is explained in plain language", () => {
  it("describes every band without jargon", () => {
    expect(heatMeaning(0)).toMatch(/nobody/i);
    expect(heatMeaning(4)).toMatch(/25%/);
    expect(heatMeaning(7)).toMatch(/raid|police/i);
    expect(heatMeaning(10)).toMatch(/federal/i);
  });
});

/**
 * Buying and declining are once-per-landing. If the view keeps advertising a
 * settled tile, the coach keeps offering it and the server rejects the click
 * with "You've already settled this tile" — which reads as a broken button.
 */
describe("a settled tile stops being offered", () => {
  it("drops the offer once the tile has been declined", () => {
    for (let seed = 1; seed <= 40; seed++) {
      const state = fresh(["a", "b"], seed);
      const me = currentPlayer(state).id;
      const rolled = applyMove(state, me, { kind: "roll" }, ctx(seed));
      if (!rolled.ok || rolled.state.pending) continue;
      if (!viewFor(rolled.state, me).you?.canBuyHere) continue;

      const declined = applyMove(rolled.state, me, { kind: "decline" }, ctx(seed));
      expect(declined.ok).toBe(true);
      if (!declined.ok) return;

      // The offer is gone, so the coach moves on instead of re-offering.
      expect(viewFor(declined.state, me).you?.canBuyHere).toBeNull();
      const coach = coachFor(viewFor(declined.state, me), label);
      expect(coach.headline).not.toMatch(/for sale/i);
      return;
    }
    throw new Error("no seed produced a buyable tile");
  });

  it("never offers a tile to a seat that isn't on the clock", () => {
    const state = fresh(["a", "b"], 12);
    const other = state.players.find((p) => p.id !== currentPlayer(state).id)!;
    expect(viewFor(state, other.id).you?.canBuyHere).toBeNull();
  });
});
