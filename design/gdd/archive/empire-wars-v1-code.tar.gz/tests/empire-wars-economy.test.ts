import { describe, expect, it } from "vitest";
import { EMPIRE_WARS_CONFIG, HEAT } from "@/lib/game/data/empire-wars";
import {
  CLEAN_POLICY,
  DEFAULT_POLICY,
  simulateMatch,
} from "@/lib/game/empire-wars/simulate";
import {
  advanceToken,
  buyTerritory,
  collectIncome,
  declineTerritory,
  launder,
  recruitCrew,
  runUpkeep,
  settleDebt,
  sweepMostWanted,
  upgradeTerritory,
} from "@/lib/game/empire-wars/economy";
import { viewFor } from "@/lib/game/empire-wars/view";
import {
  currentPrice,
  dealGame,
  playerOf,
  territoriesOf,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";

function seeded(seed: number): () => number {
  let value = seed;
  return () => {
    value = (value * 1664525 + 1013904223) % 4294967296;
    return value / 4294967296;
  };
}

const MISSIONS = Array.from({ length: 10 }, (_, i) => `m${i + 1}`);
const EVENTS = Array.from({ length: 8 }, (_, i) => `e${i + 1}`);

function fresh(seats: string[], seed = 1): EmpireState {
  return dealGame(seats, seeded(seed), {
    missionIds: MISSIONS,
    eventIds: EVENTS,
  });
}

function give(
  state: EmpireState,
  id: string,
  over: Partial<EmpireState["players"][number]>
): EmpireState {
  return {
    ...state,
    players: state.players.map((p) => (p.id === id ? { ...p, ...over } : p)),
  };
}

function own(state: EmpireState, id: string, territoryIds: string[]): EmpireState {
  return {
    ...state,
    territories: state.territories.map((t) =>
      territoryIds.includes(t.id) ? { ...t, ownerId: id } : t
    ),
  };
}

describe("movement", () => {
  it("wraps the ring and reports passing The Docks", () => {
    expect(advanceToken(0, 7)).toEqual({ tile: 7, passedDocks: false });
    expect(advanceToken(30, 4)).toEqual({ tile: 2, passedDocks: true });
    // Landing exactly on The Docks counts as passing it.
    expect(advanceToken(28, 4)).toEqual({ tile: 0, passedDocks: true });
  });
});

describe("income", () => {
  it("pays the stipend plus every owned tile", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["pawn-shop", "drug-lab"]);
    const { cash } = collectIncome(state, "a", () => false);
    // 200 stipend + 18 + 68
    expect(cash).toBe(286);
  });

  it("takes the Dirty option only where one is offered", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["pawn-shop", "drug-lab"]);
    const result = collectIncome(state, "a", () => true);
    // Pawn Shop is small, so it still pays cash: 200 + 18.
    expect(result.cash).toBe(218);
    expect(result.dirty).toBe(113);
  });

  it("docks illegal tiles 25% once Watched", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["drug-lab"]);
    state = give(state, "a", { heat: HEAT.watchedAt });
    // 68 × 0.75 = 51
    expect(collectIncome(state, "a", () => false).cash).toBe(251);
  });

  it("blocks the Dirty option entirely at Federal", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["drug-lab"]);
    state = give(state, "a", { heat: HEAT.federalAt });
    const result = collectIncome(state, "a", () => true);
    expect(result.dirty).toBe(0);
    expect(result.cash).toBeGreaterThan(0);
  });

  it("omits the stipend when income is collected off a lap", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["pawn-shop"]);
    expect(collectIncome(state, "a", () => false, { stipend: false }).cash).toBe(18);
  });
});

describe("buying and declining", () => {
  it("charges the current price and transfers ownership", () => {
    const state = fresh(["a"]);
    const result = buyTerritory(state, "a", "pawn-shop");
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(playerOf(result.state, "a")!.cash).toBe(1500 - 120);
    expect(territoriesOf(result.state, "a").map((t) => t.id)).toEqual(["pawn-shop"]);
  });

  it("refuses a tile someone already owns", () => {
    let state = fresh(["a", "b"]);
    state = own(state, "b", ["pawn-shop"]);
    expect(buyTerritory(state, "a", "pawn-shop").ok).toBe(false);
  });

  it("marks a declined tile down and honours the floor", () => {
    let state = fresh(["a"]);
    for (let i = 0; i < 20; i++) state = declineTerritory(state, "first-city-bank");
    const t = state.territories.find((x) => x.id === "first-city-bank")!;
    expect(currentPrice(t)).toBe(550);
  });

  it("pays Respect for a district the purchase completes", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["pawn-shop", "barber-shop"]);
    const before = playerOf(state, "a")!.respect;
    const result = buyTerritory(state, "a", "tattoo-parlour");
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(playerOf(result.state, "a")!.respect).toBe(before + 1);
  });
});

describe("building", () => {
  it("garrisons a crew to reach Level 2", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["drug-lab"]);
    const result = upgradeTerritory(state, "a", "drug-lab");
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const t = result.state.territories.find((x) => x.id === "drug-lab")!;
    expect(t.level).toBe(2);
    expect(t.garrison).toBe(1);
    expect(playerOf(result.state, "a")!.poolCrew).toBe(1);
  });

  it("refuses Level 2 with no crew in the pool", () => {
    let state = fresh(["a"]);
    state = own(state, "a", ["drug-lab"]);
    state = give(state, "a", { poolCrew: 0 });
    expect(upgradeTerritory(state, "a", "drug-lab").ok).toBe(false);
  });

  it("recruits crew at the discounted price for the Street Boss", () => {
    let state = fresh(["a"]);
    state = give(state, "a", { boss: "street-boss" });
    const result = recruitCrew(state, "a", "cash");
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    // 250 × 0.75
    expect(playerOf(result.state, "a")!.cash).toBe(1500 - 188);
  });
});

describe("laundering", () => {
  it("returns the Safehouse rate and clears nothing by default", () => {
    let state = fresh(["a"]);
    state = give(state, "a", { dirty: 1000, heat: 5 });
    const result = launder(state, "a", { amount: 1000, atSafehouse: true });
    expect(result.cash).toBe(800);
    expect(playerOf(result.state, "a")!.dirty).toBe(0);
    expect(playerOf(result.state, "a")!.heat).toBe(5);
  });

  it("gives the Smuggler ten more points", () => {
    let state = fresh(["a"]);
    state = give(state, "a", { dirty: 1000, boss: "smuggler" });
    expect(launder(state, "a", { amount: 1000, atSafehouse: true }).cash).toBe(900);
  });
});

describe("upkeep, raids and seizure", () => {
  it("raids and confiscates Dirty Money in the Raids band", () => {
    let state = fresh(["a"]);
    state = give(state, "a", { heat: 7, dirty: 800 });
    // A random that always returns ~0.99 rolls a 6, so the raid always fires.
    const result = runUpkeep(state, "a", () => 0.99);
    expect(result.raided).toBe(true);
    expect(result.confiscated).toBeGreaterThan(0);
    expect(playerOf(result.state, "a")!.dirty).toBe(0);
  });

  /**
   * The clause that makes Heat mean anything to a player who never touches
   * Dirty Money. Without it the police cannot reach a clean empire at all.
   */
  it("seizes the lowest-level territory when there is no Dirty Money", () => {
    let state = fresh(["a"]);
    state = give(state, "a", { heat: 7, dirty: 0 });
    state = own(state, "a", ["first-city-bank", "pawn-shop"]);
    state = {
      ...state,
      territories: state.territories.map((t) =>
        t.id === "first-city-bank" ? { ...t, level: 3 } : t
      ),
    };
    const result = runUpkeep(state, "a", () => 0.99);
    expect(result.raided).toBe(true);
    // Takes the cheapest Level 1 tile, not the valuable one.
    expect(result.seized).toBe("pawn-shop");
    expect(territoriesOf(result.state, "a").map((t) => t.id)).toEqual([
      "first-city-bank",
    ]);
  });

  it("jails on a Federal raid", () => {
    let state = fresh(["a"]);
    state = give(state, "a", { heat: HEAT.federalAt, dirty: 500 });
    const result = runUpkeep(state, "a", () => 0.99);
    expect(result.jailed).toBe(true);
    expect(playerOf(result.state, "a")!.jailTurns).toBe(3);
  });

  it("never raids a Clean player", () => {
    let state = fresh(["a"]);
    state = give(state, "a", { heat: 0, dirty: 0 });
    expect(runUpkeep(state, "a", () => 0.99).raided).toBe(false);
  });
});

describe("Most Wanted sweep", () => {
  it("flags and charges only seats above 1.25x the mean", () => {
    let state = fresh(["a", "b", "c"]);
    state = give(state, "a", { cash: 9000, heat: 0 });
    state = give(state, "b", { cash: 1000, heat: 0 });
    state = give(state, "c", { cash: 1000, heat: 0 });
    const swept = sweepMostWanted(state);
    expect(playerOf(swept, "a")!.mostWanted).toBe(true);
    expect(playerOf(swept, "a")!.heat).toBe(1);
    expect(playerOf(swept, "b")!.mostWanted).toBe(false);
    expect(playerOf(swept, "b")!.heat).toBe(0);
  });
});

describe("broken, not bankrupt", () => {
  it("force-launders first, and is not broken if that covers the debt", () => {
    let state = fresh(["a", "b"]);
    state = give(state, "a", { cash: 100, dirty: 1000 });
    state = own(state, "a", ["drug-lab"]);
    const result = settleDebt(state, "a", 500, "b");
    expect(result.broken).toBe(false);
    expect(result.surrendered).toBeNull();
    expect(territoriesOf(result.state, "a")).toHaveLength(1);
  });

  it("surrenders the best territory to the creditor and pays a bailout", () => {
    let state = fresh(["a", "b"]);
    state = give(state, "a", { cash: 0, dirty: 0, respect: 10 });
    state = own(state, "a", ["pawn-shop", "first-city-bank"]);
    const result = settleDebt(state, "a", 900, "b");
    expect(result.broken).toBe(true);
    expect(result.surrendered).toBe("first-city-bank");
    expect(territoriesOf(result.state, "b").map((t) => t.id)).toContain(
      "first-city-bank"
    );
    const player = playerOf(result.state, "a")!;
    expect(player.respect).toBe(7);
    expect(player.cash).toBe(500);
    expect(player.eliminated).toBe(false);
  });

  it("caps bailouts so going broke can never be a strategy", () => {
    let state = fresh(["a", "b"]);
    state = give(state, "a", { cash: 0, dirty: 0, bailoutsTaken: 2 });
    const result = settleDebt(state, "a", 900, "b");
    expect(playerOf(result.state, "a")!.cash).toBe(0);
  });
});

/**
 * The question this whole phase exists to answer. Absolute numbers are a floor
 * — combat, missions, events and bribes are not modelled — but the relative
 * question is exactly what the simulation is valid for.
 */
describe("the anti-runaway brake, measured", () => {
  function leaders(seeds: number, seats = 4) {
    return Array.from({ length: seeds }, (_, s) => {
      const result = simulateMatch({
        seats,
        random: seeded(1000 + s),
        // Seat 1 plays perfectly clean — the case the brake must handle.
        policies: Array.from({ length: seats }, (_, i) =>
          i === 0 ? CLEAN_POLICY : DEFAULT_POLICY
        ),
      });
      const leader = result.players.find((p) => p.id === result.ranking[0])!;
      const mean =
        result.players.reduce((a, p) => a + p.empireValue, 0) /
        result.players.length;
      return { ...leader, ratio: leader.empireValue / mean };
    });
  }

  it("lands Empire Value in the GDD's stated target band", () => {
    const rows = leaders(40);
    const avg = rows.reduce((a, r) => a + r.empireValue, 0) / rows.length;
    // GDD Formulas preamble targets "a strong final Empire Value around $10–14k".
    expect(avg).toBeGreaterThan(7_000);
    expect(avg).toBeLessThan(18_000);
  });

  it("produces enough spread for Most Wanted to trigger at all", () => {
    const rows = leaders(40);
    const avgRatio = rows.reduce((a, r) => a + r.ratio, 0) / rows.length;
    // Below the 1.25x threshold the brake can never engage, whatever the
    // consequence rules say.
    expect(avgRatio).toBeGreaterThan(HEAT.mostWantedMult);
  });

  it("gets the leader into the Raids band in most matches", () => {
    const rows = leaders(40);
    const reached = rows.filter((r) => r.peakHeat >= HEAT.raidsAt).length;
    expect(reached / rows.length).toBeGreaterThan(0.4);
  });

  it("actually fires raids on the leader", () => {
    const rows = leaders(40);
    const raided = rows.filter((r) => r.raids > 0).length;
    expect(raided).toBeGreaterThan(0);
  });

  it("keeps income cadence on, without which none of the above holds", () => {
    // Documented as a knob because it was measured, not assumed: with income
    // on laps only, upgrades never repay and the EV spread never reaches 1.25x.
    expect(EMPIRE_WARS_CONFIG.incomeEveryRound).toBe(true);
  });

  it("never eliminates anyone", () => {
    const result = simulateMatch({ seats: 6, random: seeded(77) });
    expect(result.players).toHaveLength(6);
    expect(result.players.every((p) => p.empireValue > 0)).toBe(true);
  });

  it("replays identically from the same seed", () => {
    const a = simulateMatch({ seats: 4, random: seeded(4242) });
    const b = simulateMatch({ seats: 4, random: seeded(4242) });
    expect(a).toEqual(b);
  });
});

/**
 * Precise hidden-information checks. The generic contract test only proves the
 * view differs per seat; this proves the specific things the GDD calls private
 * never cross the boundary.
 */
describe("view projection hides what it should", () => {
  function loaded(): EmpireState {
    let state = fresh(["a", "b", "c"], 55);
    state = give(state, "b", { cash: 987_654, dirty: 123_456 });
    state = give(state, "c", { cash: 555_111, dirty: 222_333 });
    return state;
  }

  it("never exposes another seat's exact Cash or Dirty Money", () => {
    const json = JSON.stringify(viewFor(loaded(), "a"));
    for (const secret of [987_654, 123_456, 555_111, 222_333]) {
      expect(json).not.toContain(String(secret));
    }
  });

  it("never exposes another seat's missions still in hand", () => {
    const state = loaded();
    const view = viewFor(state, "a");
    const json = JSON.stringify(view);
    const others = state.players.filter((p) => p.id !== "a");
    for (const player of others) {
      for (const mission of player.missions.filter((m) => !m.completed)) {
        // Only true if "a" doesn't happen to hold the same card — per-player
        // decks make that possible, so exclude the viewer's own hand.
        const mine = view.you!.missions.map((m) => m.id);
        if (mine.includes(mission.id)) continue;
        expect(json).not.toContain(mission.id);
      }
    }
  });

  it("does expose Respect and Heat, which are public by design", () => {
    let state = loaded();
    state = give(state, "b", { respect: 17, heat: 8 });
    const view = viewFor(state, "a");
    const seatB = view.seats.find((s) => s.memberId === "b")!;
    expect(seatB.respect).toBe(17);
    expect(seatB.heat).toBe(8);
    expect(seatB.heatBand).toBe("raids");
  });

  it("gives a spectator no private section at all", () => {
    expect(viewFor(loaded(), null).you).toBeNull();
  });

  it("shows a pending decision's deadline so the client can count down", () => {
    const state: EmpireState = {
      ...fresh(["a", "b"], 56),
      pending: {
        kind: "protection",
        memberId: "a",
        territoryId: "drug-lab",
        fee: 100,
        expiresAt: 1_700_000_020_000,
      },
    };
    expect(viewFor(state, "a").pending?.expiresAt).toBe(1_700_000_020_000);
  });
});
