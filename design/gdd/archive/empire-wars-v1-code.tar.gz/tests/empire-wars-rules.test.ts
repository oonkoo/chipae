import { describe, expect, it } from "vitest";
import {
  HEAT,
  LEVEL_INCOME_MULT,
  TERRITORIES,
  TIER_CASH_RATE,
  TIER_DIRTY_RATE,
} from "@/lib/game/data/empire-wars";
import {
  cashIncome,
  currentPrice,
  dealGame,
  dirtyIncome,
  empireValue,
  isMostWanted,
  neighboursOf,
  parseState,
  protectionFee,
  resolveCombat,
  rollCombat,
  territoryDef,
  upgradeCost,
  upkeepHeatDelta,
  type EmpireState,
  type PropertyLevel,
  type TerritoryState,
} from "@/lib/game/empire-wars/rules";

// Validates the data transcription against the GDD's published tables, and the
// rules that the Heat simulation will depend on. Pure layer only — no DB.

function seeded(seed: number): () => number {
  let value = seed;
  return () => {
    value = (value * 1664525 + 1013904223) % 4294967296;
    return value / 4294967296;
  };
}

function tile(id: string, level: PropertyLevel = 1): TerritoryState {
  return { id, ownerId: null, level, garrison: 0, declines: 0 };
}

const MISSIONS = Array.from({ length: 10 }, (_, i) => `m${i + 1}`);
const EVENTS = Array.from({ length: 8 }, (_, i) => `e${i + 1}`);

describe("board data", () => {
  it("has 24 territories across 8 districts of 3", () => {
    expect(TERRITORIES).toHaveLength(24);
    const byDistrict = new Map<string, number>();
    for (const t of TERRITORIES) {
      byDistrict.set(t.district, (byDistrict.get(t.district) ?? 0) + 1);
    }
    expect(byDistrict.size).toBe(8);
    expect([...byDistrict.values()].every((n) => n === 3)).toBe(true);
  });

  it("has the published tier split of 12 small / 8 illegal / 4 landmark", () => {
    const count = (tier: string) =>
      TERRITORIES.filter((t) => t.tier === tier).length;
    expect(count("small")).toBe(12);
    expect(count("illegal")).toBe(8);
    expect(count("landmark")).toBe(4);
  });

  it("totals the published board value of $10,010", () => {
    expect(TERRITORIES.reduce((sum, t) => sum + t.price, 0)).toBe(10_010);
  });

  it("gives every territory a unique tile, none on a special", () => {
    const tiles = TERRITORIES.map((t) => t.tile);
    expect(new Set(tiles).size).toBe(24);
    // Corners and the four mid-side specials.
    for (const special of [0, 4, 8, 12, 16, 20, 24, 28]) {
      expect(tiles).not.toContain(special);
    }
  });
});

describe("income formulas", () => {
  // The acceptance criterion: all 24 × 5 combinations regenerate from the
  // formula, with round() half-up.
  it("regenerates all 120 income combinations from price × rate × level", () => {
    for (const def of TERRITORIES) {
      for (const level of [1, 2, 3, 4, 5] as PropertyLevel[]) {
        const t = tile(def.id, level);
        expect(cashIncome(t)).toBe(
          Math.round(
            def.price * TIER_CASH_RATE[def.tier] * LEVEL_INCOME_MULT[level]
          )
        );
        const rate = TIER_DIRTY_RATE[def.tier];
        expect(dirtyIncome(t)).toBe(
          rate === null
            ? null
            : Math.round(def.price * rate * LEVEL_INCOME_MULT[level])
        );
      }
    }
  });

  it("matches the GDD's published Level 1 table", () => {
    const published: Record<string, [number, number | null]> = {
      "pawn-shop": [18, null],
      "barber-shop": [21, null],
      "tattoo-parlour": [24, null],
      "cigar-lounge": [24, null],
      "car-wash": [27, null],
      "liquor-store": [45, 75],
      "fish-market": [30, null],
      "boat-yard": [50, 83],
      "shipping-port": [96, 168],
      garage: [36, null],
      factory: [39, null],
      "chop-shop": [63, 105],
      "coffee-house": [42, null],
      "drug-lab": [68, 113],
      "money-laundry": [72, 120],
      "jazz-cellar": [48, null],
      "gin-joint": [77, 128],
      "onyx-room": [136, 238],
      "poker-room": [84, 140],
      racetrack: [87, 145],
      "golden-chip": [152, 266],
      "accounting-office": [60, null],
      "bail-bonds": [63, null],
      "first-city-bank": [176, 308],
    };
    for (const [id, [cash, dirty]] of Object.entries(published)) {
      expect([id, cashIncome(tile(id))]).toEqual([id, cash]);
      expect([id, dirtyIncome(tile(id))]).toEqual([id, dirty]);
    }
  });

  it("rounds half-up where the GDD says it matters", () => {
    // Boat Yard dirty at L1: 330 × 0.25 = 82.5 → 83, not 82.
    expect(dirtyIncome(tile("boat-yard"))).toBe(83);
  });

  it("never offers a dirty option on a small tile", () => {
    for (const def of TERRITORIES.filter((t) => t.tier === "small")) {
      expect(dirtyIncome(tile(def.id))).toBeNull();
    }
  });

  it("spans the published output range of 18 to 792", () => {
    const all = TERRITORIES.flatMap((def) =>
      ([1, 2, 3, 4, 5] as PropertyLevel[]).map((l) => cashIncome(tile(def.id, l)))
    );
    expect(Math.min(...all)).toBe(18);
    expect(Math.max(...all)).toBe(792);
  });
});

describe("protection fees", () => {
  it("matches the GDD's worked example (Drug Lab L3, district held)", () => {
    expect(protectionFee(tile("drug-lab", 3), true)).toBe(267);
  });

  it("matches the corrected maximum of $1,337", () => {
    expect(protectionFee(tile("first-city-bank", 5), true)).toBe(1337);
  });

  it("matches the published minimum of $22", () => {
    expect(protectionFee(tile("pawn-shop", 1), false)).toBe(22);
  });
});

describe("costs", () => {
  it("matches the GDD's Drug Lab upgrade examples", () => {
    expect(upgradeCost("drug-lab", 3)).toBe(270);
    expect(upgradeCost("drug-lab", 4)).toBe(405);
    expect(upgradeCost("drug-lab", 5)).toBe(585);
  });

  it("marks a declined tile down 10% per decline, floored at 50%", () => {
    const t = tile("first-city-bank");
    expect(currentPrice({ ...t, declines: 0 })).toBe(1100);
    expect(currentPrice({ ...t, declines: 1 })).toBe(990);
    expect(currentPrice({ ...t, declines: 5 })).toBe(550);
    // Floor holds no matter how many times it is passed over.
    expect(currentPrice({ ...t, declines: 99 })).toBe(550);
  });
});

describe("adjacency", () => {
  it("gives every territory exactly two neighbours", () => {
    for (const def of TERRITORIES) {
      expect(new Set(neighboursOf(def.id)).size).toBe(2);
    }
  });

  it("is symmetric", () => {
    for (const def of TERRITORIES) {
      for (const n of neighboursOf(def.id)) {
        expect(neighboursOf(n)).toContain(def.id);
      }
    }
  });

  it("skips special tiles and closes the loop", () => {
    // Tattoo Parlour (3) neighbours Cigar Lounge (5) across the checkpoint.
    expect(neighboursOf("tattoo-parlour")).toContain("cigar-lounge");
    // The ring closes across The Docks.
    expect(neighboursOf("first-city-bank")).toContain("pawn-shop");
  });
});

describe("combat", () => {
  const random = seeded(1);

  it("rolls at least one die even at zero strength", () => {
    for (let i = 0; i < 50; i++) {
      const roll = rollCombat(0, random);
      expect(roll).toBeGreaterThanOrEqual(1);
      expect(roll).toBeLessThanOrEqual(6);
    }
  });

  it("keeps the best two, so two dice cap at 12", () => {
    for (let i = 0; i < 200; i++) {
      expect(rollCombat(6, random)).toBeLessThanOrEqual(12);
      expect(rollCombat(6, random)).toBeGreaterThanOrEqual(2);
    }
  });

  it("gives ties to the defender", () => {
    // Force a tie by driving both rolls from an identical stream.
    let calls = 0;
    const paired = () => {
      calls++;
      return 0.99; // always a 6
    };
    const result = resolveCombat(2, 2, paired);
    expect(result.attackRoll).toBe(result.defenceRoll);
    expect(result.attackerWins).toBe(false);
    expect(calls).toBeGreaterThan(0);
  });
});

describe("empire value", () => {
  it("matches the GDD's corrected worked example of $6,556", () => {
    const state = dealGame(["a"], seeded(3), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    const owned: Array<[string, PropertyLevel]> = [
      ["drug-lab", 3],
      ["chop-shop", 2],
      ["garage", 4],
      ["factory", 1],
      ["coffee-house", 2],
    ];
    const withEmpire: EmpireState = {
      ...state,
      players: [
        {
          ...state.players[0],
          cash: 2000,
          dirty: 400,
          respect: 12,
          poolCrew: 4,
          enforcers: 0,
        },
      ],
      territories: state.territories.map((t) => {
        const hit = owned.find(([id]) => id === t.id);
        return hit ? { ...t, ownerId: "a", level: hit[1] } : t;
      }),
    };
    expect(empireValue(withEmpire, "a")).toBe(6556);
  });

  it("counts pool crew only — a garrison is already priced into the level", () => {
    const state = dealGame(["a"], seeded(4), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    const base: EmpireState = {
      ...state,
      players: [{ ...state.players[0], cash: 0, dirty: 0, respect: 0, poolCrew: 0 }],
      territories: state.territories.map((t) =>
        t.id === "drug-lab" ? { ...t, ownerId: "a", level: 2, garrison: 1 } : t
      ),
    };
    // 450 × 1.3 = 585, and the garrisoned crew adds nothing on top.
    expect(empireValue(base, "a")).toBe(585);
  });
});

describe("the Heat brake", () => {
  function playerWith(over: Partial<{ dirty: number; mostWanted: boolean }>) {
    const state = dealGame(["a"], seeded(5), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    return { ...state.players[0], dirty: 0, mostWanted: false, ...over };
  }

  it("charges 1 Heat per DIRTY_HEAT_STEP held", () => {
    expect(upkeepHeatDelta(playerWith({ dirty: 1200 }))).toBe(3);
    expect(upkeepHeatDelta(playerWith({ dirty: 399 }))).toBe(0);
    expect(upkeepHeatDelta(playerWith({ dirty: 400 }))).toBe(1);
  });

  it("sheds 1 Heat for a clean player who is not leading", () => {
    expect(upkeepHeatDelta(playerWith({ dirty: 0, mostWanted: false }))).toBe(-1);
  });

  /**
   * The regression that motivated the fix. With the shed unsuppressed, Most
   * Wanted (+1/round) and the clean shed (−1/round) cancel exactly, the leader
   * never leaves the Clean band, and territory seizure never fires.
   */
  it("suppresses the shed for the leader, so Most Wanted is not cancelled", () => {
    expect(HEAT.cleanShedAppliesToMostWanted).toBe(false);
    const leader = playerWith({ dirty: 0, mostWanted: true });
    expect(upkeepHeatDelta(leader)).toBe(0);
    // Net for the round = upkeep (0) + Most Wanted (+1) = +1, so the leader
    // climbs rather than stalling.
    expect(upkeepHeatDelta(leader) + HEAT.mostWantedHeat).toBe(1);
  });

  it("reaches the Raids band within a plausible number of rounds", () => {
    let heat = 0;
    let rounds = 0;
    const leader = playerWith({ dirty: 0, mostWanted: true });
    while (heat < HEAT.raidsAt && rounds < 20) {
      heat += upkeepHeatDelta(leader) + HEAT.mostWantedHeat;
      rounds++;
    }
    expect(heat).toBeGreaterThanOrEqual(HEAT.raidsAt);
    expect(rounds).toBeLessThanOrEqual(8);
  });

  it("flags Most Wanted only above 1.25x the table mean", () => {
    const state = dealGame(["a", "b"], seeded(6), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    // a: 3000 cash, b: 1000 → mean 2000, threshold 2500.
    const skewed: EmpireState = {
      ...state,
      players: [
        { ...state.players[0], cash: 3000, respect: 0, poolCrew: 0 },
        { ...state.players[1], cash: 1000, respect: 0, poolCrew: 0 },
      ],
    };
    expect(isMostWanted(skewed, "a")).toBe(true);
    expect(isMostWanted(skewed, "b")).toBe(false);
  });
});

describe("dealGame", () => {
  it("is deterministic for a seed", () => {
    const a = dealGame(["a", "b", "c"], seeded(7), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    const b = dealGame(["a", "b", "c"], seeded(7), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    expect(a).toEqual(b);
  });

  it("opens with 24 unowned tiles and identical purses", () => {
    const state = dealGame(["a", "b"], seeded(8), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    expect(state.territories).toHaveLength(24);
    expect(state.territories.every((t) => t.ownerId === null)).toBe(true);
    expect(state.players.every((p) => p.cash === 1500)).toBe(true);
    expect(state.players.every((p) => p.tile === 0)).toBe(true);
    expect(state.pending).toBeNull();
    expect(state.winnerId).toBeNull();
  });

  it("gives every seat a different boss and 3 private missions", () => {
    const state = dealGame(["a", "b", "c", "d", "e", "f"], seeded(9), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    expect(new Set(state.players.map((p) => p.boss)).size).toBe(6);
    for (const p of state.players) {
      expect(p.missions).toHaveLength(3);
      expect(p.missions.every((m) => !m.completed)).toBe(true);
    }
    // A seat never holds the same mission twice, and always has more to draw.
    for (const p of state.players) {
      const held = p.missions.map((m) => m.id);
      expect(new Set(held).size).toBe(held.length);
      expect(new Set([...held, ...p.missionDeck]).size).toBe(MISSIONS.length);
    }
  });

  it("deals every seat a full hand even at six players", () => {
    // 6 seats × 3 = 18 against a 10-card design, which is why the deck is
    // per-player. A shared deck starves the last seats.
    const state = dealGame(["a", "b", "c", "d", "e", "f"], seeded(11), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    expect(state.players.every((p) => p.missions.length === 3)).toBe(true);
  });

  it("knows every territory it deals", () => {
    const state = dealGame(["a"], seeded(10), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    for (const t of state.territories) {
      expect(() => territoryDef(t.id)).not.toThrow();
    }
  });
});

/**
 * A save written before a field existed must still load.
 *
 * `GameSession.state` rows are written by whatever code was deployed at the
 * time. A field added as required rather than defaulted makes every in-flight
 * game unreadable the moment it ships — and an unreadable game used to wedge
 * its lobby in IN_GAME with no way out of the UI. This is the guard.
 */
describe("state schema tolerates older saves", () => {
  function saveWithout(...omit: string[]) {
    const state = dealGame(["a", "b"], seeded(31), {
      missionIds: MISSIONS,
      eventIds: EVENTS,
    });
    // Round-trip through Json the way the database actually stores it.
    const raw = JSON.parse(JSON.stringify(state)) as Record<string, unknown>;
    for (const key of omit) delete raw[key];
    return raw;
  }

  const GREW_LATER = [
    "lastRoll",
    "tileDone",
    "phase",
    "dieFace",
    "doubles",
    "turfWarUsed",
    "freeAttackFor",
    "log",
  ];

  for (const field of GREW_LATER) {
    it(`loads a save written before \`${field}\` existed`, () => {
      expect(parseState(saveWithout(field))).not.toBeNull();
    });
  }

  it("loads a save missing every later field at once", () => {
    expect(parseState(saveWithout(...GREW_LATER))).not.toBeNull();
  });

  it("loads a player written before the mission counters existed", () => {
    const raw = saveWithout() as { players: Array<Record<string, unknown>> };
    for (const player of raw.players) {
      delete player.fightsWon;
      delete player.turfWarsWon;
      delete player.launderedTotal;
      delete player.missionDeck;
    }
    expect(parseState(raw)).not.toBeNull();
  });

  it("still rejects a save that is genuinely not this game", () => {
    expect(parseState({ gameType: "nuno", players: [] })).toBeNull();
  });
});
