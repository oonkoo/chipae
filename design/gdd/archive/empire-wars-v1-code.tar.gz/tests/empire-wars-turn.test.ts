import { describe, expect, it } from "vitest";
import { EMPIRE_WARS_CONFIG, HEAT } from "@/lib/game/data/empire-wars";
import { EVENTS, MISSION_IDS, EVENT_IDS } from "@/lib/game/data/empire-wars-content";
import {
  applyMove,
  applyQuit,
  empireMoveSchema,
  resolveExpired,
  turnHasExpired,
  type MoveCtx,
} from "@/lib/game/empire-wars/turn";
import { applyEvent, settleMissions } from "@/lib/game/empire-wars/progress";
import { chooseBotMove } from "@/lib/game/empire-wars/bot";
import {
  currentPlayer,
  dealGame,
  playerOf,
  territoriesOf,
  type EmpireState,
} from "@/lib/game/empire-wars/rules";

function seeded(seed: number): () => number {
  let value = seed;
  return () => {
    value = (value * 1664525 + 1013904223) % 4294967296;
    return value / 4294967296;
  };
}

const NOW = 1_760_000_000_000;
const ctx = (seed = 1): MoveCtx => ({ random: seeded(seed), now: NOW });

function fresh(seats: string[], seed = 1): EmpireState {
  return dealGame(seats, seeded(seed), {
    missionIds: [...MISSION_IDS],
    eventIds: [...EVENT_IDS],
  });
}

function give(
  state: EmpireState,
  id: string,
  over: Partial<EmpireState["players"][number]>
): EmpireState {
  return {
    ...state,
    players: state.players.map((p) => (p.id === id ? { ...p, ...over } : p)),
  };
}

function own(state: EmpireState, id: string, ids: string[]): EmpireState {
  return {
    ...state,
    territories: state.territories.map((t) =>
      ids.includes(t.id) ? { ...t, ownerId: id } : t
    ),
  };
}

describe("move validation", () => {
  it("rejects a move from a seat that isn't on the clock", () => {
    const state = fresh(["a", "b"]);
    const other = state.players.find((p) => p.id !== currentPlayer(state).id)!;
    const result = applyMove(state, other.id, { kind: "roll" }, ctx());
    expect(result.ok).toBe(false);
  });

  it("rejects rolling twice in a turn", () => {
    const state = fresh(["a", "b"]);
    const me = currentPlayer(state).id;
    const rolled = applyMove(state, me, { kind: "roll" }, ctx());
    expect(rolled.ok).toBe(true);
    if (!rolled.ok) return;
    expect(applyMove(rolled.state, me, { kind: "roll" }, ctx()).ok).toBe(false);
  });

  it("rejects every move once the game is won", () => {
    const state: EmpireState = { ...fresh(["a", "b"]), winnerId: "a" };
    expect(applyMove(state, "a", { kind: "roll" }, ctx()).ok).toBe(false);
  });

  it("accepts only known move shapes", () => {
    expect(empireMoveSchema.safeParse({ kind: "roll" }).success).toBe(true);
    expect(empireMoveSchema.safeParse({ kind: "nope" }).success).toBe(false);
    expect(
      empireMoveSchema.safeParse({ kind: "useCar", extra: 9 }).success
    ).toBe(false);
  });
});

describe("settling a tile", () => {
  it("refuses a second decline on the same tile", () => {
    let state = fresh(["a", "b"]);
    const me = currentPlayer(state).id;
    state = { ...state, phase: "act", tileDone: false };
    state = give(state, me, { tile: 1 });

    const first = applyMove(state, me, { kind: "decline" }, ctx());
    expect(first.ok).toBe(true);
    if (!first.ok) return;
    // Without this the tile stays unowned and a bot declines forever.
    expect(applyMove(first.state, me, { kind: "decline" }, ctx()).ok).toBe(false);
  });

  it("marks a declined tile down for whoever lands next", () => {
    let state = fresh(["a", "b"]);
    const me = currentPlayer(state).id;
    state = { ...state, phase: "act", tileDone: false };
    state = give(state, me, { tile: 31 }); // First City Bank, $1,100

    const declined = applyMove(state, me, { kind: "decline" }, ctx());
    expect(declined.ok).toBe(true);
    if (!declined.ok) return;
    const tile = declined.state.territories.find(
      (t) => t.id === "first-city-bank"
    )!;
    expect(tile.declines).toBe(1);
  });

  it("refuses to buy a tile already settled this turn", () => {
    let state = fresh(["a", "b"]);
    const me = currentPlayer(state).id;
    state = { ...state, phase: "act", tileDone: true };
    state = give(state, me, { tile: 1 });
    expect(applyMove(state, me, { kind: "buy" }, ctx()).ok).toBe(false);
  });
});

describe("pending decisions", () => {
  function withPending(seed = 5): EmpireState {
    const base = fresh(["a", "b"], seed);
    return {
      ...base,
      pending: {
        kind: "protection",
        memberId: "a",
        territoryId: "drug-lab",
        fee: 100,
        expiresAt: NOW + EMPIRE_WARS_CONFIG.decisionWindowMs,
      },
      territories: base.territories.map((t) =>
        t.id === "drug-lab" ? { ...t, ownerId: "b" } : t
      ),
    };
  }

  it("blocks every other move while one is open", () => {
    const state = withPending();
    expect(applyMove(state, "a", { kind: "roll" }, ctx()).ok).toBe(false);
    expect(applyMove(state, "a", { kind: "endTurn" }, ctx()).ok).toBe(false);
  });

  it("refuses an answer from anyone but the named answerer", () => {
    const state = withPending();
    expect(applyMove(state, "b", { kind: "payFee" }, ctx()).ok).toBe(false);
  });

  it("clears once answered", () => {
    const state = withPending();
    const paid = applyMove(state, "a", { kind: "payFee" }, ctx());
    expect(paid.ok).toBe(true);
    if (!paid.ok) return;
    expect(paid.state.pending).toBeNull();
  });

  /**
   * Expiry is judged by the server's clock, never the caller's. Without this a
   * player with a fast clock could force-resolve a live decision and default
   * someone else's open choice.
   */
  it("refuses to resolve a decision that is still live", () => {
    const state = withPending();
    const early = resolveExpired(state, { random: seeded(1), now: NOW });
    expect(early.ok).toBe(false);
  });

  it("resolves to the default once the deadline has passed", () => {
    const state = withPending();
    const late = resolveExpired(state, {
      random: seeded(1),
      now: NOW + EMPIRE_WARS_CONFIG.decisionWindowMs + 1,
    });
    expect(late.ok).toBe(true);
    if (!late.ok) return;
    expect(late.state.pending).toBeNull();
    // The protection default is Pay, so the money moved.
    expect(playerOf(late.state, "a")!.cash).toBeLessThan(
      EMPIRE_WARS_CONFIG.startingCash
    );
  });

  it("lets any seat call the resolver, not just the answerer", () => {
    const state = withPending();
    const byOther = applyMove(
      state,
      "b",
      { kind: "resolveExpired" },
      { random: seeded(1), now: NOW + EMPIRE_WARS_CONFIG.decisionWindowMs + 1 }
    );
    expect(byOther.ok).toBe(true);
  });
});

describe("missions", () => {
  it("pays out and refills the hand when one completes", () => {
    let state = fresh(["a"], 9);
    state = give(state, "a", {
      missions: [{ id: "five-grand", completed: false }],
      missionDeck: ["six-tiles", "fortress"],
      cash: 6000,
      respect: 0,
    });
    const result = settleMissions(state, "a");
    expect(result.completed.map((c) => c.missionId)).toEqual(["five-grand"]);
    const player = playerOf(result.state, "a")!;
    expect(player.respect).toBe(3);
    expect(player.cash).toBe(6300);
    // Hand topped back up to three live missions.
    expect(player.missions.filter((m) => !m.completed)).toHaveLength(2);
  });

  it("does not pay the same mission twice", () => {
    let state = fresh(["a"], 10);
    state = give(state, "a", {
      missions: [{ id: "five-grand", completed: false }],
      missionDeck: [],
      cash: 6000,
      respect: 0,
    });
    const once = settleMissions(state, "a");
    const twice = settleMissions(once.state, "a");
    expect(twice.completed).toHaveLength(0);
    expect(playerOf(twice.state, "a")!.respect).toBe(3);
  });

  it("scores counters that cannot be read off the board", () => {
    let state = fresh(["a"], 11);
    state = give(state, "a", {
      missions: [
        { id: "three-wins", completed: false },
        { id: "launder-three-grand", completed: false },
      ],
      missionDeck: [],
      fightsWon: 3,
      launderedTotal: 3000,
    });
    const result = settleMissions(state, "a");
    expect(result.completed.map((c) => c.missionId).sort()).toEqual([
      "launder-three-grand",
      "three-wins",
    ]);
  });

  it("scores board-derived goals too", () => {
    let state = fresh(["a"], 12);
    state = own(state, "a", ["pawn-shop", "barber-shop", "tattoo-parlour"]);
    state = give(state, "a", {
      missions: [{ id: "control-a-district", completed: false }],
      missionDeck: [],
    });
    expect(settleMissions(state, "a").completed).toHaveLength(1);
  });

  it("lets the hand shrink when the deck runs dry", () => {
    let state = fresh(["a"], 13);
    state = give(state, "a", {
      missions: [{ id: "five-grand", completed: false }],
      missionDeck: [],
      cash: 6000,
    });
    const result = settleMissions(state, "a");
    expect(
      playerOf(result.state, "a")!.missions.filter((m) => !m.completed)
    ).toHaveLength(0);
  });
});

describe("events", () => {
  it("applies a card's effect to the seat that drew it", () => {
    const state = fresh(["a", "b"], 14);
    const card = EVENTS.find((e) => e.id === "informant-talked")!;
    const result = applyEvent(state, "a", card.id);
    expect(result.effect?.id).toBe("informant-talked");
    expect(playerOf(result.state, "a")!.heat).toBe(card.heat);
    // Nobody else is touched — every v1 event is personal.
    expect(playerOf(result.state, "b")!.heat).toBe(0);
  });

  it("never drives cash below zero", () => {
    let state = fresh(["a"], 15);
    state = give(state, "a", { cash: 10 });
    const result = applyEvent(state, "a", "shakedown");
    expect(playerOf(result.state, "a")!.cash).toBe(0);
  });

  it("clamps Heat at the floor", () => {
    let state = fresh(["a"], 16);
    state = give(state, "a", { heat: 1 });
    const result = applyEvent(state, "a", "cop-on-payroll");
    expect(playerOf(result.state, "a")!.heat).toBe(HEAT.min);
  });

  it("ignores an unknown card rather than throwing", () => {
    const state = fresh(["a"], 17);
    expect(applyEvent(state, "a", "not-a-card").effect).toBeNull();
  });
});

describe("quitting", () => {
  it("releases every territory and drops the seat from the rotation", () => {
    let state = fresh(["a", "b", "c"], 18);
    state = own(state, "a", ["pawn-shop", "drug-lab"]);
    const result = applyQuit(state, "a");
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(territoriesOf(result.state, "a")).toHaveLength(0);
    expect(playerOf(result.state, "a")!.eliminated).toBe(true);
    expect(
      result.state.territories.find((t) => t.id === "drug-lab")!.ownerId
    ).toBeNull();
  });

  it("hands the win to the last seat standing", () => {
    const state = fresh(["a", "b"], 19);
    const result = applyQuit(state, "a");
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.state.winnerId).toBe("b");
  });

  it("clears a pending decision the quitter owed", () => {
    const base = fresh(["a", "b", "c"], 20);
    const state: EmpireState = {
      ...base,
      pending: {
        kind: "truce",
        memberId: "a",
        fromMemberId: "b",
        expiresAt: NOW,
      },
    };
    const result = applyQuit(state, "a");
    if (!result.ok) throw new Error(result.error);
    expect(result.state.pending).toBeNull();
  });
});

describe("a full bot-driven match", () => {
  it("finishes inside the round limit and names a winner", () => {
    const c = ctx(42);
    let state = fresh(["a", "b", "c", "d"], 42);
    let guard = 0;


    while (!state.winnerId && guard < 5000) {
      const seat = state.pending
        ? state.pending.memberId
        : currentPlayer(state).id;
      const move = chooseBotMove(state, seat, c);
      if (!move) break;
      const result = applyMove(state, seat, move, c);
      if (!result.ok) throw new Error(`bot proposed an illegal move: ${result.error}`);
      state = result.state;
      guard++;
    }

    expect(state.winnerId).not.toBeNull();
    expect(state.round).toBeLessThanOrEqual(EMPIRE_WARS_CONFIG.roundLimit);
    expect(guard).toBeLessThan(5000);
  });
});

/**
 * A human must always have something to click.
 *
 * The bot hid this class of bug for a while: `chooseBotMove` falls through to
 * `endTurn` from any phase, so a full bot match completed happily while a
 * human sat in phase `act` with no die face and no buttons, unable to advance.
 * These assert the invariant the *board* relies on.
 */
describe("a turn is never stranded", () => {
  it("leaves the roller either holding a die or in Build", () => {
    // Every seed exercises a different action-die face; the automatic faces
    // (Money Bag, Police, Question) are the ones that used to strand a turn.
    for (let seed = 1; seed <= 60; seed++) {
      const state = fresh(["a", "b"], seed);
      const me = currentPlayer(state).id;
      const rolled = applyMove(state, me, { kind: "roll" }, ctx(seed));
      if (!rolled.ok) continue;
      const after = rolled.state;

      // A pending decision is its own path forward, and so is jail.
      if (after.pending) continue;
      if (playerOf(after, me)!.jailTurns > 0) continue;

      const holdsDie = after.phase === "act" && after.dieFace !== null;
      const canSettleTile = after.phase === "act" && !after.tileDone;
      const inBuild = after.phase === "build";
      expect(
        holdsDie || canSettleTile || inBuild,
        `seed ${seed}: phase=${after.phase} die=${after.dieFace} tileDone=${after.tileDone}`
      ).toBe(true);
    }
  });

  it("always accepts endTurn once the die is spent", () => {
    for (let seed = 1; seed <= 40; seed++) {
      const state = fresh(["a", "b"], seed);
      const me = currentPlayer(state).id;
      const rolled = applyMove(state, me, { kind: "roll" }, ctx(seed));
      if (!rolled.ok || rolled.state.pending) continue;

      // Spend the die if one is held, then the turn must be closable.
      let cursor = rolled.state;
      if (cursor.dieFace) {
        const skipped = applyMove(cursor, me, { kind: "skipDie" }, ctx(seed));
        if (skipped.ok) cursor = skipped.state;
      }
      expect(applyMove(cursor, me, { kind: "endTurn" }, ctx(seed)).ok).toBe(true);
    }
  });
});

/**
 * The bug that hung a CPU turn on "…is thinking".
 *
 * Clients drive bots by watching the view for change and calling the server
 * once per move. A bot's turn is several moves — roll, buy, upgrade, end — so
 * if the watched value stops changing partway through, the driver stops firing
 * and the table freezes with a CPU on the clock forever. It shipped that way
 * because `phase` and `round` were the watched values, and both sit still for
 * most of a turn.
 */
describe("every move changes something a client can watch", () => {
  it("bumps the version on each accepted move", () => {
    const state = fresh(["a", "b"], 61);
    const me = currentPlayer(state).id;
    const rolled = applyMove(state, me, { kind: "roll" }, ctx(61));
    expect(rolled.ok).toBe(true);
    if (!rolled.ok) return;
    expect(rolled.state.version).toBe(state.version + 1);
  });

  it("never repeats a version across a whole bot turn", () => {
    // The real failure: several consecutive moves whose phase/round are
    // identical. Versions must still differ, or the driver stalls.
    for (let seed = 1; seed <= 20; seed++) {
      const c = ctx(seed);
      let state = fresh(["a", "b"], seed);
      const seen = new Set<number>([state.version]);

      for (let step = 0; step < 15; step++) {
        const seat = state.pending
          ? state.pending.memberId
          : currentPlayer(state).id;
        const move = chooseBotMove(state, seat, c);
        if (!move) break;
        const result = applyMove(state, seat, move, c);
        if (!result.ok) break;
        expect(
          seen.has(result.state.version),
          `seed ${seed} step ${step}: version ${result.state.version} repeated`
        ).toBe(false);
        seen.add(result.state.version);
        state = result.state;
      }
    }
  });

  it("leaves a version change even when phase and round hold still", () => {
    // Buy then upgrade: both land in the same phase and round, which is
    // exactly the window the old driver went blind in.
    let state = fresh(["a", "b"], 62);
    const me = currentPlayer(state).id;
    state = {
      ...state,
      phase: "build",
      players: state.players.map((p) =>
        p.id === me ? { ...p, cash: 9000 } : p
      ),
      territories: state.territories.map((t) =>
        t.id === "drug-lab" ? { ...t, ownerId: me } : t
      ),
    };

    const first = applyMove(state, me, { kind: "recruit", currency: "cash" }, ctx(62));
    expect(first.ok).toBe(true);
    if (!first.ok) return;
    const second = applyMove(
      first.state,
      me,
      { kind: "upgrade", territoryId: "drug-lab" },
      ctx(62)
    );
    expect(second.ok).toBe(true);
    if (!second.ok) return;

    expect(second.state.phase).toBe(first.state.phase);
    expect(second.state.round).toBe(first.state.round);
    expect(second.state.version).not.toBe(first.state.version);
  });
});

describe("the turn clock", () => {
  it("gives the seat on the clock a fresh window after each move", () => {
    const state = fresh(["a", "b"], 63);
    const me = currentPlayer(state).id;
    const rolled = applyMove(state, me, { kind: "roll" }, ctx(63));
    expect(rolled.ok).toBe(true);
    if (!rolled.ok) return;
    expect(rolled.state.turnExpiresAt).toBe(
      NOW + EMPIRE_WARS_CONFIG.turnWindowMs
    );
  });

  it("is not expired while the window is still open", () => {
    const state = fresh(["a", "b"], 64);
    const me = currentPlayer(state).id;
    const rolled = applyMove(state, me, { kind: "roll" }, ctx(64));
    if (!rolled.ok) return;
    expect(turnHasExpired(rolled.state, NOW)).toBe(false);
    expect(
      turnHasExpired(rolled.state, NOW + EMPIRE_WARS_CONFIG.turnWindowMs - 1)
    ).toBe(false);
  });

  it("expires once the window passes", () => {
    const state = fresh(["a", "b"], 65);
    const me = currentPlayer(state).id;
    const rolled = applyMove(state, me, { kind: "roll" }, ctx(65));
    if (!rolled.ok) return;
    expect(
      turnHasExpired(rolled.state, NOW + EMPIRE_WARS_CONFIG.turnWindowMs)
    ).toBe(true);
  });

  it("stops running once someone has won", () => {
    const state: EmpireState = { ...fresh(["a", "b"], 66), winnerId: "a" };
    expect(turnHasExpired(state, NOW + 10_000_000)).toBe(false);
  });
});
